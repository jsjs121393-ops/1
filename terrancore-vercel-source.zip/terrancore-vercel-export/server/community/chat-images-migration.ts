import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { rows, execute, type Database } from "./database";

export const CHAT_IMAGES_VERSION = "community-schema-v2-chat-images";

// Caller holds the tc-setup database-specific advisory lock. DDL auto-commits,
// so inspect the actual column on every run, including after interrupted work.
export async function applyChatImagesMigration(db: Database): Promise<{
  addedColumn: boolean;
  initializedRows: number;
  backfilledRows: number;
  messages: number;
}> {
  const columns = await rows(
    "SELECT DATA_TYPE AS data_type,IS_NULLABLE AS is_nullable,COLUMN_DEFAULT AS column_default FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='tc_messages' AND COLUMN_NAME='images'",
    [],
    db
  );
  const addedColumn = columns.length === 0;
  let initializedRows = 0;
  if (addedColumn) {
    initializedRows = Number(
      (await rows("SELECT COUNT(*) AS count FROM tc_messages", [], db))[0].count
    );
    const sql = await readFile(
      fileURLToPath(
        new URL("./migrations/002_chat_images.sql", import.meta.url)
      ),
      "utf8"
    );
    for (const statement of sql
      .split(";")
      .map(s => s.trim())
      .filter(Boolean))
      await db.query(statement);
  } else if (columns[0].data_type !== "json") {
    throw new Error(
      "Chat images column has an unexpected type; no data changed"
    );
  }
  // Preserve every populated attachment array; only legacy SQL NULLs are filled.
  const backfill = await execute(
    "UPDATE tc_messages SET images=JSON_ARRAY() WHERE images IS NULL",
    [],
    db
  );
  const invalid = await rows(
    "SELECT COUNT(*) AS count FROM tc_messages WHERE images IS NULL OR JSON_TYPE(images) <> 'ARRAY'",
    [],
    db
  );
  if (Number(invalid[0].count) !== 0)
    throw new Error(
      "Chat images contains non-array values; readiness not marked"
    );
  if (
    addedColumn ||
    columns[0].is_nullable !== "NO" ||
    columns[0].column_default == null
  ) {
    // TiDB 8.5 rejects expression-default ADD COLUMN and JSON SET DEFAULT.
    // MODIFY COLUMN after backfill installs the default safely, preserving
    // compatibility with old text-only writers during overlapping deployment.
    await db.query(
      "ALTER TABLE tc_messages MODIFY COLUMN images JSON NOT NULL DEFAULT (JSON_ARRAY())"
    );
  }
  await execute(
    "INSERT IGNORE INTO tc_versions (version) VALUES (?)",
    [CHAT_IMAGES_VERSION],
    db
  );
  const messages = Number(
    (await rows("SELECT COUNT(*) AS count FROM tc_messages", [], db))[0].count
  );
  return {
    addedColumn,
    initializedRows,
    backfilledRows: backfill.affectedRows,
    messages,
  };
}
