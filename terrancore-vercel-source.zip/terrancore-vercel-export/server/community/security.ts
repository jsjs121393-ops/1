import {
  createHash,
  randomBytes,
  scrypt as nodeScrypt,
  timingSafeEqual,
} from "node:crypto";
import { promisify } from "node:util";
import { z } from "zod";

const scrypt = promisify(nodeScrypt);
export class ApiError extends Error {
  constructor(
    public status: number,
    message: string
  ) {
    super(message);
  }
}
export const hashToken = (token: string) =>
  createHash("sha256").update(token).digest("hex");
export const newToken = () => randomBytes(32).toString("base64url");

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(32).toString("hex");
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  return `scrypt$${salt}$${derived.toString("hex")}`;
}

export async function verifyPassword(
  password: string,
  encoded?: string
): Promise<boolean> {
  const parts = encoded?.split("$");
  const valid =
    parts?.length === 3 &&
    parts[0] === "scrypt" &&
    /^[a-f0-9]{64}$/.test(parts[1]) &&
    /^[a-f0-9]{128}$/.test(parts[2]);
  const salt = valid ? parts![1] : "0".repeat(64);
  const expected = valid ? Buffer.from(parts![2], "hex") : Buffer.alloc(64);
  const actual = (await scrypt(password, salt, 64)) as Buffer;
  return timingSafeEqual(actual, expected) && Boolean(valid);
}

export function sanitizeName(value: string): string {
  return value
    .normalize("NFKC")
    .replace(/<[^>]*>/g, "")
    .replace(
      /[<>\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2066-\u2069]/g,
      ""
    )
    .trim();
}
const text = (max: number, min = 1) =>
  z
    .string()
    .transform(v =>
      v
        .replace(/\r\n/g, "\n")
        .replace(/\u0000/g, "")
        .trim()
    )
    .pipe(z.string().min(min).max(max));
export const nameSchema = z
  .string()
  .max(300)
  .transform(sanitizeName)
  .pipe(z.string().min(1).max(30));
export const managedPath = z
  .string()
  .max(1024)
  .refine(
    value =>
      value === "" ||
      (/^\/manus-storage\/[A-Za-z0-9_./-]+$/.test(value) &&
        !value.includes("..") &&
        !value.includes("//")),
    "관리되는 이미지 경로만 사용할 수 있습니다."
  );
export const workSchema = z
  .object({
    kind: z.enum(["novel", "webtoon"]),
    title: text(200),
    description: text(10000, 0),
    genre: text(80),
    cover: managedPath,
    tags: z.array(text(30)).max(12),
    status: z.enum(["ongoing", "completed"]),
  })
  .strict();
export const episodeSchema = z
  .object({
    title: text(200),
    number: z.number().int().min(1).max(1000000),
    body: text(200000, 0),
    images: z.array(managedPath.refine(v => v !== "")).max(100),
  })
  .strict();
export const postSchema = z
  .object({ title: text(200), body: text(100000), category: text(80) })
  .strict();
export const commentSchema = z.object({ body: text(5000) }).strict();
export const roomSchema = z
  .string()
  .regex(
    /^(?:general|world|creators|room_[a-f0-9]{12})(?![\s\S])/,
    "올바르지 않은 채팅방 ID입니다."
  );
export const roomCreateSchema = z
  .object({
    name: text(40, 2),
    description: text(200, 0),
  })
  .strict();
export const roomUpdateSchema = roomCreateSchema
  .extend({ closed: z.boolean() })
  .partial()
  .refine(
    value => Object.keys(value).length > 0,
    "수정할 내용을 입력해 주세요."
  );
export const chatSchema = z
  .object({
    room: roomSchema,
    body: text(2000, 0),
    images: z
      .array(managedPath.refine(v => v !== ""))
      .max(4)
      .default([]),
  })
  .strict()
  .refine(value => value.body.length > 0 || value.images.length > 0, {
    message: "메시지 또는 이미지를 입력해 주세요.",
    path: ["body"],
  });
export const profileSchema = z.object({ name: nameSchema }).strict();
export const loginSchema = z
  .object({
    username: z.string().min(1).max(64),
    password: z.string().min(1).max(128),
  })
  .strict();
export const passwordSchema = z
  .object({
    currentPassword: z.string().min(1).max(128),
    newPassword: z
      .string()
      .min(8)
      .max(128)
      .refine(
        v => /[a-zA-Z]/.test(v) && /[^a-zA-Z]/.test(v),
        "새 비밀번호는 문자와 숫자 또는 기호를 포함해야 합니다."
      ),
  })
  .strict();
export const moderateSchema = z
  .object({
    entity: z.enum(["work", "episode", "post", "comment", "message"]),
    id: z.number().int().positive(),
    action: z.enum(["hide", "restore", "delete"]),
  })
  .strict();
export const memberSchema = z
  .object({ id: z.number().int().positive(), banned: z.boolean() })
  .strict();
export const uploadSchema = z
  .object({
    name: z.string().min(1).max(255),
    type: z.enum(["image/jpeg", "image/png", "image/webp", "image/gif"]),
    data: z.string().min(1).max(13981016),
  })
  .strict();

export function parse<T>(schema: z.ZodType<T>, input: unknown): T {
  const result = schema.safeParse(input);
  if (!result.success)
    throw new ApiError(
      400,
      result.error.issues[0]?.message ?? "요청 내용을 확인해 주세요."
    );
  return result.data;
}
export function idParam(value: string): number {
  if (!/^[1-9]\d{0,9}$/.test(value) || Number(value) > 2147483647)
    throw new ApiError(400, "올바르지 않은 ID입니다.");
  return Number(value);
}
export function assertOwner(
  ownerId: number,
  actorId: number,
  admin: boolean,
  sample = false
): void {
  if (!admin && (sample || ownerId !== actorId || actorId <= 0))
    throw new ApiError(403, "이 콘텐츠에 대한 권한이 없습니다.");
}
export function assertMutationHeader(value: string | undefined): void {
  if (value !== "web")
    throw new ApiError(403, "안전한 클라이언트 요청이 필요합니다.");
}
export const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;
export function validateImage(
  type: string,
  base64: string
): { buffer: Buffer; extension: string } {
  if (base64.length > Math.ceil(MAX_UPLOAD_BYTES / 3) * 4)
    throw new ApiError(413, "이미지는 최대 10MB까지 업로드할 수 있습니다.");
  if (
    !base64 ||
    base64.length % 4 !== 0 ||
    !/^[A-Za-z0-9+/]+={0,2}$/.test(base64)
  )
    throw new ApiError(400, "올바른 Base64 이미지가 아닙니다.");
  const buffer = Buffer.from(base64, "base64");
  if (buffer.length > MAX_UPLOAD_BYTES)
    throw new ApiError(413, "이미지는 최대 10MB까지 업로드할 수 있습니다.");
  const jpeg =
    buffer.length >= 4 &&
    buffer[0] === 0xff &&
    buffer[1] === 0xd8 &&
    buffer[2] === 0xff;
  const png =
    buffer.length >= 24 &&
    buffer
      .subarray(0, 8)
      .equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])) &&
    buffer.subarray(12, 16).toString("ascii") === "IHDR";
  const webp =
    buffer.length >= 16 &&
    buffer.subarray(0, 4).toString("ascii") === "RIFF" &&
    buffer.subarray(8, 12).toString("ascii") === "WEBP";
  const gif =
    buffer.length >= 13 &&
    ["GIF87a", "GIF89a"].includes(buffer.subarray(0, 6).toString("ascii"));
  const allowed: Record<string, [boolean, string]> = {
    "image/jpeg": [jpeg, "jpg"],
    "image/png": [png, "png"],
    "image/webp": [webp, "webp"],
    "image/gif": [gif, "gif"],
  };
  const match = allowed[type];
  if (!match?.[0])
    throw new ApiError(400, "이미지 형식과 파일 내용이 일치하지 않습니다.");
  return { buffer, extension: match[1] };
}
