import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  ApiError,
  parse,
  roomSchema,
  roomCreateSchema,
  roomUpdateSchema,
} from "./security";
import type { Identity } from "./auth";

const mocks = vi.hoisted(() => ({ rows: vi.fn(), execute: vi.fn() }));
vi.mock("./database", () => ({
  rows: mocks.rows,
  execute: mocks.execute,
  transaction: async (run: (db: any) => Promise<any>) => run({ mocked: true }),
}));
import { createRoom, updateRoom, getRooms, requireOpenRoom } from "./rooms";
import { createMessage } from "./content";
import { getMessages } from "./reads";

const roomId = "room_012345abcdef";
const guest: Identity = {
  user: null,
  admin: false,
  adminId: null,
  sessionHash: null,
};
const member: Identity = {
  ...guest,
  user: {
    id: 42,
    name: "시민",
    email: null,
    role: "user",
    createdAt: "2026-01-01T00:00:00Z",
  },
};
const admin: Identity = {
  ...guest,
  admin: true,
  adminId: 1,
  sessionHash: "test-session-hash",
};
let banned: boolean;
let stored: any;
const initial = () => ({
  id: roomId,
  name: "시민 방",
  description: "소개",
  creator_id: 42,
  creator_name: "시민",
  created_at: "2026-11-10 00:00:00",
  is_default: 0,
  closed: 0,
  message_count: 3,
});

beforeEach(() => {
  vi.clearAllMocks();
  banned = false;
  stored = initial();
  mocks.rows.mockImplementation(async (sql: string) => {
    if (sql.includes("FROM tc_member_moderation")) return [{ banned }];
    if (sql.includes("FROM tc_rooms")) return stored ? [{ ...stored }] : [];
    return [];
  });
  mocks.execute.mockImplementation(async (sql: string, values: any[]) => {
    if (sql.startsWith("INSERT INTO tc_rooms"))
      stored = {
        ...initial(),
        id: values[0],
        name: values[1],
        description: values[2],
        creator_id: values[3],
        creator_name: values[4],
        message_count: 0,
      };
    if (sql.startsWith("UPDATE tc_rooms"))
      stored = {
        ...stored,
        name: values[0],
        description: values[1],
        closed: values[2],
      };
    return { insertId: 1, affectedRows: 1 };
  });
});

const status = async (promise: Promise<unknown>, code: number) =>
  expect(promise).rejects.toMatchObject({ status: code });

describe("room fields (pure; no database writes)", () => {
  it("accepts only exact builtins and generated lower-hex IDs", () => {
    for (const value of ["general", "world", "creators", roomId])
      expect(parse(roomSchema, value)).toBe(value);
    for (const value of [
      "general\n",
      "general ",
      "시민 방",
      "room_012345abcdeF",
      "room_012345abcde",
      "room_012345abcdef0",
      "room_../../etc",
      "",
      null,
      ["general"],
    ])
      expect(() => parse(roomSchema, value)).toThrow(ApiError);
  });
  it("trims names/intros and enforces 2..40 / 0..200 characters", () => {
    expect(
      parse(roomCreateSchema, { name: "  시민 방 ", description: "  " })
    ).toEqual({ name: "시민 방", description: "" });
    expect(
      parse(roomCreateSchema, {
        name: "가".repeat(40),
        description: "나".repeat(200),
      })
    ).toBeTruthy();
    for (const value of [
      { name: " ", description: "" },
      { name: "가", description: "" },
      { name: "가".repeat(41), description: "" },
      { name: "정상", description: "나".repeat(201) },
      { name: "정상" },
      { name: "정상", description: "", creatorId: 99 },
    ])
      expect(() => parse(roomCreateSchema, value)).toThrow(ApiError);
  });
  it("patches only nonempty strict name/description/boolean closed fields", () => {
    for (const value of [
      { name: "수정" },
      { description: "" },
      { closed: true },
      { closed: false },
    ])
      expect(parse(roomUpdateSchema, value)).toEqual(value);
    for (const value of [
      {},
      { closed: "true" },
      { name: "가" },
      { creatorId: 1 },
      { isDefault: false },
      { id: roomId },
    ])
      expect(() => parse(roomUpdateSchema, value)).toThrow(ApiError);
  });
});

describe("room authorization and persistence (mock database only)", () => {
  it("denies guests and banned members, including dual member/admin identity", async () => {
    const input = { name: "새 방", description: "" };
    await status(createRoom(input, guest), 401);
    banned = true;
    await status(createRoom(input, member), 403);
    await status(createRoom(input, { ...admin, user: member.user }), 403);
    expect(mocks.execute).not.toHaveBeenCalled();
  });
  it("generates random IDs and stores validated member ownership", async () => {
    const result = await createRoom(
      { name: " 새 방 ", description: " 소개 " },
      member
    );
    expect(result).toMatchObject({
      name: "새 방",
      description: "소개",
      creatorId: 42,
      creator: "시민",
      isDefault: false,
      closed: false,
      messageCount: 0,
    });
    expect(result.id).toMatch(/^room_[a-f0-9]{12}$/);
    expect(mocks.execute.mock.calls[0][1]).toEqual([
      result.id,
      "새 방",
      "소개",
      42,
      "시민",
    ]);
    expect(mocks.execute.mock.calls[0][2]).toEqual({ mocked: true });
  });
  it("separate admin creates ID-zero rooms", async () => {
    const result = await createRoom(
      { name: "운영 방", description: "" },
      admin
    );
    expect(result.creatorId).toBe(0);
    expect(result.creator).toBe("테란 관리자");
  });
  it("owner can edit/close/reopen without deleting any content", async () => {
    expect(
      await updateRoom(roomId, { name: "수정 이름" }, member)
    ).toMatchObject({
      name: "수정 이름",
      description: "소개",
      messageCount: 3,
    });
    expect(
      await updateRoom(roomId, { closed: true, description: "" }, member)
    ).toMatchObject({ closed: true, description: "", messageCount: 3 });
    expect(await updateRoom(roomId, { closed: false }, member)).toMatchObject({
      closed: false,
    });
    expect(
      mocks.execute.mock.calls.every(([sql]) =>
        sql.startsWith("UPDATE tc_rooms")
      )
    ).toBe(true);
    expect(
      mocks.rows.mock.calls.some(([sql]) => sql.includes("FOR UPDATE"))
    ).toBe(true);
  });
  it("denies other members, guests and banned owners; admins can edit others", async () => {
    stored.creator_id = 99;
    await status(updateRoom(roomId, { closed: true }, member), 403);
    await status(updateRoom(roomId, { closed: true }, guest), 401);
    stored.creator_id = 42;
    banned = true;
    await status(updateRoom(roomId, { closed: true }, member), 403);
    banned = false;
    stored.creator_id = 99;
    expect(await updateRoom(roomId, { closed: true }, admin)).toMatchObject({
      closed: true,
    });
  });
  it("ID-zero custom rooms are editable only by separately authenticated admin", async () => {
    stored.creator_id = 0;
    await status(updateRoom(roomId, { name: "수정" }, member), 403);
    expect(
      await updateRoom(roomId, { name: "운영 수정" }, admin)
    ).toMatchObject({ name: "운영 수정" });
  });
  it("blocks all default-room changes with 409 for authorized administrators", async () => {
    stored.is_default = 1;
    stored.creator_id = 0;
    for (const value of [
      { name: "변경" },
      { description: "수정" },
      { closed: true },
      { closed: false },
    ])
      await status(updateRoom("general", value, admin), 409);
    expect(mocks.execute).not.toHaveBeenCalled();
  });
  it("returns 404 for missing rooms without writing", async () => {
    stored = null;
    await status(updateRoom(roomId, { closed: true }, member), 404);
    expect(mocks.execute).not.toHaveBeenCalled();
  });
  it("lists public open rooms defaults-first/newest; admin list includes closed rooms", async () => {
    expect((await getRooms())[0]).toMatchObject({
      creatorId: 42,
      messageCount: 3,
    });
    const publicSql = mocks.rows.mock.calls[0][0];
    expect(publicSql).toContain("WHERE r.closed=FALSE");
    expect(publicSql).toContain("ORDER BY r.is_default DESC,r.created_at DESC");
    await getRooms(true);
    expect(mocks.rows.mock.calls[1][0]).not.toContain("WHERE r.closed=FALSE");
  });
});

describe("room openness and chat race guard (mock database only)", () => {
  it("rejects nonexistent/closed reads and writes before attachment validation or insertion", async () => {
    for (const [value, code] of [
      [null, 404],
      [{ ...initial(), closed: 1 }, 409],
    ] as const) {
      stored = value;
      await status(getMessages(roomId), code);
      await status(
        createMessage(roomId, "", member, ["/manus-storage/missing.png"]),
        code
      );
      await status(requireOpenRoom(roomId, { mocked: true } as any), code);
    }
    expect(mocks.execute).not.toHaveBeenCalled();
    expect(
      mocks.rows.mock.calls.some(([sql]) => sql.includes("FROM tc_uploads"))
    ).toBe(false);
  });
  it("locks the open room before image-owner lookup and message insertion in one transaction", async () => {
    const original = mocks.rows.getMockImplementation()!;
    mocks.rows.mockImplementation((sql: string, values: any[]) =>
      sql.includes("FROM tc_uploads")
        ? Promise.resolve([
            {
              url: "/manus-storage/owned.png",
              owner_id: 42,
              admin_owned: false,
            },
          ])
        : original(sql, values)
    );
    expect(
      await createMessage(roomId, "", member, ["/manus-storage/owned.png"])
    ).toEqual({ id: 1 });
    const calls = mocks.rows.mock.calls;
    expect(
      calls.findIndex(
        ([sql]) => sql.includes("tc_rooms") && sql.includes("FOR UPDATE")
      )
    ).toBeLessThan(calls.findIndex(([sql]) => sql.includes("tc_uploads")));
    expect(calls.every(call => call[2]?.mocked === true)).toBe(true);
    expect(mocks.execute.mock.calls[0][0]).toContain("INSERT INTO tc_messages");
    expect(mocks.execute.mock.calls[0][1][0]).toBe(roomId);
  });
});
