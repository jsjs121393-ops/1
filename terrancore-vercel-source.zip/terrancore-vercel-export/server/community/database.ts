import mysql, {
  type Pool,
  type PoolConnection,
  type ResultSetHeader,
  type RowDataPacket,
} from "mysql2/promise";

export type Database = Pool | PoolConnection;
export type Row = RowDataPacket & Record<string, any>;
let pool: Pool | undefined;

export function getCommunityPool(): Pool {
  if (!pool) {
    const uri = process.env.DATABASE_URL;
    if (!uri) throw new Error("Community database is not configured");
    // mysql2 parses managed DSN options, including TLS, from the supplied URI.
    pool = mysql.createPool({
      uri,
      connectionLimit: 8,
      charset: "utf8mb4",
      timezone: "Z",
      dateStrings: true,
      enableKeepAlive: true,
    });
    pool.on("connection", connection => {
      connection.query("SET time_zone = '+00:00'");
    });
  }
  return pool;
}

export async function rows<T extends Row = Row>(
  sql: string,
  values: unknown[] = [],
  db: Database = getCommunityPool()
): Promise<T[]> {
  const [result] = await db.execute<T[]>(sql, values);
  return result;
}

export async function execute(
  sql: string,
  values: unknown[] = [],
  db: Database = getCommunityPool()
): Promise<ResultSetHeader> {
  const [result] = await db.execute<ResultSetHeader>(sql, values);
  return result;
}

export async function transaction<T>(
  run: (db: PoolConnection) => Promise<T>
): Promise<T> {
  const connection = await getCommunityPool().getConnection();
  try {
    await connection.beginTransaction();
    const result = await run(connection);
    await connection.commit();
    return result;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

export async function checkReady(): Promise<void> {
  const result = await rows(
    "SELECT version FROM tc_versions WHERE version IN (?,?,?)",
    [
      "community-seed-v1",
      "community-schema-v2-chat-images",
      "community-schema-v3-chat-rooms",
    ]
  );
  if (result.length !== 3)
    throw new Error("Community database setup is incomplete");
}

export async function closeCommunityPool(): Promise<void> {
  if (pool) {
    await pool.end();
    pool = undefined;
  }
}
