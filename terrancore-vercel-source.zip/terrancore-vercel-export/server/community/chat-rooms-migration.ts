import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { rows, execute, type Database } from "./database";

export const CHAT_ROOMS_VERSION = "community-schema-v3-chat-rooms";
export const DEFAULT_CHAT_ROOMS = [
  {
    id: "general",
    name: "테란 라운지",
    description: "오늘의 생각과 소소한 이야기를 나누는 곳.",
  },
  {
    id: "world",
    name: "세계관 연구소",
    description: "테란의 역사와 행성, 새로운 설정을 함께 만들어요.",
  },
  {
    id: "creators",
    name: "창작자 살롱",
    description: "연재와 그림, 창작의 모든 고민을 나눠요.",
  },
] as const;

// Caller holds the same database-specific tc-setup advisory lock as v1/v2.
// DDL auto-commits; inspect actual schema every time, not only the version marker.
export async function applyChatRoomsMigration(db: Database): Promise<{
  widenedColumn: boolean;
  seededRooms: number;
  rooms: number;
  messages: number;
}> {
  const columns = await rows(
    "SELECT COLUMN_NAME AS column_name,DATA_TYPE AS data_type,COLUMN_TYPE AS column_type,CHARACTER_MAXIMUM_LENGTH AS max_length,IS_NULLABLE AS is_nullable,COLUMN_DEFAULT AS column_default FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='tc_messages' AND COLUMN_NAME IN ('room','images')",
    [],
    db
  );
  const room = columns.find(column => column.column_name === "room");
  const images = columns.find(column => column.column_name === "images");
  const legacyEnum =
    room?.data_type === "enum" &&
    room.column_type === "enum('general','world','creators')";
  const correctVarchar =
    room?.data_type === "varchar" && Number(room.max_length) === 64;
  if (
    (!legacyEnum && !correctVarchar) ||
    room?.is_nullable !== "NO" ||
    room.column_default != null
  )
    throw new Error(
      "Chat room column has an unexpected schema; no data changed"
    );
  if (
    images?.data_type !== "json" ||
    images.is_nullable !== "NO" ||
    images.column_default == null
  )
    throw new Error("Chat images v2 schema is required; no data changed");

  const sql = await readFile(
    fileURLToPath(new URL("./migrations/003_chat_rooms.sql", import.meta.url)),
    "utf8"
  );
  for (const statement of sql
    .split(";")
    .map(s => s.trim())
    .filter(Boolean))
    await db.query(statement);
  if (legacyEnum)
    await db.query(
      "ALTER TABLE tc_messages MODIFY COLUMN room VARCHAR(64) NOT NULL"
    );
  let seededRooms = 0;
  for (const room of DEFAULT_CHAT_ROOMS) {
    // Never overwrite names, descriptions or room state after an interrupted/repeated setup.
    seededRooms += (
      await execute(
        "INSERT IGNORE INTO tc_rooms (id,name,description,creator_id,creator_name,is_default,closed) VALUES (?,?,?,0,'테란 관리자',TRUE,FALSE)",
        [room.id, room.name, room.description],
        db
      )
    ).affectedRows;
  }
  const orphaned = await rows(
    "SELECT COUNT(*) AS count FROM tc_messages m LEFT JOIN tc_rooms r ON r.id=m.room WHERE r.id IS NULL",
    [],
    db
  );
  if (Number(orphaned[0].count) !== 0)
    throw new Error("Messages reference missing rooms; readiness not marked");
  await execute(
    "INSERT IGNORE INTO tc_versions (version) VALUES (?)",
    [CHAT_ROOMS_VERSION],
    db
  );
  const counts = (
    await rows(
      "SELECT (SELECT COUNT(*) FROM tc_rooms) AS rooms,(SELECT COUNT(*) FROM tc_messages) AS messages",
      [],
      db
    )
  )[0];
  return {
    widenedColumn: legacyEnum,
    seededRooms,
    rooms: Number(counts.rooms),
    messages: Number(counts.messages),
  };
}
