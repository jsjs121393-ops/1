import "dotenv/config";
import { getCommunityPool, rows, closeCommunityPool } from "./database";
import { hashToken } from "./security";
import {
  applyChatImagesMigration,
  CHAT_IMAGES_VERSION,
} from "./chat-images-migration";

async function upgradeChat(): Promise<void> {
  const db = await getCommunityPool().getConnection();
  let lockName = "";
  let locked = false;
  try {
    const names = await rows("SELECT DATABASE() AS name", [], db);
    lockName = `tc-setup-${hashToken(String(names[0].name)).slice(0, 40)}`;
    const lock = await rows(
      "SELECT GET_LOCK(?,30) AS acquired",
      [lockName],
      db
    );
    if (Number(lock[0].acquired) !== 1)
      throw new Error("Could not acquire community setup lock");
    locked = true;
    const result = await applyChatImagesMigration(db);
    console.log(
      "Chat images migration:",
      JSON.stringify({ version: CHAT_IMAGES_VERSION, ...result })
    );
  } finally {
    try {
      if (locked)
        await rows("SELECT RELEASE_LOCK(?) AS released", [lockName], db);
    } finally {
      db.release();
      await closeCommunityPool();
    }
  }
}

upgradeChat().catch(async error => {
  await closeCommunityPool().catch(() => undefined);
  // Never log credentials, DSNs, message text, bound values or administrator secrets.
  console.error(
    "Chat upgrade failed:",
    (error as { code?: string; name?: string }).code ?? (error as Error).name
  );
  process.exitCode = 1;
});
