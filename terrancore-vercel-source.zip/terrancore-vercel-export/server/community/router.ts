import express, {
  type Request,
  type Response,
  type NextFunction,
} from "express";
import { randomUUID, timingSafeEqual } from "node:crypto";
import { z } from "zod";
import { storagePut } from "../storage";
import { rows, execute, transaction, checkReady } from "./database";
import {
  resolveIdentity,
  requireActor,
  requireAdmin,
  rateLimit,
  ADMIN_COOKIE,
  ADMIN_SESSION_MS,
  adminCookieOptions,
  type Identity,
} from "./auth";
import { bootstrap, adminData, getMessages } from "./reads";
import * as content from "./content";
import { getRooms, createRoom, updateRoom } from "./rooms";
import {
  ApiError,
  assertMutationHeader,
  parse,
  idParam,
  hashToken,
  newToken,
  hashPassword,
  verifyPassword,
  validateImage,
  workSchema,
  episodeSchema,
  postSchema,
  commentSchema,
  chatSchema,
  roomSchema,
  roomCreateSchema,
  roomUpdateSchema,
  profileSchema,
  loginSchema,
  passwordSchema,
  moderateSchema,
  memberSchema,
  uploadSchema,
} from "./security";

const router = express.Router();
const identities = new WeakMap<Request, Identity>();
const identity = (req: Request) => identities.get(req)!;
const ip = (req: Request) => req.ip || req.socket.remoteAddress || "unknown";
const handle =
  (handler: (req: Request, res: Response) => Promise<unknown>) =>
  (req: Request, res: Response, next: NextFunction) => {
    void handler(req, res).catch(next);
  };
const patch = <T extends z.ZodRawShape>(schema: z.ZodObject<T>) =>
  schema
    .partial()
    .refine(
      value => Object.keys(value).length > 0,
      "수정할 내용을 입력해 주세요."
    );

router.use((_req, res, next) => {
  res.set("Cache-Control", "private, no-store");
  next();
});
router.use((req, _res, next) => {
  try {
    if (!["GET", "HEAD", "OPTIONS"].includes(req.method))
      assertMutationHeader(req.get("X-Terran-Client"));
    next();
  } catch (error) {
    next(error);
  }
});
router.use(express.json({ limit: "15mb", strict: true }));
router.use((req, res, next) => {
  void (async () => {
    await checkReady();
    if (!["GET", "HEAD", "OPTIONS"].includes(req.method))
      await rateLimit("mutation-ip", ip(req), 300, 60, res);
    const actor = await resolveIdentity(req);
    identities.set(req, actor);
    if (
      !["GET", "HEAD", "OPTIONS"].includes(req.method) &&
      !req.path.startsWith("/admin/login")
    ) {
      if (actor.user || actor.admin)
        await rateLimit(
          "identity-write",
          actor.user ? `member:${actor.user.id}` : `admin:${actor.adminId}`,
          120,
          60,
          res
        );
    }
  })().then(() => next(), next);
});

router.get(
  "/bootstrap",
  handle(async (req, res) => res.json(await bootstrap(identity(req))))
);
router.get(
  "/rooms",
  handle(async (_req, res) => res.json(await getRooms()))
);
router.post(
  "/rooms",
  handle(async (req, res) => {
    const value = parse(roomCreateSchema, req.body);
    const actor = await requireActor(identity(req));
    await rateLimit(
      "room-create",
      actor.user ? `member:${actor.user.id}` : `admin:${actor.adminId}`,
      10,
      3600,
      res
    );
    res.json(await createRoom(value, identity(req)));
  })
);
router.patch(
  "/rooms/:id",
  handle(async (req, res) => {
    res.json(
      await updateRoom(
        parse(roomSchema, req.params.id),
        parse(roomUpdateSchema, req.body),
        identity(req)
      )
    );
  })
);
router.get(
  "/chat",
  handle(async (req, res) =>
    res.json(
      await getMessages(
        req.query.room === undefined
          ? undefined
          : parse(roomSchema, req.query.room)
      )
    )
  )
);
router.post(
  "/works",
  handle(async (req, res) =>
    res.json(
      await content.createWork(parse(workSchema, req.body), identity(req))
    )
  )
);
router.patch(
  "/works/:id",
  handle(async (req, res) =>
    res.json(
      await content.updateWork(
        idParam(req.params.id),
        parse(patch(workSchema), req.body),
        identity(req)
      )
    )
  )
);
router.delete(
  "/works/:id",
  handle(async (req, res) =>
    res.json(await content.deleteWork(idParam(req.params.id), identity(req)))
  )
);
router.post(
  "/works/:id/episodes",
  handle(async (req, res) =>
    res.json(
      await content.createEpisode(
        idParam(req.params.id),
        parse(episodeSchema, req.body),
        identity(req)
      )
    )
  )
);
router.patch(
  "/episodes/:id",
  handle(async (req, res) =>
    res.json(
      await content.updateEpisode(
        idParam(req.params.id),
        parse(patch(episodeSchema), req.body),
        identity(req)
      )
    )
  )
);
router.delete(
  "/episodes/:id",
  handle(async (req, res) =>
    res.json(
      await content.updateEpisode(idParam(req.params.id), null, identity(req))
    )
  )
);
router.post(
  "/posts",
  handle(async (req, res) =>
    res.json(
      await content.createPost(parse(postSchema, req.body), identity(req))
    )
  )
);
router.patch(
  "/posts/:id",
  handle(async (req, res) =>
    res.json(
      await content.updatePost(
        idParam(req.params.id),
        parse(patch(postSchema), req.body),
        identity(req)
      )
    )
  )
);
router.delete(
  "/posts/:id",
  handle(async (req, res) =>
    res.json(
      await content.updatePost(idParam(req.params.id), null, identity(req))
    )
  )
);
router.post(
  "/posts/:id/comments",
  handle(async (req, res) =>
    res.json(
      await content.createComment(
        idParam(req.params.id),
        parse(commentSchema, req.body).body,
        identity(req)
      )
    )
  )
);
router.patch(
  "/comments/:id",
  handle(async (req, res) =>
    res.json(
      await content.updateComment(
        idParam(req.params.id),
        parse(commentSchema, req.body).body,
        identity(req)
      )
    )
  )
);
router.delete(
  "/comments/:id",
  handle(async (req, res) =>
    res.json(
      await content.deleteAuthored(
        "comment",
        idParam(req.params.id),
        identity(req)
      )
    )
  )
);
router.post(
  "/chat",
  handle(async (req, res) => {
    const value = parse(chatSchema, req.body);
    res.json(
      await content.createMessage(
        value.room,
        value.body,
        identity(req),
        value.images
      )
    );
  })
);
router.delete(
  "/chat/:id",
  handle(async (req, res) =>
    res.json(
      await content.deleteAuthored(
        "message",
        idParam(req.params.id),
        identity(req)
      )
    )
  )
);

router.patch(
  "/profile",
  handle(async (req, res) => {
    const actor = await requireActor(identity(req));
    if (!actor.user)
      throw new ApiError(401, "회원 프로필은 Manus 계정 로그인이 필요합니다.");
    const value = parse(profileSchema, req.body);
    await execute(
      "INSERT INTO tc_profiles (user_id,name) VALUES (?,?) ON DUPLICATE KEY UPDATE name=VALUES(name)",
      [actor.user.id, value.name]
    );
    res.json({ success: true });
  })
);
router.post(
  "/upload",
  handle(async (req, res) => {
    const actor = await requireActor(identity(req));
    await rateLimit(
      "upload",
      actor.user ? `member:${actor.user.id}` : `admin:${actor.adminId}`,
      12,
      60,
      res
    );
    const value = parse(uploadSchema, req.body);
    const { buffer, extension } = validateImage(value.type, value.data);
    const uploaded = await storagePut(
      `community/uploads/${randomUUID()}.${extension}`,
      buffer,
      value.type
    );
    // Never store caller-supplied filenames or arbitrary URLs as managed files.
    await execute(
      "INSERT INTO tc_uploads (url,url_hash,storage_key,owner_id,admin_owned,content_type,byte_size) VALUES (?,?,?,?,?,?,?)",
      [
        uploaded.url,
        hashToken(uploaded.url),
        uploaded.key,
        actor.authorId,
        actor.authorId === 0,
        value.type,
        buffer.length,
      ]
    );
    res.json({ url: uploaded.url });
  })
);

router.post(
  "/admin/login",
  handle(async (req, res) => {
    await rateLimit("admin-login", ip(req), 8, 15 * 60, res);
    const value = parse(loginSchema, req.body);
    const records = await rows(
      "SELECT id,password_hash FROM tc_admin_accounts WHERE username=?",
      [value.username]
    );
    const valid = await verifyPassword(
      value.password,
      records[0]?.password_hash
    );
    if (!valid || !records[0])
      throw new ApiError(
        401,
        "관리자 아이디 또는 비밀번호가 올바르지 않습니다."
      );
    const token = newToken();
    await transaction(async db => {
      // Serialize login with password rotation so an old password cannot create a fresh session.
      const account = await rows(
        "SELECT password_hash FROM tc_admin_accounts WHERE id=? FOR UPDATE",
        [records[0].id],
        db
      );
      if (account[0]?.password_hash !== records[0].password_hash)
        throw new ApiError(
          401,
          "비밀번호가 변경되었습니다. 다시 로그인해 주세요."
        );
      await execute(
        "DELETE FROM tc_admin_sessions WHERE expires_at <= UTC_TIMESTAMP()",
        [],
        db
      );
      await execute(
        "INSERT INTO tc_admin_sessions (token_hash,admin_id,expires_at) VALUES (?,?,DATE_ADD(UTC_TIMESTAMP(), INTERVAL 7 DAY))",
        [hashToken(token), records[0].id],
        db
      );
    });
    res.cookie(ADMIN_COOKIE, token, adminCookieOptions);
    res.json({ success: true, token });
  })
);
router.post(
  "/admin/logout",
  handle(async (req, res) => {
    const actor = identity(req);
    if (actor.sessionHash)
      await execute("DELETE FROM tc_admin_sessions WHERE token_hash=?", [
        actor.sessionHash,
      ]);
    res.clearCookie(ADMIN_COOKIE, {
      httpOnly: true,
      secure: true,
      sameSite: "none",
      path: "/api/community",
    });
    res.json({ success: true });
  })
);
router.post(
  "/admin/password",
  handle(async (req, res) => {
    const actor = identity(req);
    requireAdmin(actor);
    await rateLimit("admin-password", String(actor.adminId), 5, 15 * 60, res);
    const value = parse(passwordSchema, req.body);
    if (
      timingSafeEqual(
        Buffer.from(hashToken(value.currentPassword), "hex"),
        Buffer.from(hashToken(value.newPassword), "hex")
      )
    )
      throw new ApiError(400, "기존 비밀번호와 다른 비밀번호를 입력해 주세요.");
    const nextHash = await hashPassword(value.newPassword);
    await transaction(async db => {
      const account = await rows(
        "SELECT password_hash FROM tc_admin_accounts WHERE id=? FOR UPDATE",
        [actor.adminId],
        db
      );
      if (
        !(await verifyPassword(
          value.currentPassword,
          account[0]?.password_hash
        ))
      )
        throw new ApiError(401, "현재 비밀번호가 올바르지 않습니다.");
      const session = await rows(
        "SELECT token_hash FROM tc_admin_sessions WHERE token_hash=? AND admin_id=? AND expires_at>UTC_TIMESTAMP()",
        [actor.sessionHash, actor.adminId],
        db
      );
      if (!session[0]) throw new ApiError(401, "관리자 세션이 만료되었습니다.");
      await execute(
        "UPDATE tc_admin_accounts SET password_hash=? WHERE id=?",
        [nextHash, actor.adminId],
        db
      );
      await execute(
        "DELETE FROM tc_admin_sessions WHERE admin_id=? AND token_hash<>?",
        [actor.adminId, actor.sessionHash],
        db
      );
    });
    res.json({ success: true });
  })
);
router.get(
  "/admin/data",
  handle(async (req, res) => {
    requireAdmin(identity(req));
    res.json(await adminData());
  })
);
router.get(
  "/admin/rooms",
  handle(async (req, res) => {
    requireAdmin(identity(req));
    res.json(await getRooms(true));
  })
);
router.post(
  "/admin/moderate",
  handle(async (req, res) => {
    const actor = identity(req);
    requireAdmin(actor);
    const value = parse(moderateSchema, req.body);
    res.json(
      await content.moderate(
        value.entity,
        value.id,
        value.action,
        actor.adminId
      )
    );
  })
);
router.post(
  "/admin/member",
  handle(async (req, res) => {
    const actor = identity(req);
    requireAdmin(actor);
    const value = parse(memberSchema, req.body);
    await transaction(async db => {
      const users = await rows(
        "SELECT id FROM users WHERE id=? FOR UPDATE",
        [value.id],
        db
      );
      if (!users.length) throw new ApiError(404, "회원을 찾을 수 없습니다.");
      await execute(
        "INSERT INTO tc_member_moderation (user_id,banned) VALUES (?,?) ON DUPLICATE KEY UPDATE banned=VALUES(banned)",
        [value.id, value.banned],
        db
      );
      await execute(
        "INSERT INTO tc_moderation_log (admin_id,entity,entity_id,action) VALUES (?,'member',?,?)",
        [actor.adminId, value.id, value.banned ? "ban" : "unban"],
        db
      );
    });
    res.json({ success: true });
  })
);
router.use((_req, _res, next) =>
  next(new ApiError(404, "API 경로를 찾을 수 없습니다."))
);
router.use(
  (error: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (res.headersSent) return;
    if (error instanceof ApiError) {
      res.status(error.status).json({ error: error.message });
      return;
    }
    const typed = error as { type?: string; code?: string; name?: string };
    if (typed.type === "entity.too.large") {
      res.status(413).json({ error: "요청 크기가 너무 큽니다." });
      return;
    }
    if (
      typed.type === "entity.parse.failed" ||
      typed.type === "encoding.unsupported" ||
      typed.type === "charset.unsupported"
    ) {
      res.status(400).json({ error: "올바른 JSON 요청이 필요합니다." });
      return;
    }
    if (typed.code === "ER_DUP_ENTRY") {
      res.status(409).json({
        error: "이미 사용 중인 값입니다. 회차 번호 등을 확인해 주세요.",
      });
      return;
    }
    if (
      typed.code === "ER_LOCK_DEADLOCK" ||
      typed.code === "ER_LOCK_WAIT_TIMEOUT"
    ) {
      res.status(503).json({
        error: "동시 요청으로 처리하지 못했습니다. 다시 시도해 주세요.",
      });
      return;
    }
    console.error(
      "[Community] Request failed",
      typed.code ?? typed.name ?? "UnknownError"
    );
    res.status(500).json({
      error: "서버에서 요청을 처리하지 못했습니다. 잠시 후 다시 시도해 주세요.",
    });
  }
);
export const communityRouter = router;
