import { beforeEach, describe, expect, it, vi } from "vitest";
import type { Database } from "./database";

const mocks = vi.hoisted(() => ({ rows: vi.fn(), execute: vi.fn() }));
vi.mock("./database", () => ({ rows: mocks.rows, execute: mocks.execute }));
import {
  applyChatImagesMigration,
  CHAT_IMAGES_VERSION,
} from "./chat-images-migration";

const query = vi.fn();
const db = { query } as unknown as Database;
let columns: any[];
let invalidRows: number;

beforeEach(() => {
  vi.clearAllMocks();
  columns = [];
  invalidRows = 0;
  query.mockResolvedValue([]);
  mocks.execute.mockResolvedValue({ affectedRows: 0 });
  mocks.rows.mockImplementation(async (sql: string) => {
    if (sql.includes("information_schema.COLUMNS")) return columns;
    if (sql.includes("JSON_TYPE")) return [{ count: invalidRows }];
    return [{ count: 2 }];
  });
});

describe("chat image migration (mock database only)", () => {
  it("adds the column once with the default for old rows and marks the schema", async () => {
    const result = await applyChatImagesMigration(db);
    expect(result).toEqual({
      addedColumn: true,
      initializedRows: 2,
      backfilledRows: 0,
      messages: 2,
    });
    expect(query).toHaveBeenCalledTimes(2);
    expect(query.mock.calls[0][0]).toContain("ADD COLUMN images JSON NULL");
    expect(query.mock.calls[1][0]).toBe(
      "ALTER TABLE tc_messages MODIFY COLUMN images JSON NOT NULL DEFAULT (JSON_ARRAY())"
    );
    expect(mocks.execute).toHaveBeenCalledWith(
      "INSERT IGNORE INTO tc_versions (version) VALUES (?)",
      [CHAT_IMAGES_VERSION],
      db
    );
  });
  it("is a DDL no-op for an already-correct existing column", async () => {
    columns = [
      { data_type: "json", is_nullable: "NO", column_default: "json_array()" },
    ];
    expect((await applyChatImagesMigration(db)).addedColumn).toBe(false);
    expect(query).not.toHaveBeenCalled();
    expect(mocks.execute.mock.calls[0][0]).toBe(
      "UPDATE tc_messages SET images=JSON_ARRAY() WHERE images IS NULL"
    );
  });
  it("recovers a nullable partial migration without replacing populated arrays", async () => {
    columns = [{ data_type: "json", is_nullable: "YES", column_default: null }];
    mocks.execute.mockResolvedValue({ affectedRows: 2 });
    expect((await applyChatImagesMigration(db)).backfilledRows).toBe(2);
    expect(query).toHaveBeenCalledWith(
      "ALTER TABLE tc_messages MODIFY COLUMN images JSON NOT NULL DEFAULT (JSON_ARRAY())"
    );
    expect(mocks.execute.mock.calls[0][0]).toContain("WHERE images IS NULL");
  });
  it("refuses an unexpected column type without changing data", async () => {
    columns = [{ data_type: "text", is_nullable: "NO", column_default: null }];
    await expect(applyChatImagesMigration(db)).rejects.toThrow(
      "unexpected type"
    );
    expect(mocks.execute).not.toHaveBeenCalled();
    expect(query).not.toHaveBeenCalled();
  });
  it("does not mark readiness when attachments contain a non-array value", async () => {
    columns = [
      { data_type: "json", is_nullable: "NO", column_default: "json_array()" },
    ];
    invalidRows = 1;
    await expect(applyChatImagesMigration(db)).rejects.toThrow("non-array");
    expect(
      mocks.execute.mock.calls.some(([sql]) => sql.includes("tc_versions"))
    ).toBe(false);
  });
});
