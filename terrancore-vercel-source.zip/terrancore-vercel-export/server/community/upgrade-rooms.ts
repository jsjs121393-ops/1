import "dotenv/config";
import {
  getCommunityPool,
  rows,
  closeCommunityPool,
  type Database,
} from "./database";
import { hashToken } from "./security";
import {
  applyChatRoomsMigration,
  CHAT_ROOMS_VERSION,
} from "./chat-rooms-migration";

async function snapshot(db: Database) {
  const messages = await rows("SELECT * FROM tc_messages ORDER BY id", [], db);
  const counts = (
    await rows(
      "SELECT (SELECT COUNT(*) FROM users) AS members,(SELECT COUNT(*) FROM tc_works) AS works,(SELECT COUNT(*) FROM tc_episodes) AS episodes,(SELECT COUNT(*) FROM tc_posts) AS posts,(SELECT COUNT(*) FROM tc_comments) AS comments,(SELECT COUNT(*) FROM tc_uploads) AS uploads",
      [],
      db
    )
  )[0];
  return {
    messageCount: messages.length,
    messageDigest: hashToken(JSON.stringify(messages)),
    counts,
  };
}

async function upgradeRooms(): Promise<void> {
  const db = await getCommunityPool().getConnection();
  let lockName = "";
  let locked = false;
  try {
    const names = await rows("SELECT DATABASE() AS name", [], db);
    lockName = `tc-setup-${hashToken(String(names[0].name)).slice(0, 40)}`;
    const lock = await rows(
      "SELECT GET_LOCK(?,30) AS acquired",
      [lockName],
      db
    );
    if (Number(lock[0].acquired) !== 1)
      throw new Error("Could not acquire community setup lock");
    locked = true;
    const before = await snapshot(db);
    const result = await applyChatRoomsMigration(db);
    const after = await snapshot(db);
    const messagesUnchanged = before.messageDigest === after.messageDigest;
    const contentCountsUnchanged =
      JSON.stringify(before.counts) === JSON.stringify(after.counts);
    if (!messagesUnchanged || !contentCountsUnchanged)
      throw new Error(
        "Concurrent content changes detected; inspect before declaring preservation"
      );
    const rooms = await rows(
      "SELECT id,name,is_default,closed FROM tc_rooms ORDER BY id",
      [],
      db
    );
    console.log(
      "Chat rooms migration:",
      JSON.stringify({
        version: CHAT_ROOMS_VERSION,
        ...result,
        messagesUnchanged,
        contentCountsUnchanged,
        contentCounts: after.counts,
        roomRecords: rooms,
      })
    );
  } finally {
    try {
      if (locked)
        await rows("SELECT RELEASE_LOCK(?) AS released", [lockName], db);
    } finally {
      db.release();
      await closeCommunityPool();
    }
  }
}

upgradeRooms().catch(async error => {
  await closeCommunityPool().catch(() => undefined);
  // Never print DSNs, SQL values, message bodies, session tokens or admin secrets.
  console.error(
    "Chat rooms upgrade failed:",
    (error as { code?: string; name?: string }).code ?? (error as Error).name
  );
  process.exitCode = 1;
});
