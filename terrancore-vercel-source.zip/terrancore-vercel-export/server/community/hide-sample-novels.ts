import "dotenv/config";
import { transaction, rows, execute, closeCommunityPool } from "./database";

const titles = ["테란: 마지막 함대", "제국의 잔해"];
const scope = "kind='novel' AND sample=TRUE AND author_id=0 AND title IN (?,?)";

async function hideSampleNovels(): Promise<void> {
  const result = await transaction(async db => {
    const samples = await rows(
      `SELECT id,title,hidden FROM tc_works WHERE ${scope} ORDER BY id FOR UPDATE`,
      titles,
      db
    );
    const visibleTitles = samples
      .filter(sample => !sample.hidden)
      .map(sample => sample.title);
    // Hide only these original sample novels. Never delete works or episodes,
    // and never change independent episode moderation states or user content.
    const update = await execute(
      `UPDATE tc_works SET hidden=TRUE WHERE ${scope} AND hidden=FALSE`,
      titles,
      db
    );
    if (update.affectedRows !== visibleTitles.length)
      throw new Error("Sample hide count mismatch; transaction rolled back");
    return { hiddenCount: update.affectedRows, titles: visibleTitles };
  });
  console.log("Hidden original sample novels:", JSON.stringify(result));
}

hideSampleNovels()
  .catch(error => {
    console.error(
      "Sample hiding failed:",
      (error as { code?: string; name?: string }).code ?? (error as Error).name
    );
    process.exitCode = 1;
  })
  .finally(() => closeCommunityPool());
