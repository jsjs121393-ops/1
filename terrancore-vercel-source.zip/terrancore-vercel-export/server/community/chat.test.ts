import { describe, expect, it } from "vitest";
import { chatSchema, parse, ApiError } from "./security";

const image = "/manus-storage/community/uploads/test.png";

describe("chat validation (pure; no managed DB writes)", () => {
  it("defaults old text-only requests to an empty attachment array", () => {
    expect(parse(chatSchema, { room: "general", body: " hello " })).toEqual({
      room: "general",
      body: "hello",
      images: [],
    });
  });
  it("allows image-only and mixed messages in all valid rooms", () => {
    for (const room of ["general", "world", "creators"])
      expect(parse(chatSchema, { room, body: "  ", images: [image] })).toEqual({
        room,
        body: "",
        images: [image],
      });
    expect(
      parse(chatSchema, {
        room: "general",
        body: "caption",
        images: Array(4).fill(image),
      }).images
    ).toHaveLength(4);
  });
  it("rejects empty messages, excessive text/images and invalid rooms", () => {
    for (const input of [
      { room: "general", body: "" },
      { room: "general", body: " \n\u0000 ", images: [] },
      { room: "general", body: "a".repeat(2001) },
      { room: "general", body: "", images: Array(5).fill(image) },
      { room: "invalid", body: "hello" },
      { room: "general", images: [image] },
      { room: "general", body: "hello", authorId: 99 },
    ])
      expect(() => parse(chatSchema, input)).toThrow(ApiError);
    expect(
      parse(chatSchema, { room: "general", body: "a".repeat(2000) }).body
    ).toHaveLength(2000);
  });
  it("requires every image path to be managed and nonempty", () => {
    for (const bad of [
      "",
      " ",
      "https://attacker.test/a.png",
      "/other/image.png",
      "/manus-storage/../image.png",
      "/manus-storage/a//image.png",
      "javascript:alert(1)",
    ])
      expect(() =>
        parse(chatSchema, { room: "general", body: "caption", images: [bad] })
      ).toThrow(ApiError);
    for (const images of [null, "not-an-array", [null], [42]])
      expect(() =>
        parse(chatSchema, { room: "general", body: "caption", images })
      ).toThrow(ApiError);
  });
});
