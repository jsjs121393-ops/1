import { describe, it, expect } from "vitest";
import {
  ApiError,
  assertMutationHeader,
  assertOwner,
  hashPassword,
  verifyPassword,
  hashToken,
  newToken,
  sanitizeName,
  parse,
  profileSchema,
  workSchema,
  idParam,
  validateImage,
  MAX_UPLOAD_BYTES,
  managedPath,
  passwordSchema,
} from "./security";

const png = Buffer.alloc(24);
Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]).copy(png);
png.write("IHDR", 12);

describe("community security (pure; no managed DB writes)", () => {
  it("requires the exact anti-CSRF client header", () => {
    expect(() => assertMutationHeader(undefined)).toThrow(ApiError);
    expect(() => assertMutationHeader("WEB")).toThrow(ApiError);
    expect(() => assertMutationHeader("web")).not.toThrow();
  });
  it("never grants ownership of sample or other members' work", () => {
    expect(() => assertOwner(2, 1, false)).toThrow();
    expect(() => assertOwner(1, 1, false, true)).toThrow();
    expect(() => assertOwner(0, 0, false)).toThrow();
    expect(() => assertOwner(2, 1, true, true)).not.toThrow();
  });
  it("uses salted scrypt and constant-sized digest comparisons", async () => {
    const password = "Test-only password#2026";
    const one = await hashPassword(password);
    const two = await hashPassword(password);
    expect(one).not.toEqual(two);
    expect(one).not.toContain(password);
    expect(await verifyPassword(password, one)).toBe(true);
    expect(await verifyPassword("wrong", one)).toBe(false);
    expect(await verifyPassword(password, "corrupt")).toBe(false);
    expect(await verifyPassword(password)).toBe(false);
  });
  it("generates opaque random tokens and stores only fixed hashes", () => {
    const token = newToken();
    expect(token).toMatch(/^[A-Za-z0-9_-]{43}$/);
    expect(hashToken(token)).toMatch(/^[a-f0-9]{64}$/);
    expect(newToken()).not.toEqual(token);
  });
  it("sanitizes profiles and enforces the 30-character limit", () => {
    expect(sanitizeName(" <b>테란</b>\u0000 ")).toEqual("테란");
    expect(
      parse(profileSchema, { name: "<script>닉네임</script>" }).name
    ).toEqual("닉네임");
    expect(() => parse(profileSchema, { name: "가".repeat(31) })).toThrow();
    expect(() => parse(profileSchema, { name: "", role: "admin" })).toThrow();
  });
  it("rejects remote, traversal, protocol-relative and unmanaged image URLs", () => {
    for (const url of [
      "https://attacker.test/a.png",
      "//attacker.test/a.png",
      "/manus-storage/../a.png",
      "/manus-storage/a//b",
      "javascript:alert(1)",
      "/other/a.png",
    ])
      expect(managedPath.safeParse(url).success).toBe(false);
    expect(
      managedPath.safeParse("/manus-storage/community/a.webp").success
    ).toBe(true);
  });
  it("validates MIME against magic bytes and strict Base64", () => {
    expect(validateImage("image/png", png.toString("base64")).extension).toBe(
      "png"
    );
    expect(() => validateImage("image/jpeg", png.toString("base64"))).toThrow();
    expect(() =>
      validateImage("image/svg+xml", Buffer.from("<svg/>").toString("base64"))
    ).toThrow();
    for (const data of [
      "",
      "%%%%",
      "data:image/png;base64,AAAA",
      "A===",
      "AAA",
    ])
      expect(() => validateImage("image/png", data)).toThrow();
    expect(
      validateImage(
        "image/gif",
        Buffer.from("GIF89a12345678").toString("base64")
      ).extension
    ).toBe("gif");
  });
  it("enforces exactly 10 MiB decoded maximum without regex stack exhaustion", () => {
    const image = Buffer.alloc(MAX_UPLOAD_BYTES);
    png.copy(image);
    expect(
      validateImage("image/png", image.toString("base64")).buffer.length
    ).toBe(MAX_UPLOAD_BYTES);
    expect(() =>
      validateImage(
        "image/png",
        Buffer.concat([image, Buffer.from([0])]).toString("base64")
      )
    ).toThrow();
  });
  it("rejects mass-assignment and invalid IDs", () => {
    const work = {
      kind: "novel",
      title: "작품",
      description: "",
      genre: "SF",
      cover: "",
      tags: [],
      status: "ongoing",
    };
    expect(() =>
      parse(workSchema, { ...work, sample: true, featured: true, authorId: 1 })
    ).toThrow();
    for (const id of ["0", "-1", "1 OR 1=1", "1.5", "2147483648"])
      expect(() => idParam(id)).toThrow();
    expect(idParam("1")).toBe(1);
  });
  it("accepts approved 8-character mixed passwords and rejects short or unmixed values", () => {
    const validate = (newPassword: string) =>
      passwordSchema.safeParse({
        currentPassword: "current-test-value",
        newPassword,
      }).success;
    expect(validate("Test#123")).toBe(true);
    expect(validate("Test#12")).toBe(false);
    expect(validate("abcdefgh")).toBe(false);
    expect(validate("12345678")).toBe(false);
    expect(validate("a".repeat(128) + "1")).toBe(false);
  });
});
