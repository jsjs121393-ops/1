import { randomBytes } from "node:crypto";
import type { z } from "zod";
import type { ChatRoom } from "../../shared/community";
import {
  rows,
  execute,
  transaction,
  type Database,
  type Row,
} from "./database";
import { iso, requireActor, type Identity } from "./auth";
import {
  ApiError,
  assertOwner,
  roomCreateSchema,
  roomUpdateSchema,
  parse,
} from "./security";

export const mapRoom = (r: Row): ChatRoom => ({
  id: r.id,
  name: r.name,
  description: r.description,
  creatorId: Number(r.creator_id),
  creator: r.creator_name,
  createdAt: iso(r.created_at),
  isDefault: Boolean(r.is_default),
  closed: Boolean(r.closed),
  messageCount: Number(r.message_count ?? 0),
});

const roomSelect = (all = false) =>
  `r.*, (SELECT COUNT(*) FROM tc_messages m WHERE m.room=r.id${all ? "" : " AND m.hidden=FALSE"}) AS message_count`;

export async function getRooms(
  all = false,
  db?: Database
): Promise<ChatRoom[]> {
  const result = await rows(
    `SELECT ${roomSelect(all)} FROM tc_rooms r ${all ? "" : "WHERE r.closed=FALSE"} ORDER BY r.is_default DESC,r.created_at DESC,r.id DESC`,
    [],
    db
  );
  return result.map(mapRoom);
}

async function getRoom(id: string, db: Database): Promise<ChatRoom> {
  const result = await rows(
    `SELECT ${roomSelect()} FROM tc_rooms r WHERE r.id=?`,
    [id],
    db
  );
  if (!result[0]) throw new ApiError(404, "채팅방을 찾을 수 없습니다.");
  return mapRoom(result[0]);
}

// Call inside a transaction: serializes message insertion/room reads with closing.
export async function requireOpenRoom(id: string, db: Database): Promise<Row> {
  const result = await rows(
    "SELECT * FROM tc_rooms WHERE id=? FOR UPDATE",
    [id],
    db
  );
  if (!result[0]) throw new ApiError(404, "채팅방을 찾을 수 없습니다.");
  if (result[0].closed) throw new ApiError(409, "닫힌 채팅방입니다.");
  return result[0];
}

export async function createRoom(
  input: z.infer<typeof roomCreateSchema>,
  identity: Identity
): Promise<ChatRoom> {
  const value = parse(roomCreateSchema, input);
  return transaction(async db => {
    const actor = await requireActor(identity, db);
    const id = `room_${randomBytes(6).toString("hex")}`;
    await execute(
      "INSERT INTO tc_rooms (id,name,description,creator_id,creator_name) VALUES (?,?,?,?,?)",
      [id, value.name, value.description, actor.authorId, actor.author],
      db
    );
    return getRoom(id, db);
  });
}

export async function updateRoom(
  id: string,
  input: z.infer<typeof roomUpdateSchema>,
  identity: Identity
): Promise<ChatRoom> {
  const value = parse(roomUpdateSchema, input);
  return transaction(async db => {
    const actor = await requireActor(identity, db);
    const result = await rows(
      "SELECT * FROM tc_rooms WHERE id=? FOR UPDATE",
      [id],
      db
    );
    const room = result[0];
    if (!room) throw new ApiError(404, "채팅방을 찾을 수 없습니다.");
    if (room.is_default)
      throw new ApiError(409, "기본 채팅방은 수정하거나 닫을 수 없습니다.");
    assertOwner(Number(room.creator_id), actor.authorId, actor.admin);
    await execute(
      "UPDATE tc_rooms SET name=?,description=?,closed=? WHERE id=?",
      [
        value.name ?? room.name,
        value.description ?? room.description,
        value.closed ?? Boolean(room.closed),
        id,
      ],
      db
    );
    return getRoom(id, db);
  });
}
