-- Additive chat attachments. Run through upgrade-chat.ts or setup.ts.
-- TiDB 8.5 rejects expression-default ADD COLUMN and JSON SET DEFAULT.
-- The helper adds a nullable column, backfills only SQL NULLs to [], then
-- uses MODIFY COLUMN to install NOT NULL DEFAULT (JSON_ARRAY()) before readiness.
ALTER TABLE tc_messages ADD COLUMN images JSON NULL AFTER body;
