-- Additive only. The inspect-first helper widens tc_messages.room separately.
CREATE TABLE IF NOT EXISTS tc_rooms (
  id VARCHAR(64) NOT NULL PRIMARY KEY,
  name VARCHAR(40) NOT NULL,
  description VARCHAR(200) NOT NULL DEFAULT '',
  creator_id INT NOT NULL,
  creator_name VARCHAR(120) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  is_default BOOLEAN NOT NULL DEFAULT FALSE,
  closed BOOLEAN NOT NULL DEFAULT FALSE,
  INDEX tc_room_visible (closed, is_default, created_at),
  INDEX tc_room_creator (creator_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
