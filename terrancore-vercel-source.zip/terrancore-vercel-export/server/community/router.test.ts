import {
  afterAll,
  beforeAll,
  beforeEach,
  describe,
  expect,
  it,
  vi,
} from "vitest";
import express from "express";
import { createServer, type Server } from "node:http";
import { ApiError, hashPassword, hashToken, newToken } from "./security";
import { ForbiddenError } from "../../shared/_core/errors";

const state = vi.hoisted(() => ({
  user: null as any,
  authError: null as any,
  dbFailure: false,
  banned: false,
  adminHash: "",
  adminTokenHash: "",
  work: null as any,
  rateHits: 1,
}));
const mocks = vi.hoisted(() => ({
  rows: vi.fn(),
  execute: vi.fn(),
  checkReady: vi.fn(),
  sdk: vi.fn(),
  storage: vi.fn(),
}));
vi.mock("../_core/sdk", () => ({ sdk: { authenticateRequest: mocks.sdk } }));
vi.mock("../storage", () => ({ storagePut: mocks.storage }));
vi.mock("./database", () => ({
  rows: mocks.rows,
  execute: mocks.execute,
  checkReady: mocks.checkReady,
  transaction: async (run: (db: any) => Promise<any>) => run({ mocked: true }),
}));
import { communityRouter } from "./router";
import { requireAdmin } from "./auth";

const testPassword = "Test only strong pass#2026";
let server: Server;
let base: string;
async function request(
  path: string,
  method = "GET",
  body?: unknown,
  headers: Record<string, string> = {}
) {
  const response = await fetch(`${base}${path}`, {
    method,
    headers: {
      ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
      ...headers,
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return { response, body: await response.json() };
}
const member = () => {
  state.user = {
    id: 42,
    name: "진짜 회원",
    email: "member@example.test",
    role: "admin",
    createdAt: new Date("2026-01-01T00:00:00Z"),
    openId: "test-real-oauth",
  };
  return {
    Authorization: "Bearer test-member-token",
    "X-Terran-Client": "web",
  };
};
const admin = () => {
  const token = newToken();
  state.adminTokenHash = hashToken(token);
  return { "X-Terran-Admin": token, "X-Terran-Client": "web" };
};
const workBody = {
  kind: "novel",
  title: "새 작품",
  description: "소설 설명",
  genre: "SF",
  cover: "",
  tags: ["우주"],
  status: "ongoing",
};

beforeAll(async () => {
  const app = express();
  app.use("/api/community", communityRouter);
  server = createServer(app);
  await new Promise<void>(resolve => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  if (!address || typeof address === "string")
    throw new Error("Test listener unavailable");
  base = `http://127.0.0.1:${address.port}/api/community`;
});
afterAll(async () => {
  server.closeAllConnections();
  await new Promise<void>((resolve, reject) =>
    server.close(error => (error ? reject(error) : resolve()))
  );
});
beforeEach(async () => {
  vi.clearAllMocks();
  Object.assign(state, {
    user: null,
    authError: null,
    dbFailure: false,
    banned: false,
    adminHash: await hashPassword(testPassword),
    adminTokenHash: "",
    work: null,
    rateHits: 1,
  });
  mocks.checkReady.mockImplementation(async () => {
    if (state.dbFailure) throw new Error("mock database outage");
  });
  mocks.sdk.mockImplementation(async () => {
    if (state.authError) throw state.authError;
    if (!state.user) throw ForbiddenError("invalid test session");
    return state.user;
  });
  mocks.execute.mockResolvedValue({ insertId: 41, affectedRows: 1 });
  mocks.storage.mockResolvedValue({
    key: "community/test.png",
    url: "/manus-storage/community/test.png",
  });
  mocks.rows.mockImplementation(async (sql: string, values: unknown[] = []) => {
    if (sql.includes("FROM tc_rate_limits"))
      return [{ hits: state.rateHits, retry: 60 }];
    if (sql.includes("FROM tc_admin_sessions"))
      return values[0] && values[0] === state.adminTokenHash
        ? [{ admin_id: 1, token_hash: state.adminTokenHash }]
        : [];
    if (sql.includes("FROM tc_admin_accounts"))
      return sql.includes("username=?") && values[0] !== "admin"
        ? []
        : [{ id: 1, password_hash: state.adminHash }];
    if (sql.includes("SELECT p.name, COALESCE"))
      return state.user ? [{ name: "진짜 회원", banned: state.banned }] : [];
    if (sql.includes("SELECT banned FROM tc_member_moderation"))
      return [{ banned: state.banned }];
    if (sql.includes("AS members"))
      return [{ members: 0, works: 0, posts: 0, messages: 0 }];
    if (sql.includes("SELECT * FROM tc_rooms WHERE"))
      return ["general", "world", "creators"].includes(String(values[0]))
        ? [
            {
              id: values[0],
              name: "기본 방",
              creator_id: 0,
              closed: false,
              is_default: true,
            },
          ]
        : [];
    if (sql.includes("SELECT * FROM tc_works WHERE"))
      return state.work ? [state.work] : [];
    return [];
  });
});

describe("community REST (mocked database/OAuth/storage only)", () => {
  it("returns exact logged-out bootstrap with real count fields and empty chat", async () => {
    const result = await request("/bootstrap");
    expect(result.response.status).toBe(200);
    expect(result.body).toEqual({
      user: null,
      admin: false,
      works: [],
      posts: [],
      messages: [],
      stats: { members: 0, works: 0, posts: 0, messages: 0 },
    });
    expect(result.response.headers.get("cache-control")).toContain("no-store");
  });
  it("returns database failure as JSON 500, never blank success", async () => {
    state.dbFailure = true;
    const result = await request("/bootstrap");
    expect(result.response.status).toBe(500);
    expect(typeof result.body.error).toBe("string");
    expect(result.body.works).toBeUndefined();
  });
  it("treats invalid OAuth as logged out", async () => {
    state.authError = ForbiddenError("invalid JWT");
    const result = await request("/bootstrap", "GET", undefined, {
      Authorization: "Bearer invalid",
    });
    expect(result.response.status).toBe(200);
    expect(result.body.user).toBeNull();
  });
  it("does not derive administrator privilege from a Manus user role", async () => {
    const headers = member();
    const result = await request("/bootstrap", "GET", undefined, headers);
    expect(result.body.user.id).toBe(42);
    expect(result.body.user.role).toBe("user");
    expect(result.body.admin).toBe(false);
    expect(
      (await request("/admin/data", "GET", undefined, headers)).response.status
    ).toBe(403);
    expect(() =>
      requireAdmin({
        user: state.user,
        admin: false,
        adminId: null,
        sessionHash: null,
      })
    ).toThrow(ApiError);
  });
  it("requires CSRF header before any database operation", async () => {
    const result = await request("/works", "POST", workBody);
    expect(result.response.status).toBe(403);
    expect(mocks.checkReady).not.toHaveBeenCalled();
    expect(mocks.execute).not.toHaveBeenCalled();
    expect(
      result.response.headers.get("access-control-allow-origin")
    ).toBeNull();
  });
  it("denies logged-out content creation", async () => {
    const result = await request("/works", "POST", workBody, {
      "X-Terran-Client": "web",
    });
    expect(result.response.status).toBe(401);
    expect(
      mocks.execute.mock.calls.some(([sql]) =>
        sql.includes("INSERT INTO tc_works")
      )
    ).toBe(false);
  });
  it("denies writes from banned authenticated members", async () => {
    const headers = member();
    state.banned = true;
    const result = await request("/works", "POST", workBody, headers);
    expect(result.response.status).toBe(403);
    expect(
      mocks.execute.mock.calls.some(([sql]) =>
        sql.includes("INSERT INTO tc_works")
      )
    ).toBe(false);
  });
  it("creates member content with authenticated ownership and no editable sample flag", async () => {
    const result = await request("/works", "POST", workBody, member());
    expect(result.response.status).toBe(200);
    expect(result.body).toEqual({ id: 41 });
    const insert = mocks.execute.mock.calls.find(([sql]) =>
      sql.includes("INSERT INTO tc_works")
    );
    expect(insert?.[1][4]).toBe(42);
    expect(insert?.[0]).not.toContain("sample");
  });
  it("rejects arbitrary remote images and unregistered managed paths", async () => {
    const headers = member();
    expect(
      (
        await request(
          "/works",
          "POST",
          { ...workBody, cover: "https://attacker.test/image.png" },
          headers
        )
      ).response.status
    ).toBe(400);
    expect(
      (
        await request(
          "/works",
          "POST",
          { ...workBody, cover: "/manus-storage/not-owned.png" },
          headers
        )
      ).response.status
    ).toBe(403);
    expect(mocks.storage).not.toHaveBeenCalled();
  });
  it("enforces content ownership and protects sample edits", async () => {
    const headers = member();
    state.work = { id: 1, author_id: 99, sample: false };
    expect(
      (await request("/works/1", "PATCH", { title: "수정" }, headers)).response
        .status
    ).toBe(403);
    state.work = { id: 1, author_id: 42, sample: true };
    expect(
      (await request("/works/1", "DELETE", undefined, headers)).response.status
    ).toBe(403);
  });
  it("uses public queries that filter hidden children and their hidden parents", async () => {
    await request("/bootstrap");
    const queries = mocks.rows.mock.calls.map(([sql]) => sql);
    expect(
      queries.some(sql => sql.includes("e.hidden = FALSE AND w.hidden = FALSE"))
    ).toBe(true);
    expect(
      queries.some(sql => sql.includes("c.hidden = FALSE AND p.hidden = FALSE"))
    ).toBe(true);
    expect(
      queries.some(
        sql => sql.includes("m.hidden = FALSE") && sql.includes("LIMIT 100")
      )
    ).toBe(true);
  });
  it("validates chat room and returns ascending last-100 query semantics", async () => {
    expect((await request("/chat?room=general")).response.status).toBe(200);
    expect((await request("/chat?room=unexpected")).response.status).toBe(400);
    const query = mocks.rows.mock.calls.find(([sql]) =>
      sql.includes("m.room = ?")
    );
    expect(query?.[1]).toEqual(["general"]);
    expect(query?.[0]).toContain("ORDER BY m.id DESC LIMIT 100");
  });
  it("logs in with scrypt and sets secure cross-site cookie plus opaque fallback token", async () => {
    const result = await request(
      "/admin/login",
      "POST",
      { username: "admin", password: testPassword },
      { "X-Terran-Client": "web" }
    );
    expect(result.response.status).toBe(200);
    expect(result.body.success).toBe(true);
    expect(result.body.token).toMatch(/^[A-Za-z0-9_-]{43}$/);
    const cookie = result.response.headers.get("set-cookie") ?? "";
    for (const flag of [
      "terran_admin=",
      "HttpOnly",
      "Secure",
      "SameSite=None",
      "Path=/api/community",
    ])
      expect(cookie).toContain(flag);
    const insert = mocks.execute.mock.calls.find(([sql]) =>
      sql.includes("INSERT INTO tc_admin_sessions")
    );
    expect(insert?.[1][0]).toBe(hashToken(result.body.token));
    expect(insert?.[1][0]).not.toBe(result.body.token);
    expect(JSON.stringify(result.body)).not.toContain(testPassword);
  });
  it("rejects invalid admin credentials with a generic JSON error", async () => {
    const result = await request(
      "/admin/login",
      "POST",
      { username: "admin", password: "incorrect" },
      { "X-Terran-Client": "web" }
    );
    expect(result.response.status).toBe(401);
    expect(Object.keys(result.body)).toEqual(["error"]);
  });
  it("enforces durable login limit before credential verification", async () => {
    state.rateHits = 9;
    const result = await request(
      "/admin/login",
      "POST",
      { username: "admin", password: testPassword },
      { "X-Terran-Client": "web" }
    );
    expect(result.response.status).toBe(429);
    expect(result.response.headers.get("retry-after")).toBe("60");
    expect(
      mocks.rows.mock.calls.some(([sql]) =>
        sql.includes("FROM tc_admin_accounts")
      )
    ).toBe(false);
  });
  it("uploads authenticated magic-checked image with randomized key and persisted ownership", async () => {
    const png = Buffer.alloc(24);
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]).copy(png);
    png.write("IHDR", 12);
    const result = await request(
      "/upload",
      "POST",
      {
        name: "../../untrusted.png",
        type: "image/png",
        data: png.toString("base64"),
      },
      member()
    );
    expect(result.response.status).toBe(200);
    expect(result.body).toEqual({ url: "/manus-storage/community/test.png" });
    expect(mocks.storage.mock.calls[0][0]).toMatch(
      /^community\/uploads\/[a-f0-9-]+\.png$/
    );
    const persisted = mocks.execute.mock.calls.find(([sql]) =>
      sql.includes("INSERT INTO tc_uploads")
    );
    expect(persisted?.[1][3]).toBe(42);
    expect(persisted?.[1][4]).toBe(false);
    expect(persisted?.[1][6]).toBe(24);
  });
  it("accepts opaque admin header without a member and returns all-content shape without secrets", async () => {
    const result = await request("/admin/data", "GET", undefined, admin());
    expect(result.response.status).toBe(200);
    expect(result.body).toEqual({
      users: [],
      works: [],
      posts: [],
      messages: [],
    });
    expect(
      mocks.rows.mock.calls.some(
        ([sql]) =>
          sql.includes("tc_episodes") && !sql.includes("e.hidden = FALSE")
      )
    ).toBe(true);
  });
  it("lets separate administrator author content as ID zero", async () => {
    const result = await request(
      "/posts",
      "POST",
      { title: "관리자 글", body: "운영 내용", category: "공지" },
      admin()
    );
    expect(result.response.status).toBe(200);
    const insert = mocks.execute.mock.calls.find(([sql]) =>
      sql.includes("INSERT INTO tc_posts")
    );
    expect(insert?.[1][3]).toBe("테란 관리자");
    expect(insert?.[1][4]).toBe(0);
  });
  it("requires explicit admin permission on moderation", async () => {
    const result = await request(
      "/admin/moderate",
      "POST",
      { entity: "work", id: 1, action: "delete" },
      member()
    );
    expect(result.response.status).toBe(403);
    expect(
      mocks.execute.mock.calls.some(([sql]) =>
        sql.startsWith("DELETE FROM tc_works")
      )
    ).toBe(false);
  });
  it("password rotation keeps current session and revokes all other sessions", async () => {
    const headers = admin();
    const result = await request(
      "/admin/password",
      "POST",
      {
        currentPassword: testPassword,
        newPassword: "New test-only password#2026",
      },
      headers
    );
    expect(result.response.status).toBe(200);
    const revoke = mocks.execute.mock.calls.find(([sql]) =>
      sql.includes(
        "DELETE FROM tc_admin_sessions WHERE admin_id=? AND token_hash<>?"
      )
    );
    expect(revoke?.[1]).toEqual([1, state.adminTokenHash]);
    const update = mocks.execute.mock.calls.find(([sql]) =>
      sql.includes("UPDATE tc_admin_accounts")
    );
    expect(update?.[1][0]).toMatch(/^scrypt\$/);
    expect(update?.[1][0]).not.toContain("New test-only");
  });
  it("logout deletes the active hashed session", async () => {
    const result = await request("/admin/logout", "POST", {}, admin());
    expect(result.response.status).toBe(200);
    expect(
      mocks.execute.mock.calls.some(
        ([sql, values]) =>
          sql.includes("DELETE FROM tc_admin_sessions WHERE token_hash=?") &&
          values[0] === state.adminTokenHash
      )
    ).toBe(true);
  });
  it("rejects malformed JSON and unknown API paths with JSON errors", async () => {
    const malformed = await fetch(`${base}/works`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Terran-Client": "web" },
      body: "{",
    });
    expect(malformed.status).toBe(400);
    expect(typeof (await malformed.json()).error).toBe("string");
    const missing = await request("/no-such-route");
    expect(missing.response.status).toBe(404);
    expect(typeof missing.body.error).toBe("string");
  });
});

describe("comment editing permissions (mock database)", () => {
  function commentRecord(authorId: number, hidden = false) {
    const original = mocks.rows.getMockImplementation()!;
    mocks.rows.mockImplementation((sql: string, values: unknown[] = []) =>
      sql.includes("FROM tc_comments c JOIN tc_posts")
        ? Promise.resolve([{ author_id: authorId, hidden, post_hidden: false }])
        : original(sql, values)
    );
  }
  it("requires a validated member or separate admin session", async () => {
    const result = await request(
      "/comments/7",
      "PATCH",
      { body: "수정" },
      { "X-Terran-Client": "web" }
    );
    expect(result.response.status).toBe(401);
  });
  it("allows the comment author to edit the body", async () => {
    const headers = member();
    commentRecord(42);
    const result = await request(
      "/comments/7",
      "PATCH",
      { body: "수정한 댓글" },
      headers
    );
    expect(result.response.status).toBe(200);
    expect(result.body).toEqual({ success: true });
    expect(mocks.execute).toHaveBeenCalledWith(
      "UPDATE tc_comments SET body=? WHERE id=?",
      ["수정한 댓글", 7],
      expect.anything()
    );
  });
  it("denies a different member", async () => {
    const headers = member();
    commentRecord(99);
    const result = await request(
      "/comments/7",
      "PATCH",
      { body: "수정" },
      headers
    );
    expect(result.response.status).toBe(403);
  });
  it("does not let a member edit moderated hidden comments", async () => {
    const headers = member();
    commentRecord(42, true);
    const result = await request(
      "/comments/7",
      "PATCH",
      { body: "수정" },
      headers
    );
    expect(result.response.status).toBe(403);
  });
  it("allows a separately authenticated admin to edit a hidden comment", async () => {
    const headers = admin();
    commentRecord(99, true);
    const result = await request(
      "/comments/7",
      "PATCH",
      { body: "관리자 수정" },
      headers
    );
    expect(result.response.status).toBe(200);
  });
});

describe("chat images and global notifications (mock database only)", () => {
  const image = "/manus-storage/community/uploads/member.png";
  const inserts = () =>
    mocks.execute.mock.calls.filter(([sql]) =>
      sql.includes("INSERT INTO tc_messages")
    );
  function uploadRecord(ownerId: number, adminOwned = false) {
    const original = mocks.rows.getMockImplementation()!;
    mocks.rows.mockImplementation((sql: string, values: unknown[] = []) =>
      sql.includes("FROM tc_uploads")
        ? Promise.resolve([
            { url: image, owner_id: ownerId, admin_owned: adminOwned },
          ])
        : original(sql, values)
    );
  }
  it("keeps text-only clients working and persists the explicit empty array", async () => {
    const result = await request(
      "/chat",
      "POST",
      { room: "general", body: " hello " },
      member()
    );
    expect(result.response.status).toBe(200);
    expect(inserts()[0][1]).toEqual([
      "general",
      "hello",
      "[]",
      "진짜 회원",
      42,
    ]);
    expect(inserts()[0][2]).toEqual({ mocked: true });
    expect(
      mocks.rows.mock.calls.some(([sql]) => sql.includes("FROM tc_uploads"))
    ).toBe(false);
  });
  it("allows an image-only message from the registered upload owner in the same transaction", async () => {
    const headers = member();
    uploadRecord(42);
    const result = await request(
      "/chat",
      "POST",
      { room: "world", body: "", images: [image] },
      headers
    );
    expect(result.response.status).toBe(200);
    expect(inserts()[0][1]).toEqual([
      "world",
      "",
      JSON.stringify([image]),
      "진짜 회원",
      42,
    ]);
    expect(mocks.rows).toHaveBeenCalledWith(
      expect.stringContaining("FROM tc_uploads"),
      [hashToken(image)],
      { mocked: true }
    );
    expect(inserts()[0][2]).toEqual({ mocked: true });
  });
  it("rejects empty messages, non-managed paths and empty image entries before insertion", async () => {
    const headers = member();
    for (const body of [
      { room: "general", body: " \n " },
      { room: "general", body: "", images: [""] },
      {
        room: "general",
        body: "caption",
        images: ["https://attacker.test/a.png"],
      },
      { room: "general", body: "caption", images: Array(5).fill(image) },
    ])
      expect(
        (await request("/chat", "POST", body, headers)).response.status
      ).toBe(400);
    expect(inserts()).toHaveLength(0);
  });
  it("rejects unregistered managed uploads", async () => {
    const result = await request(
      "/chat",
      "POST",
      { room: "general", body: "", images: [image] },
      member()
    );
    expect(result.response.status).toBe(403);
    expect(inserts()).toHaveLength(0);
  });
  it("rejects another member's upload and admin-owned uploads for normal members", async () => {
    const headers = member();
    for (const [ownerId, adminOwned] of [
      [99, false],
      [42, true],
    ] as const) {
      uploadRecord(ownerId, adminOwned);
      expect(
        (
          await request(
            "/chat",
            "POST",
            { room: "general", body: "", images: [image] },
            headers
          )
        ).response.status
      ).toBe(403);
    }
    expect(inserts()).toHaveLength(0);
  });
  it("allows separately authenticated administrators to use registered member uploads", async () => {
    uploadRecord(99);
    const result = await request(
      "/chat",
      "POST",
      { room: "creators", body: "관리 이미지", images: [image] },
      admin()
    );
    expect(result.response.status).toBe(200);
    expect(inserts()[0][1][4]).toBe(0);
  });
  it("serves the latest public global stream when room is omitted, with legacy attachment mapping", async () => {
    const original = mocks.rows.getMockImplementation()!;
    mocks.rows.mockImplementation((sql: string, values: unknown[] = []) =>
      sql.includes("FROM tc_messages m")
        ? Promise.resolve([
            {
              id: 2,
              room: "world",
              body: "",
              images: JSON.stringify([image]),
              author: "회원",
              author_id: 42,
              created_at: "2026-11-10 00:00:00",
              hidden: 0,
            },
            {
              id: 1,
              room: "general",
              body: "text",
              author: "회원",
              author_id: 42,
              created_at: "2026-11-09 00:00:00",
              hidden: 0,
            },
          ])
        : original(sql, values)
    );
    const result = await request("/chat");
    expect(result.response.status).toBe(200);
    expect(result.body.map((message: any) => message.id)).toEqual([1, 2]);
    expect(result.body.map((message: any) => message.images)).toEqual([
      [],
      [image],
    ]);
    const query = mocks.rows.mock.calls.find(([sql]) =>
      sql.includes("FROM tc_messages m")
    );
    expect(query?.[0]).toContain("m.hidden = FALSE");
    expect(query?.[0]).toContain("ORDER BY m.id DESC LIMIT 100");
    expect(query?.[0]).not.toContain("m.room = ?");
    expect(query?.[1]).toEqual([]);
    expect((await request("/chat?room=")).response.status).toBe(400);
    expect(
      (await request("/chat?room=general&room=world")).response.status
    ).toBe(400);
  });
});

describe("public room REST contract (mock database only)", () => {
  const roomId = "room_012345abcdef";
  const roomInput = { name: "시민 공개방", description: "함께 이야기해요" };
  function roomRecords(creatorId = 42, closed = false, isDefault = false) {
    let record = {
      id: roomId,
      name: roomInput.name,
      description: roomInput.description,
      creator_id: creatorId,
      creator_name: creatorId === 0 ? "테란 관리자" : "진짜 회원",
      created_at: "2026-11-10 00:00:00",
      is_default: isDefault,
      closed,
      message_count: 2,
    };
    const originalRows = mocks.rows.getMockImplementation()!;
    const originalExecute = mocks.execute.getMockImplementation()!;
    mocks.rows.mockImplementation((sql: string, values: unknown[] = []) => {
      if (sql.includes("FROM tc_rooms"))
        return Promise.resolve([{ ...record }]);
      return originalRows(sql, values);
    });
    mocks.execute.mockImplementation((sql: string, values: any[] = []) => {
      if (sql.startsWith("INSERT INTO tc_rooms"))
        record = {
          ...record,
          id: values[0],
          name: values[1],
          description: values[2],
          creator_id: values[3],
          creator_name: values[4],
          message_count: 0,
        };
      if (sql.startsWith("UPDATE tc_rooms"))
        record = {
          ...record,
          name: values[0],
          description: values[1],
          closed: values[2],
        };
      return originalExecute(sql, values);
    });
  }
  const inserts = () =>
    mocks.execute.mock.calls.filter(([sql]) =>
      sql.startsWith("INSERT INTO tc_rooms")
    );
  it("serves direct public room array and admin-only all-room array", async () => {
    roomRecords();
    const publicList = await request("/rooms");
    expect(publicList.response.status).toBe(200);
    expect(publicList.body[0]).toMatchObject({
      id: roomId,
      creatorId: 42,
      messageCount: 2,
      isDefault: false,
      closed: false,
    });
    expect((await request("/admin/rooms")).response.status).toBe(403);
    expect(
      (await request("/admin/rooms", "GET", undefined, admin())).response.status
    ).toBe(200);
  });
  it("requires authentication and blocks banned creation", async () => {
    expect(
      (await request("/rooms", "POST", roomInput, { "X-Terran-Client": "web" }))
        .response.status
    ).toBe(401);
    const headers = member();
    state.banned = true;
    expect(
      (await request("/rooms", "POST", roomInput, headers)).response.status
    ).toBe(403);
    expect(inserts()).toHaveLength(0);
  });
  it("creates trimmed, owned room with random id and full returned ChatRoom", async () => {
    roomRecords();
    const result = await request(
      "/rooms",
      "POST",
      { name: " 시민 공개방 ", description: " " },
      member()
    );
    expect(result.response.status).toBe(200);
    expect(result.body).toMatchObject({
      name: "시민 공개방",
      description: "",
      creatorId: 42,
      creator: "진짜 회원",
      closed: false,
      isDefault: false,
      messageCount: 0,
    });
    expect(result.body.id).toMatch(/^room_[a-f0-9]{12}$/);
    expect(Object.keys(result.body).sort()).toEqual(
      [
        "id",
        "name",
        "description",
        "creatorId",
        "creator",
        "createdAt",
        "isDefault",
        "closed",
        "messageCount",
      ].sort()
    );
    expect(inserts()[0][1]).toEqual([
      result.body.id,
      "시민 공개방",
      "",
      42,
      "진짜 회원",
    ]);
  });
  it("caps creations at 10/hour without any fee or fake counts", async () => {
    const headers = member();
    state.rateHits = 11;
    expect(
      (await request("/rooms", "POST", roomInput, headers)).response.status
    ).toBe(429);
    expect(inserts()).toHaveLength(0);
    expect(
      mocks.execute.mock.calls.some(
        ([sql, values]) => sql.includes("tc_rate_limits") && values[1] === 3600
      )
    ).toBe(true);
  });
  it("rejects out-of-range and forged creation fields", async () => {
    const headers = member();
    for (const input of [
      { name: "가", description: "" },
      { name: "가".repeat(41), description: "" },
      { name: "정상", description: "나".repeat(201) },
      { ...roomInput, id: roomId },
      { ...roomInput, creatorId: 99 },
    ])
      expect(
        (await request("/rooms", "POST", input, headers)).response.status
      ).toBe(400);
    expect(inserts()).toHaveLength(0);
  });
  it("lets owner close room, but rejects other members and disallows DELETE", async () => {
    const headers = member();
    roomRecords(99);
    expect(
      (await request(`/rooms/${roomId}`, "PATCH", { closed: true }, headers))
        .response.status
    ).toBe(403);
    roomRecords(42);
    const result = await request(
      `/rooms/${roomId}`,
      "PATCH",
      { closed: true },
      headers
    );
    expect(result.response.status).toBe(200);
    expect(result.body).toMatchObject({ closed: true, messageCount: 2 });
    expect(
      (await request(`/rooms/${roomId}`, "DELETE", undefined, headers)).response
        .status
    ).toBe(404);
    expect(
      mocks.execute.mock.calls.some(([sql]) => sql.startsWith("DELETE"))
    ).toBe(false);
  });
  it("lets separate admins manage ID-zero rooms and rejects default edits", async () => {
    roomRecords(0);
    expect(
      (await request(`/rooms/${roomId}`, "PATCH", { name: "수정" }, member()))
        .response.status
    ).toBe(403);
    state.user = null;
    const headers = admin();
    expect(
      (
        await request(
          `/rooms/${roomId}`,
          "PATCH",
          { name: "관리 수정" },
          headers
        )
      ).response.status
    ).toBe(200);
    roomRecords(0, false, true);
    expect(
      (await request("/rooms/general", "PATCH", { closed: true }, headers))
        .response.status
    ).toBe(409);
  });
  it("returns 404 nonexistent and 409 closed chat for both GET and POST", async () => {
    expect((await request(`/chat?room=${roomId}`)).response.status).toBe(404);
    const headers = member();
    expect(
      (await request("/chat", "POST", { room: roomId, body: "hello" }, headers))
        .response.status
    ).toBe(404);
    roomRecords(42, true);
    expect((await request(`/chat?room=${roomId}`)).response.status).toBe(409);
    expect(
      (await request("/chat", "POST", { room: roomId, body: "hello" }, headers))
        .response.status
    ).toBe(409);
    expect(
      mocks.execute.mock.calls.some(([sql]) =>
        sql.startsWith("INSERT INTO tc_messages")
      )
    ).toBe(false);
  });
  it("supports custom-room text and images with roomName in read output", async () => {
    roomRecords();
    expect(
      (
        await request(
          "/chat",
          "POST",
          { room: roomId, body: "custom room text" },
          member()
        )
      ).response.status
    ).toBe(200);
    const original = mocks.rows.getMockImplementation()!;
    mocks.rows.mockImplementation((sql: string, values: unknown[] = []) =>
      sql.includes("FROM tc_messages m")
        ? Promise.resolve([
            {
              id: 1,
              room: roomId,
              room_name: roomInput.name,
              body: "hello",
              images: "[]",
              author: "진짜 회원",
              author_id: 42,
              hidden: 0,
              created_at: "2026-11-10 00:00:00",
            },
          ])
        : original(sql, values)
    );
    const result = await request(`/chat?room=${roomId}`);
    expect(result.response.status).toBe(200);
    expect(result.body[0]).toMatchObject({
      room: roomId,
      roomName: roomInput.name,
      images: [],
    });
  });
});
