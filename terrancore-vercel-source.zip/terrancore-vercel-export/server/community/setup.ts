import "dotenv/config";
import { readFile, writeFile, chmod } from "node:fs/promises";
import { randomBytes } from "node:crypto";
import { fileURLToPath } from "node:url";
import {
  getCommunityPool,
  rows,
  execute,
  closeCommunityPool,
} from "./database";
import { hashPassword, hashToken } from "./security";
import { seedCommunity } from "./seed";
import { applyChatImagesMigration } from "./chat-images-migration";
import { applyChatRoomsMigration } from "./chat-rooms-migration";

const ACCESS_FILE = "/home/ubuntu/terran-admin-access.txt";
async function initialPassword(): Promise<string> {
  try {
    const stored = JSON.parse(await readFile(ACCESS_FILE, "utf8")) as {
      username: string;
      password: string;
    };
    if (
      stored.username !== "admin" ||
      !/^[A-Za-z0-9_-]{43}$/.test(stored.password)
    )
      throw new Error(
        "Existing admin access file is invalid; refusing to overwrite it"
      );
    await chmod(ACCESS_FILE, 0o600);
    return stored.password;
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
    const password = randomBytes(32).toString("base64url");
    await writeFile(
      ACCESS_FILE,
      JSON.stringify({ username: "admin", password }, null, 2) + "\n",
      { mode: 0o600, flag: "wx" }
    );
    return password;
  }
}

async function setup(): Promise<void> {
  const pool = getCommunityPool();
  const db = await pool.getConnection();
  let locked = false;
  let inTransaction = false;
  let lockName = "";
  try {
    const names = await rows("SELECT DATABASE() AS name", [], db);
    lockName = `tc-setup-${hashToken(String(names[0].name)).slice(0, 40)}`;
    const lock = await rows(
      "SELECT GET_LOCK(?,30) AS acquired",
      [lockName],
      db
    );
    if (Number(lock[0].acquired) !== 1)
      throw new Error("Could not acquire community setup lock");
    locked = true;
    const sql = await readFile(
      fileURLToPath(new URL("./migrations/001_community.sql", import.meta.url)),
      "utf8"
    );
    for (const statement of sql
      .split(";")
      .map(value => value.trim())
      .filter(Boolean))
      await db.query(statement);
    await execute(
      "INSERT IGNORE INTO tc_versions (version) VALUES (?)",
      ["community-schema-v1"],
      db
    );
    await applyChatImagesMigration(db);
    await db.beginTransaction();
    inTransaction = true;
    const administrators = await rows(
      "SELECT id FROM tc_admin_accounts WHERE username='admin'",
      [],
      db
    );
    if (!administrators.length) {
      const password = await initialPassword();
      await execute(
        "INSERT INTO tc_admin_accounts (id,username,password_hash) VALUES (1,'admin',?)",
        [await hashPassword(password)],
        db
      );
      console.log(
        `Initial administrator created; access file: ${ACCESS_FILE} (mode 0600)`
      );
    } else console.log("Existing administrator preserved; no password reset.");
    const seeded = await rows(
      "SELECT version FROM tc_versions WHERE version=?",
      ["community-seed-v1"],
      db
    );
    if (!seeded.length) {
      await seedCommunity(db);
      await execute(
        "INSERT INTO tc_versions (version) VALUES (?)",
        ["community-seed-v1"],
        db
      );
      console.log("community-seed-v1 applied atomically.");
    } else
      console.log(
        "community-seed-v1 already applied; all content edits preserved."
      );
    await db.commit();
    inTransaction = false;
    await applyChatRoomsMigration(db);
    const counts = await rows(
      "SELECT (SELECT COUNT(*) FROM tc_works) AS works,(SELECT COUNT(*) FROM tc_episodes) AS episodes,(SELECT COUNT(*) FROM tc_posts) AS posts,(SELECT COUNT(*) FROM tc_messages) AS messages,(SELECT COUNT(*) FROM users) AS members",
      [],
      db
    );
    console.log("Database initialization evidence:", JSON.stringify(counts[0]));
    console.log(
      "Applied versions:",
      (await rows("SELECT version FROM tc_versions ORDER BY version", [], db))
        .map(row => row.version)
        .join(", ")
    );
  } finally {
    if (inTransaction) await db.rollback();
    if (locked)
      await rows("SELECT RELEASE_LOCK(?) AS released", [lockName], db);
    db.release();
    await closeCommunityPool();
  }
}
setup().catch(async error => {
  await closeCommunityPool().catch(() => undefined);
  // Do not print DSNs, bound SQL values or initial passwords, even on setup failure.
  console.error(
    "Community setup failed:",
    (error as { code?: string; name?: string }).code ?? (error as Error).name
  );
  process.exitCode = 1;
});
