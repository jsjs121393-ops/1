import type { Request, Response } from "express";
import { parse as parseCookies } from "cookie";
import { sdk } from "../_core/sdk";
import { HttpError } from "../../shared/_core/errors";
import { COOKIE_NAME } from "../../shared/const";
import type { Member } from "../../shared/community";
import { rows, execute, checkReady, type Database } from "./database";
import { ApiError, hashToken, sanitizeName } from "./security";

export const ADMIN_COOKIE = "terran_admin";
export const ADMIN_SESSION_MS = 7 * 24 * 60 * 60 * 1000;
export const adminCookieOptions = {
  httpOnly: true,
  secure: true,
  sameSite: "none" as const,
  path: "/api/community",
  maxAge: ADMIN_SESSION_MS,
};
export interface Identity {
  user: Member | null;
  admin: boolean;
  adminId: number | null;
  sessionHash: string | null;
}
export interface Actor extends Identity {
  authorId: number;
  author: string;
}
export function iso(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  return new Date(
    String(value).replace(" ", "T") +
      (/Z$|[+-]\d\d:\d\d$/.test(String(value)) ? "" : "Z")
  ).toISOString();
}

export async function resolveIdentity(req: Request): Promise<Identity> {
  const cookies = parseCookies(req.headers.cookie ?? "");
  const header = req.get("X-Terran-Admin");
  const token = header ?? cookies[ADMIN_COOKIE];
  let sessionHash: string | null = null;
  let adminId: number | null = null;
  if (token && /^[A-Za-z0-9_-]{43}$/.test(token)) {
    sessionHash = hashToken(token);
    const sessions = await rows(
      "SELECT admin_id FROM tc_admin_sessions WHERE token_hash = ? AND expires_at > UTC_TIMESTAMP()",
      [sessionHash]
    );
    adminId = sessions[0]?.admin_id ?? null;
    if (!adminId) sessionHash = null;
  }
  let user: Member | null = null;
  if (cookies[COOKIE_NAME] || req.headers.authorization) {
    try {
      const authenticated = await sdk.authenticateRequest(req);
      if (authenticated.id > 0 && !authenticated.isCron) {
        const profile = await rows(
          "SELECT p.name, COALESCE(m.banned, FALSE) AS banned FROM users u LEFT JOIN tc_profiles p ON p.user_id = u.id LEFT JOIN tc_member_moderation m ON m.user_id = u.id WHERE u.id = ?",
          [authenticated.id]
        );
        if (profile.length)
          user = {
            id: authenticated.id,
            name:
              profile[0].name ??
              (authenticated.name
                ? sanitizeName(authenticated.name).slice(0, 30)
                : null),
            email: authenticated.email,
            // Community administrator status NEVER comes from the base Manus user role.
            role: "user",
            banned: Boolean(profile[0].banned),
            createdAt: iso(authenticated.createdAt),
          };
      }
    } catch (error) {
      if (!(error instanceof HttpError && error.statusCode === 403))
        throw error;
      // The SDK can classify sync errors as authentication errors. Do not mask a DB outage.
      await checkReady();
    }
  }
  return { user, admin: adminId !== null, adminId, sessionHash };
}

export async function requireActor(
  identity: Identity,
  db?: Database
): Promise<Actor> {
  if (!identity.user && !identity.admin)
    throw new ApiError(401, "로그인이 필요합니다.");
  if (identity.user) {
    const moderation = await rows(
      "SELECT banned FROM tc_member_moderation WHERE user_id = ?",
      [identity.user.id],
      db
    );
    // A banned member cannot use a simultaneously held admin cookie to write.
    if (moderation[0]?.banned)
      throw new ApiError(403, "이 계정은 커뮤니티 작성이 제한되었습니다.");
  }
  return {
    ...identity,
    authorId: identity.user?.id ?? 0,
    author: identity.user?.name || (identity.admin ? "테란 관리자" : "회원"),
  };
}

export function requireAdmin(
  identity: Identity
): asserts identity is Identity & { adminId: number; sessionHash: string } {
  if (!identity.admin || !identity.adminId || !identity.sessionHash)
    throw new ApiError(403, "별도의 관리자 로그인이 필요합니다.");
}

export async function rateLimit(
  scope: string,
  key: string,
  maximum: number,
  windowSeconds: number,
  res?: Response
): Promise<void> {
  const rateKey = hashToken(`${scope}:${key}`);
  await execute(
    "INSERT INTO tc_rate_limits (rate_key,hits,resets_at) VALUES (?,1,DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? SECOND)) ON DUPLICATE KEY UPDATE hits = IF(resets_at <= UTC_TIMESTAMP(),1,hits+1), resets_at = IF(resets_at <= UTC_TIMESTAMP(),DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? SECOND),resets_at)",
    [rateKey, windowSeconds, windowSeconds]
  );
  const result = await rows(
    "SELECT hits, GREATEST(1,TIMESTAMPDIFF(SECOND,UTC_TIMESTAMP(),resets_at)) AS retry FROM tc_rate_limits WHERE rate_key = ?",
    [rateKey]
  );
  if (result[0].hits > maximum) {
    res?.set("Retry-After", String(result[0].retry));
    throw new ApiError(
      429,
      "요청이 너무 많습니다. 잠시 후 다시 시도해 주세요."
    );
  }
}
