import { describe, expect, it, vi } from "vitest";
import type { Database } from "./database";

const execute = vi.hoisted(() => vi.fn());
vi.mock("./database", () => ({ execute }));
import { seedCommunity } from "./seed";

describe("initial samples (mock database only)", () => {
  it("retains examples privately without seeding public novels or fabricated chat", async () => {
    execute.mockClear();
    execute.mockResolvedValue({ insertId: 1 });
    await seedCommunity({ mocked: true } as unknown as Database);
    const works = execute.mock.calls.filter(([sql]) =>
      sql.includes("INSERT INTO tc_works")
    );
    expect(works).toHaveLength(4);
    for (const [sql, values] of works) {
      expect(sql).toContain("sample,hidden");
      expect(values[7]).toBe(values[0] === "novel");
    }
    expect(
      works
        .filter(([, values]) => values[0] === "novel")
        .map(([, values]) => values[1])
    ).toEqual(["테란: 마지막 함대", "제국의 잔해"]);
    expect(
      execute.mock.calls.filter(([sql]) =>
        sql.includes("INSERT INTO tc_episodes")
      )
    ).toHaveLength(6);
    expect(
      execute.mock.calls.some(([sql]) =>
        /DELETE|INSERT INTO tc_messages/.test(sql)
      )
    ).toBe(false);
  });
});
