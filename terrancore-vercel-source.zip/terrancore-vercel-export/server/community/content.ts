import { ART } from "../../shared/community";
import {
  rows,
  execute,
  transaction,
  type Database,
  type Row,
} from "./database";
import { requireActor, type Identity, type Actor } from "./auth";
import { ApiError, assertOwner, hashToken } from "./security";
import type { z } from "zod";
import type { workSchema, episodeSchema, postSchema } from "./security";
import { requireOpenRoom } from "./rooms";

type WorkInput = z.infer<typeof workSchema>;
type EpisodeInput = z.infer<typeof episodeSchema>;
type PostInput = z.infer<typeof postSchema>;
const storedArray = (value: unknown): string[] =>
  typeof value === "string" ? JSON.parse(value) : (value as string[]);

export async function validateImageOwnership(
  paths: string[],
  actor: Actor,
  existing: string[] = [],
  db?: Database
): Promise<void> {
  const allowed = new Set(existing);
  if (actor.admin)
    for (const path of [ART.hero, ...ART.covers]) allowed.add(path);
  const pending = [
    ...new Set(paths.filter(path => path && !allowed.has(path))),
  ];
  if (!pending.length) return;
  const placeholders = pending.map(() => "?").join(",");
  const uploads = await rows(
    `SELECT url,owner_id,admin_owned FROM tc_uploads WHERE url_hash IN (${placeholders})`,
    pending.map(hashToken),
    db
  );
  for (const path of pending) {
    const upload = uploads.find(upload => upload.url === path);
    if (
      !upload ||
      (!actor.admin &&
        (upload.owner_id !== actor.authorId || upload.admin_owned))
    )
      throw new ApiError(
        403,
        "본인이 업로드한 관리 이미지 파일만 사용할 수 있습니다."
      );
  }
}

async function ownedWork(
  id: number,
  actor: Actor,
  db: Database,
  allowHidden = false
): Promise<Row> {
  const records = await rows(
    "SELECT * FROM tc_works WHERE id = ? FOR UPDATE",
    [id],
    db
  );
  const work = records[0];
  if (!work) throw new ApiError(404, "작품을 찾을 수 없습니다.");
  assertOwner(
    work.author_id,
    actor.authorId,
    actor.admin,
    Boolean(work.sample)
  );
  if (work.hidden && !actor.admin && !allowHidden)
    throw new ApiError(403, "숨겨진 작품은 수정할 수 없습니다.");
  return work;
}
async function ownedPost(
  id: number,
  actor: Actor,
  db: Database,
  allowHidden = false
): Promise<Row> {
  const records = await rows(
    "SELECT * FROM tc_posts WHERE id = ? FOR UPDATE",
    [id],
    db
  );
  const post = records[0];
  if (!post) throw new ApiError(404, "게시글을 찾을 수 없습니다.");
  assertOwner(
    post.author_id,
    actor.authorId,
    actor.admin,
    Boolean(post.sample)
  );
  if (post.hidden && !actor.admin && !allowHidden)
    throw new ApiError(403, "숨겨진 게시글은 수정할 수 없습니다.");
  return post;
}

export async function createWork(
  input: WorkInput,
  identity: Identity
): Promise<{ id: number }> {
  return transaction(async db => {
    const actor = await requireActor(identity, db);
    await validateImageOwnership([input.cover], actor, [], db);
    const result = await execute(
      "INSERT INTO tc_works (kind,title,description,author,author_id,genre,cover,tags,status) VALUES (?,?,?,?,?,?,?,?,?)",
      [
        input.kind,
        input.title,
        input.description,
        actor.author,
        actor.authorId,
        input.genre,
        input.cover,
        JSON.stringify(input.tags),
        input.status,
      ],
      db
    );
    return { id: result.insertId };
  });
}
export async function updateWork(
  id: number,
  input: Partial<WorkInput>,
  identity: Identity
): Promise<{ success: true }> {
  return transaction(async db => {
    const actor = await requireActor(identity, db);
    const work = await ownedWork(id, actor, db);
    await validateImageOwnership(
      input.cover ? [input.cover] : [],
      actor,
      [work.cover],
      db
    );
    const value = {
      kind: work.kind,
      title: work.title,
      description: work.description,
      genre: work.genre,
      cover: work.cover,
      tags: storedArray(work.tags),
      status: work.status,
      ...input,
    };
    await execute(
      "UPDATE tc_works SET kind=?,title=?,description=?,genre=?,cover=?,tags=?,status=? WHERE id=?",
      [
        value.kind,
        value.title,
        value.description,
        value.genre,
        value.cover,
        JSON.stringify(value.tags),
        value.status,
        id,
      ],
      db
    );
    return { success: true };
  });
}
export async function deleteWork(
  id: number,
  identity: Identity
): Promise<{ success: true }> {
  return transaction(async db => {
    const actor = await requireActor(identity, db);
    await ownedWork(id, actor, db, true);
    // Episode rows are removed atomically by the FK cascade.
    await execute("DELETE FROM tc_works WHERE id = ?", [id], db);
    return { success: true };
  });
}
export async function createEpisode(
  workId: number,
  input: EpisodeInput,
  identity: Identity
): Promise<{ id: number }> {
  return transaction(async db => {
    const actor = await requireActor(identity, db);
    await ownedWork(workId, actor, db);
    await validateImageOwnership(input.images, actor, [], db);
    const result = await execute(
      "INSERT INTO tc_episodes (work_id,title,number,body,images) VALUES (?,?,?,?,?)",
      [
        workId,
        input.title,
        input.number,
        input.body,
        JSON.stringify(input.images),
      ],
      db
    );
    return { id: result.insertId };
  });
}
export async function updateEpisode(
  id: number,
  input: Partial<EpisodeInput> | null,
  identity: Identity
): Promise<{ success: true }> {
  return transaction(async db => {
    const actor = await requireActor(identity, db);
    const records = await rows(
      "SELECT * FROM tc_episodes WHERE id = ? FOR UPDATE",
      [id],
      db
    );
    const episode = records[0];
    if (!episode) throw new ApiError(404, "회차를 찾을 수 없습니다.");
    await ownedWork(episode.work_id, actor, db, input === null);
    if (input === null) {
      await execute("DELETE FROM tc_episodes WHERE id=?", [id], db);
    } else {
      if (episode.hidden && !actor.admin)
        throw new ApiError(403, "숨겨진 회차는 수정할 수 없습니다.");
      const oldImages = storedArray(episode.images);
      await validateImageOwnership(input.images ?? [], actor, oldImages, db);
      const value = {
        title: episode.title,
        number: episode.number,
        body: episode.body,
        images: oldImages,
        ...input,
      };
      await execute(
        "UPDATE tc_episodes SET title=?,number=?,body=?,images=? WHERE id=?",
        [
          value.title,
          value.number,
          value.body,
          JSON.stringify(value.images),
          id,
        ],
        db
      );
    }
    return { success: true };
  });
}
export async function createPost(
  input: PostInput,
  identity: Identity
): Promise<{ id: number }> {
  return transaction(async db => {
    const actor = await requireActor(identity, db);
    const result = await execute(
      "INSERT INTO tc_posts (title,body,category,author,author_id) VALUES (?,?,?,?,?)",
      [input.title, input.body, input.category, actor.author, actor.authorId],
      db
    );
    return { id: result.insertId };
  });
}
export async function updatePost(
  id: number,
  input: Partial<PostInput> | null,
  identity: Identity
): Promise<{ success: true }> {
  return transaction(async db => {
    const actor = await requireActor(identity, db);
    const post = await ownedPost(id, actor, db, input === null);
    if (input === null)
      await execute("DELETE FROM tc_posts WHERE id=?", [id], db);
    else {
      const value = {
        title: post.title,
        body: post.body,
        category: post.category,
        ...input,
      };
      await execute(
        "UPDATE tc_posts SET title=?,body=?,category=? WHERE id=?",
        [value.title, value.body, value.category, id],
        db
      );
    }
    return { success: true };
  });
}
export async function createComment(
  postId: number,
  body: string,
  identity: Identity
): Promise<{ id: number }> {
  return transaction(async db => {
    const actor = await requireActor(identity, db);
    const posts = await rows(
      "SELECT id,hidden FROM tc_posts WHERE id=? FOR UPDATE",
      [postId],
      db
    );
    if (!posts[0] || (posts[0].hidden && !actor.admin))
      throw new ApiError(404, "게시글을 찾을 수 없습니다.");
    const result = await execute(
      "INSERT INTO tc_comments (post_id,body,author,author_id) VALUES (?,?,?,?)",
      [postId, body, actor.author, actor.authorId],
      db
    );
    return { id: result.insertId };
  });
}
export async function updateComment(
  id: number,
  body: string,
  identity: Identity
): Promise<{ success: true }> {
  return transaction(async db => {
    const actor = await requireActor(identity, db);
    const records = await rows(
      "SELECT c.author_id,c.hidden,p.hidden AS post_hidden FROM tc_comments c JOIN tc_posts p ON p.id=c.post_id WHERE c.id=? FOR UPDATE",
      [id],
      db
    );
    const comment = records[0];
    if (!comment) throw new ApiError(404, "댓글을 찾을 수 없습니다.");
    assertOwner(comment.author_id, actor.authorId, actor.admin);
    if ((comment.hidden || comment.post_hidden) && !actor.admin)
      throw new ApiError(403, "숨겨진 댓글은 수정할 수 없습니다.");
    await execute("UPDATE tc_comments SET body=? WHERE id=?", [body, id], db);
    return { success: true };
  });
}
export async function createMessage(
  room: string,
  body: string,
  identity: Identity,
  images: string[] = []
): Promise<{ id: number }> {
  return transaction(async db => {
    const actor = await requireActor(identity, db);
    await requireOpenRoom(room, db);
    await validateImageOwnership(images, actor, [], db);
    const result = await execute(
      "INSERT INTO tc_messages (room,body,images,author,author_id) VALUES (?,?,?,?,?)",
      [room, body, JSON.stringify(images), actor.author, actor.authorId],
      db
    );
    return { id: result.insertId };
  });
}
export async function deleteAuthored(
  entity: "comment" | "message",
  id: number,
  identity: Identity
): Promise<{ success: true }> {
  const table = entity === "comment" ? "tc_comments" : "tc_messages";
  return transaction(async db => {
    const actor = await requireActor(identity, db);
    const records = await rows(
      `SELECT author_id FROM ${table} WHERE id=? FOR UPDATE`,
      [id],
      db
    );
    if (!records[0]) throw new ApiError(404, "콘텐츠를 찾을 수 없습니다.");
    assertOwner(records[0].author_id, actor.authorId, actor.admin);
    await execute(`DELETE FROM ${table} WHERE id=?`, [id], db);
    return { success: true };
  });
}
export const moderationTables = {
  work: "tc_works",
  episode: "tc_episodes",
  post: "tc_posts",
  comment: "tc_comments",
  message: "tc_messages",
} as const;
export async function moderate(
  entity: keyof typeof moderationTables,
  id: number,
  action: "hide" | "restore" | "delete",
  adminId: number
): Promise<{ success: true }> {
  const table = moderationTables[entity];
  return transaction(async db => {
    const records = await rows(
      `SELECT id FROM ${table} WHERE id=? FOR UPDATE`,
      [id],
      db
    );
    if (!records[0]) throw new ApiError(404, "콘텐츠를 찾을 수 없습니다.");
    if (action === "delete")
      await execute(`DELETE FROM ${table} WHERE id=?`, [id], db);
    else
      await execute(
        `UPDATE ${table} SET hidden=? WHERE id=?`,
        [action === "hide", id],
        db
      );
    await execute(
      "INSERT INTO tc_moderation_log (admin_id,entity,entity_id,action) VALUES (?,?,?,?)",
      [adminId, entity, id, action],
      db
    );
    return { success: true };
  });
}
