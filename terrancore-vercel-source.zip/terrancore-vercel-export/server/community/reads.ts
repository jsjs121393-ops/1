import type {
  Work,
  Episode,
  Post,
  Comment,
  ChatMessage,
  Member,
  AdminData,
  Bootstrap,
} from "../../shared/community";
import { rows, transaction, type Row, type Database } from "./database";
import { iso, type Identity } from "./auth";
import { requireOpenRoom } from "./rooms";

const array = (value: unknown): string[] =>
  typeof value === "string" ? JSON.parse(value) : (value as string[]);
const authorJoins = (alias: string) =>
  ` LEFT JOIN users u ON u.id = ${alias}.author_id LEFT JOIN tc_profiles profile ON profile.user_id = u.id `;
const authorSelect = (alias: string) =>
  `${alias}.*, COALESCE(profile.name,u.name,${alias}.author) AS resolved_author`;
export const mapEpisode = (r: Row): Episode => ({
  id: r.id,
  workId: r.work_id,
  title: r.title,
  number: r.number,
  body: r.body,
  images: array(r.images),
  createdAt: iso(r.created_at),
  hidden: Boolean(r.hidden),
});
export const mapWork = (r: Row): Work => ({
  id: r.id,
  kind: r.kind,
  title: r.title,
  description: r.description,
  author: r.resolved_author ?? r.author,
  authorId: r.author_id,
  genre: r.genre,
  cover: r.cover,
  tags: array(r.tags),
  status: r.status,
  createdAt: iso(r.created_at),
  featured: Boolean(r.featured),
  hidden: Boolean(r.hidden),
  sample: Boolean(r.sample),
  episodes: [],
});
export const mapComment = (r: Row): Comment => ({
  id: r.id,
  postId: r.post_id,
  body: r.body,
  author: r.resolved_author ?? r.author,
  authorId: r.author_id,
  createdAt: iso(r.created_at),
  hidden: Boolean(r.hidden),
});
export const mapPost = (r: Row): Post => ({
  id: r.id,
  title: r.title,
  body: r.body,
  category: r.category,
  author: r.resolved_author ?? r.author,
  authorId: r.author_id,
  createdAt: iso(r.created_at),
  hidden: Boolean(r.hidden),
  pinned: Boolean(r.pinned),
  sample: Boolean(r.sample),
  comments: [],
});
export const mapMessage = (r: Row): ChatMessage => ({
  id: r.id,
  room: r.room,
  ...(r.room_name != null ? { roomName: r.room_name } : {}),
  body: r.body,
  images: r.images == null ? [] : array(r.images),
  author: r.resolved_author ?? r.author,
  authorId: r.author_id,
  createdAt: iso(r.created_at),
  hidden: Boolean(r.hidden),
});

export async function getWorks(all = false, db?: Database): Promise<Work[]> {
  const [works, episodes] = await Promise.all([
    rows(
      `SELECT ${authorSelect("w")} FROM tc_works w ${authorJoins("w")} ${all ? "" : "WHERE w.hidden = FALSE"} ORDER BY w.created_at DESC,w.id DESC`,
      [],
      db
    ),
    rows(
      `SELECT e.* FROM tc_episodes e JOIN tc_works w ON w.id = e.work_id ${all ? "" : "WHERE e.hidden = FALSE AND w.hidden = FALSE"} ORDER BY e.number,e.id`,
      [],
      db
    ),
  ]);
  const result = works.map(mapWork);
  const byId = new Map(result.map(w => [w.id, w]));
  for (const episode of episodes)
    byId.get(episode.work_id)?.episodes.push(mapEpisode(episode));
  return result;
}
export async function getPosts(all = false, db?: Database): Promise<Post[]> {
  const [posts, comments] = await Promise.all([
    rows(
      `SELECT ${authorSelect("p")} FROM tc_posts p ${authorJoins("p")} ${all ? "" : "WHERE p.hidden = FALSE"} ORDER BY p.pinned DESC,p.created_at DESC,p.id DESC`,
      [],
      db
    ),
    rows(
      `SELECT ${authorSelect("c")} FROM tc_comments c JOIN tc_posts p ON p.id = c.post_id ${authorJoins("c")} ${all ? "" : "WHERE c.hidden = FALSE AND p.hidden = FALSE"} ORDER BY c.id`,
      [],
      db
    ),
  ]);
  const result = posts.map(mapPost);
  const byId = new Map(result.map(p => [p.id, p]));
  for (const comment of comments)
    byId.get(comment.post_id)?.comments.push(mapComment(comment));
  return result;
}
export async function getMessages(
  room?: string,
  all = false,
  db?: Database
): Promise<ChatMessage[]> {
  if (room !== undefined && !all) {
    if (!db)
      return transaction(connection => getMessages(room, all, connection));
    await requireOpenRoom(room, db);
  }
  const filters = [
    ...(!all ? ["m.hidden = FALSE"] : []),
    ...(room !== undefined ? ["m.room = ?"] : []),
    ...(!all ? ["r.closed = FALSE"] : []),
  ];
  const result = await rows(
    `SELECT ${authorSelect("m")},r.name AS room_name FROM tc_messages m ${all ? "LEFT JOIN" : "JOIN"} tc_rooms r ON r.id=m.room ${authorJoins("m")} ${filters.length ? `WHERE ${filters.join(" AND ")}` : ""} ORDER BY m.id DESC ${all ? "" : "LIMIT 100"}`,
    room !== undefined ? [room] : [],
    db
  );
  return result.reverse().map(mapMessage);
}
export async function getMembers(): Promise<Member[]> {
  const result = await rows(
    "SELECT u.id,COALESCE(p.name,u.name) AS name,u.email,u.createdAt,COALESCE(m.banned,FALSE) AS banned FROM users u LEFT JOIN tc_profiles p ON p.user_id = u.id LEFT JOIN tc_member_moderation m ON m.user_id = u.id ORDER BY u.id DESC"
  );
  return result.map(r => ({
    id: r.id,
    name: r.name,
    email: r.email,
    role: "user",
    createdAt: iso(r.createdAt),
    banned: Boolean(r.banned),
  }));
}
export async function bootstrap(identity: Identity): Promise<Bootstrap> {
  const [works, posts, messages, counts] = await Promise.all([
    getWorks(),
    getPosts(),
    getMessages(),
    rows(
      "SELECT (SELECT COUNT(*) FROM users) AS members,(SELECT COUNT(*) FROM tc_works WHERE hidden = FALSE) AS works,(SELECT COUNT(*) FROM tc_posts WHERE hidden = FALSE) AS posts,(SELECT COUNT(*) FROM tc_messages m JOIN tc_rooms r ON r.id=m.room WHERE m.hidden = FALSE AND r.closed = FALSE) AS messages"
    ),
  ]);
  const count = counts[0];
  return {
    user: identity.user,
    admin: identity.admin,
    works,
    posts,
    messages,
    stats: {
      members: Number(count.members),
      works: Number(count.works),
      posts: Number(count.posts),
      messages: Number(count.messages),
    },
  };
}
export async function adminData(): Promise<AdminData> {
  const [users, works, posts, messages] = await Promise.all([
    getMembers(),
    getWorks(true),
    getPosts(true),
    getMessages(undefined, true),
  ]);
  return { users, works, posts, messages };
}
