import { beforeEach, describe, expect, it, vi } from "vitest";
import type { Database } from "./database";

const mocks = vi.hoisted(() => ({ rows: vi.fn(), execute: vi.fn() }));
vi.mock("./database", () => ({ rows: mocks.rows, execute: mocks.execute }));
import {
  applyChatRoomsMigration,
  CHAT_ROOMS_VERSION,
  DEFAULT_CHAT_ROOMS,
} from "./chat-rooms-migration";

const query = vi.fn();
const db = { query } as unknown as Database;
let columns: any[];
let orphaned: number;
let rooms: Map<string, any>;
const priorMessages = [
  {
    id: 1,
    room: "general",
    body: "기존 기록",
    images: ["/manus-storage/original.png"],
  },
  { id: 2, room: "creators", body: "이전 텍스트", images: [] },
];
let messages: typeof priorMessages;
const legacyColumns = () => [
  {
    column_name: "room",
    data_type: "enum",
    column_type: "enum('general','world','creators')",
    max_length: 8,
    is_nullable: "NO",
    column_default: null,
  },
  {
    column_name: "images",
    data_type: "json",
    is_nullable: "NO",
    column_default: "json_array()",
  },
];

beforeEach(() => {
  vi.clearAllMocks();
  columns = legacyColumns();
  orphaned = 0;
  rooms = new Map();
  messages = structuredClone(priorMessages);
  query.mockImplementation(async (sql: string) => {
    if (sql.startsWith("ALTER TABLE"))
      columns[0] = {
        ...columns[0],
        data_type: "varchar",
        column_type: "varchar(64)",
        max_length: 64,
      };
    return [];
  });
  mocks.rows.mockImplementation(async (sql: string) => {
    if (sql.includes("information_schema.COLUMNS")) return columns;
    if (sql.includes("WHERE r.id IS NULL")) return [{ count: orphaned }];
    return [{ rooms: rooms.size, messages: messages.length }];
  });
  mocks.execute.mockImplementation(async (sql: string, values: any[]) => {
    if (sql.includes("INSERT IGNORE INTO tc_rooms")) {
      if (rooms.has(values[0])) return { affectedRows: 0 };
      rooms.set(values[0], {
        id: values[0],
        name: values[1],
        description: values[2],
        creator_id: 0,
        is_default: true,
        closed: false,
      });
      return { affectedRows: 1 };
    }
    return { affectedRows: 1 };
  });
});

describe("chat rooms v3 migration (mock database only)", () => {
  it("widens only the room column, seeds exact defaults and preserves messages/images", async () => {
    expect(await applyChatRoomsMigration(db)).toEqual({
      widenedColumn: true,
      seededRooms: 3,
      rooms: 3,
      messages: 2,
    });
    expect(query.mock.calls[0][0]).toContain(
      "CREATE TABLE IF NOT EXISTS tc_rooms"
    );
    expect(query.mock.calls[0][0]).toContain(
      "id VARCHAR(64) NOT NULL PRIMARY KEY"
    );
    expect(query.mock.calls[1][0]).toBe(
      "ALTER TABLE tc_messages MODIFY COLUMN room VARCHAR(64) NOT NULL"
    );
    expect(
      query.mock.calls.every(
        ([sql]) => !sql.includes("ADD COLUMN") && !sql.includes("SET DEFAULT")
      )
    ).toBe(true);
    expect(
      mocks.execute.mock.calls.every(([sql]) => sql.startsWith("INSERT IGNORE"))
    ).toBe(true);
    expect(messages).toEqual(priorMessages);
    expect([...rooms.values()].map(room => room.name)).toEqual(
      DEFAULT_CHAT_ROOMS.map(room => room.name)
    );
    expect(mocks.execute).toHaveBeenCalledWith(
      "INSERT IGNORE INTO tc_versions (version) VALUES (?)",
      [CHAT_ROOMS_VERSION],
      db
    );
  });
  it("repeats safely without ALTER or overwriting previous room edits/state or content", async () => {
    await applyChatRoomsMigration(db);
    const custom = {
      id: "room_123456abcdef",
      name: "시민 작품 방",
      description: "보존",
      creator_id: 42,
      is_default: false,
      closed: true,
    };
    rooms.set(custom.id, custom);
    rooms.get("general").name = "기존 기본방 이름";
    rooms.get("general").description = "기존 소개";
    const before = structuredClone([...rooms.entries()]);
    query.mockClear();
    expect(await applyChatRoomsMigration(db)).toEqual({
      widenedColumn: false,
      seededRooms: 0,
      rooms: 4,
      messages: 2,
    });
    expect(query).toHaveBeenCalledTimes(1);
    expect(query.mock.calls[0][0]).toContain("CREATE TABLE IF NOT EXISTS");
    expect([...rooms.entries()]).toEqual(before);
    expect(messages).toEqual(priorMessages);
  });
  it("recovers an interrupted varchar upgrade before seed/version completion", async () => {
    columns[0] = {
      ...columns[0],
      data_type: "varchar",
      column_type: "varchar(64)",
      max_length: 64,
    };
    rooms.set("general", {
      id: "general",
      name: "보존 이름",
      description: "보존 소개",
    });
    expect(await applyChatRoomsMigration(db)).toMatchObject({
      widenedColumn: false,
      seededRooms: 2,
      rooms: 3,
    });
    expect(rooms.get("general").name).toBe("보존 이름");
    expect(query.mock.calls.some(([sql]) => sql.includes("ALTER TABLE"))).toBe(
      false
    );
  });
  it("refuses unexpected room/image schema before any write", async () => {
    for (const change of [
      { data_type: "int" },
      { data_type: "varchar", max_length: 40 },
      { column_type: "enum('other')" },
      { is_nullable: "YES" },
      { column_default: "general" },
    ]) {
      columns = legacyColumns();
      Object.assign(columns[0], change);
      await expect(applyChatRoomsMigration(db)).rejects.toThrow(
        "unexpected schema"
      );
    }
    for (const change of [
      { data_type: "text" },
      { is_nullable: "YES" },
      { column_default: null },
    ]) {
      columns = legacyColumns();
      Object.assign(columns[1], change);
      await expect(applyChatRoomsMigration(db)).rejects.toThrow(
        "v2 schema is required"
      );
    }
    expect(query).not.toHaveBeenCalled();
    expect(mocks.execute).not.toHaveBeenCalled();
  });
  it("does not mark readiness when messages refer to missing rooms", async () => {
    orphaned = 1;
    await expect(applyChatRoomsMigration(db)).rejects.toThrow("missing rooms");
    expect(
      mocks.execute.mock.calls.some(([sql]) => sql.includes("tc_versions"))
    ).toBe(false);
    expect(messages).toEqual(priorMessages);
  });
  it("never truncates, deletes, updates prior rows or changes credentials/images schema", async () => {
    await applyChatRoomsMigration(db);
    const writes = [...query.mock.calls, ...mocks.execute.mock.calls].map(
      call => call[0]
    );
    expect(
      writes.some(sql =>
        /\b(DELETE|TRUNCATE|UPDATE|DROP)\b|tc_admin|MODIFY COLUMN images|INSERT INTO tc_messages/i.test(
          sql
        )
      )
    ).toBe(false);
  });
});
