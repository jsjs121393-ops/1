# Terran community backend

The Express router is mounted at `/api/community` before the starter body parsers. OAuth, its exact `webdev_app_session` cookie and the starter tRPC endpoints are preserved. The shared contract is `shared/community.ts`.

## Explicit database preparation

Run from the project directory:

```sh
pnpm exec tsx server/community/setup.ts
```

This finite script creates the additive schema in `migrations/001_community.sql`, applies the inspect-first chat image migration and the chat room v3 migration after seed commit, keeps the existing base `users` schema and records `community-schema-v1`, `community-schema-v2-chat-images`, `community-schema-v3-chat-rooms` and `community-seed-v1`. A database-specific advisory lock serializes setup and chat upgrades. Seed content and its completion marker are committed atomically. Rerunning preserves subsequent content edits and existing administrator credentials. Startup **does not migrate or reseed**; API readiness requires the seed, v2 image and v3 room markers and fails with JSON HTTP 500 if preparation is incomplete or the database is unavailable.

For an existing database, run only the required finite incremental scripts below. None reads or changes administrator credentials.

```sh
pnpm exec tsx server/community/upgrade-chat.ts
pnpm exec tsx server/community/upgrade-rooms.ts
pnpm exec tsx server/community/hide-sample-novels.ts
```

The chat upgrade inspects `information_schema` before adding `tc_messages.images`, fills only SQL NULL values with `[]`, preserves populated arrays, and installs `JSON NOT NULL DEFAULT (JSON_ARRAY())` before recording readiness. It resumes safely after partial DDL completion. On managed TiDB 8.5, expression defaults fail during `ADD COLUMN`, and JSON `ALTER COLUMN SET DEFAULT` is also rejected. The verified compatible sequence is nullable `ADD COLUMN`, NULL-only backfill, then `MODIFY COLUMN` with the empty-array default. Default-expression support is described in the [TiDB defaults documentation](https://docs.pingcap.com/tidbcloud/data-type-default-values/); the ADD COLUMN restriction is visible in [the TiDB 8.5.3 implementation](https://github.com/pingcap/tidb/blob/v8.5.3/pkg/ddl/column.go).

The sample script transactionally hides only novels with `sample=TRUE`, `author_id=0`, and the exact titles `테란: 마지막 함대` or `제국의 잔해`. It logs counts/titles only and never deletes works or episodes. An administrator can restore them through existing moderation. Fresh initialization also retains these two novel examples hidden; the existing seed marker prevents public reseeding or overwriting later edits.

The room upgrade inspects the exact legacy enum and completed v2 image schema before writing. It creates `tc_rooms`, widens only `tc_messages.room` to `VARCHAR(64) NOT NULL` (verified on managed TiDB), and `INSERT IGNORE`s the three original room IDs/names/descriptions. Existing room edits and all messages/images are preserved on rerun. The same setup advisory lock is held throughout. Its evidence compares full message-row digests and unrelated content counts without logging message text or credentials. No fake custom rooms are inserted into the managed database.

The initial administrator has username `admin` and a 256-bit random password. The only plaintext copy is `/home/ubuntu/terran-admin-access.txt`, mode `0600`, outside the repository. The script reuses that file if a prior interrupted initial transaction wrote it, and never logs the password. The database stores salted scrypt hashes only. Deliver the access file privately, then change the initial password through the admin screen. Password changes do not update the initial-access file; it is not an ongoing password recovery service.

Development and publication use the **same managed database**. Do not run destructive live-data tests. Test files mock the database/OAuth/storage or use pure validators; their short-lived loopback HTTP listener is a test harness, not a development server.

## Authentication and authorization

Members use `sdk.authenticateRequest`, with the starter OAuth cookie or Bearer fallback. There are no fake identities or development bypasses. The community returns member `role: 'user'`; administration is determined exclusively by a separate valid admin session, never the base user's role. Members have profile and ban records in separate tables; base OAuth columns are not repurposed.

Admin login sets `terran_admin` with `HttpOnly; Secure; SameSite=None`, scoped to `/api/community`, and returns an opaque token for the `X-Terran-Admin` sessionStorage fallback. Tokens are 32 random bytes, hashed with SHA-256 in the database and expire after seven days. Logout revokes the supplied session; password rotation verifies the current password, revokes other sessions and preserves the current one. Tokens and password hashes are never present in bootstrap or admin data.

Every mutation, including admin login/logout, requires `X-Terran-Client: web`. No permissive CORS headers are emitted. A database-backed limiter caps mutations at 300/minute per network peer and 120/minute per member or administrator; admin login is 8 attempts per 15 minutes per peer, password changes 5 per 15 minutes per administrator and uploads 12/minute per identity. The peer is Express `req.ip` with no unsafe blanket proxy trust. If infrastructure shares the same upstream peer, the peer-based limiter is intentionally conservative.

Server-side authorization enforces ownership and explicit admin permission. Banned members cannot create/edit/delete/upload or update profiles. Separate admin-only sessions can author content as `authorId: 0`, author `테란 관리자`. Newly authored works/posts always have `sample: false`. Sample works and posts are editable only by admin. Deleting a work cascades its episodes; deleting a post cascades comments. Hiding a parent excludes its children from every public read without overwriting independent child hide states.

## REST details

All successes return direct JSON data; every error returns `{error: string}` with an appropriate non-2xx status. GET `/bootstrap` always contains public visible data, even for admin; GET `/admin/data` is the dedicated all-content view with hidden episodes and comments nested under their parents. Public statistics are real database counts, and never include invented online/view counts. `/bootstrap` and GET `/chat` return the latest 100 visible messages across all rooms in ascending order; `/chat?room=general|world|creators` restricts that stream to the validated room. Admin data contains all messages.

GET `/rooms` returns open `ChatRoom[]`, defaults first then newest. POST `/rooms` accepts strict `{name,description}` with trimmed name 2–40 characters and description 0–200; it requires a non-banned authenticated member or separate administrator and is capped at 10 creation attempts/hour per identity. IDs are server-generated `room_` plus exactly 12 lowercase hex digits. PATCH `/rooms/:id` accepts a nonempty strict subset `{name?,description?,closed?}` and returns the updated `ChatRoom`. Only the creator or administrator may edit; creator ID zero is admin-only. Default rooms cannot be edited or closed (409). There is no room DELETE. GET `/admin/rooms` is separately admin-only and includes closed rooms.

`ChatRoom` contains `id,name,description,creatorId,creator,createdAt,isDefault,closed,messageCount`. Public/updated room counts exclude hidden messages; the admin list counts all messages. Chat room query/body IDs accept only the exact three defaults or generated `room_[a-f0-9]{12}` IDs, not display names. A requested nonexistent room returns 404 and a closed room returns 409. Requested public reads and all message inserts lock the room in a transaction; inserts check openness before image ownership. Global public messages/notifications and public message counts exclude closed rooms, but admin data retains all old messages. Message reads include the joined optional `roomName`.

POST `/chat` accepts `{room,body,images?}`. Text is trimmed and limited to 2,000 characters; an empty body requires at least one image. Attachments default to `[]` for old text-only clients, accept at most four nonempty managed image paths, and must pass upload ownership validation inside the same transaction as insertion. Every returned message includes an image array, including legacy text-only messages. Existing delete and hide/restore moderation continue to operate on the complete message.

POST work/episode/post bodies use the exact fields in the requested contract. PATCH endpoints accept any nonempty subset of those fields. CREATE returns `{id}`. PATCH/DELETE/moderation/member/profile/password/logout return `{success: true}`. Each episode number is unique within its work (conflicts return HTTP 409). `/profile` requires a real member session; admin-only identity has no member profile. Names are normalized/sanitized and capped at 30 characters. Content bodies are plain text, not executable HTML.

Uploads accept only strict base64 JPEG/PNG/WEBP/GIF with matching magic bytes and a maximum decoded length of 10 MiB. Original filenames are not used for keys; randomized server keys and upload ownership are persisted. Cover/episode/chat paths must be managed `/manus-storage/` paths that are uploaded by the author, already assigned to the authorized edited record, or recognized seed artwork used by an administrator. Admin may use managed uploaded files from any member. Arbitrary remote URLs and unregistered managed paths are rejected.

## Checks

```sh
pnpm exec vitest run server/community
pnpm check
```

Only explicit finite preparation scripts write schema/seed or sample-hide changes; tests never mutate managed production data. No passwords belong in source, environment examples, Git history or API response objects.
