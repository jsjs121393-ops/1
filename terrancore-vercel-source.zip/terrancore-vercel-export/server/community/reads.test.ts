import { beforeEach, describe, expect, it, vi } from "vitest";
import type { Row } from "./database";

const mocks = vi.hoisted(() => ({ rows: vi.fn() }));
vi.mock("./database", () => ({
  rows: mocks.rows,
  transaction: async (run: (db: any) => Promise<any>) => run({ mocked: true }),
}));
vi.mock("./rooms", () => ({
  requireOpenRoom: vi.fn().mockResolvedValue({ closed: false }),
}));
vi.mock("./auth", () => ({
  iso: (value: string) => new Date(`${value.replace(" ", "T")}Z`).toISOString(),
}));
import { mapMessage, getMessages } from "./reads";

const message = (id = 1, images?: unknown) =>
  ({
    id,
    room: "general",
    body: "hello",
    images,
    author: "stored author",
    author_id: 42,
    created_at: "2026-11-10 00:00:00",
    hidden: 0,
  }) as Row;

beforeEach(() => vi.clearAllMocks());

describe("chat reads (mock database only)", () => {
  it("maps legacy missing/null images and serialized/decoded arrays", () => {
    for (const images of [undefined, null, "[]", []])
      expect(mapMessage(message(1, images))).toMatchObject({
        images: [],
        hidden: false,
      });
    const paths = [
      "/manus-storage/community/uploads/one.png",
      "/manus-storage/community/uploads/two.png",
    ];
    for (const images of [JSON.stringify(paths), paths])
      expect(mapMessage(message(1, images))).toMatchObject({
        images: paths,
        authorId: 42,
      });
  });
  it("uses current profile author names and preserves image-only bodies", () => {
    expect(
      mapMessage({
        ...message(),
        body: "",
        room_name: "테란 라운지",
        resolved_author: "new profile",
        hidden: 1,
      })
    ).toMatchObject({
      body: "",
      author: "new profile",
      hidden: true,
      roomName: "테란 라운지",
      images: [],
    });
  });
  it("returns latest 100 visible messages across rooms in chronological order", async () => {
    mocks.rows.mockResolvedValue([
      message(3),
      { ...message(2), room: "world" },
      message(1),
    ]);
    const result = await getMessages();
    expect(result.map(row => row.id)).toEqual([1, 2, 3]);
    expect(result.map(row => row.room)).toEqual([
      "general",
      "world",
      "general",
    ]);
    const [sql, values] = mocks.rows.mock.calls[0];
    expect(sql).toContain("WHERE m.hidden = FALSE");
    expect(sql).toContain("JOIN tc_rooms r ON r.id=m.room");
    expect(sql).toContain("r.closed = FALSE");
    expect(sql).toContain("ORDER BY m.id DESC LIMIT 100");
    expect(sql).not.toContain("m.room = ?");
    expect(values).toEqual([]);
  });
  it("filters a requested room and keeps public hidden filtering", async () => {
    mocks.rows.mockResolvedValue([]);
    await getMessages("creators");
    expect(mocks.rows.mock.calls[0][0]).toContain(
      "WHERE m.hidden = FALSE AND m.room = ?"
    );
    expect(mocks.rows.mock.calls[0][1]).toEqual(["creators"]);
  });
  it("keeps admin all-message reads unrestricted and valid with a room", async () => {
    mocks.rows.mockResolvedValue([]);
    await getMessages(undefined, true);
    expect(mocks.rows.mock.calls[0][0]).not.toMatch(/WHERE|LIMIT 100/);
    expect(mocks.rows.mock.calls[0][0]).toContain("LEFT JOIN tc_rooms");
    expect(mocks.rows.mock.calls[0][0]).not.toContain("r.closed = FALSE");
    await getMessages("world", true);
    expect(mocks.rows.mock.calls[1][0]).toContain("WHERE m.room = ?");
    expect(mocks.rows.mock.calls[1][0]).not.toContain("m.hidden = FALSE");
  });
});
