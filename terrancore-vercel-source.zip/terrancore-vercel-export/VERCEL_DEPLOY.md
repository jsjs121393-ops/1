# Vercel 전체 기능 배포 안내

이 프로젝트는 Vercel용으로 다음 구조를 사용합니다.

- 프런트엔드: Vite 빌드 결과 `dist/public`
- API: `api/index.ts`에서 기존 Express 라우터 실행
- API 경로: `/api/*`
- SPA 경로: 존재하지 않는 프런트엔드 경로를 `/index.html`로 재작성
- 서버 코드: `server/_core/app.ts`의 공통 Express 앱

## Vercel 설정

`vercel.json`이 빌드 명령, 출력 디렉터리, Node.js 22 서버리스 함수, API 및 SPA 라우팅을 정의합니다.

## 필요한 환경변수

Vercel Project Settings → Environment Variables에 서버 전용으로 등록합니다.

- `DATABASE_URL`: MySQL 호환 데이터베이스 연결 문자열
- `MANUS_PROJECT_ID`: 기존 Manus OAuth 프로젝트 ID
- `MANUS_OAUTH_API_URL`: OAuth 토큰 교환 서버 URL
- `MANUS_OAUTH_PORTAL_URL`: 로그인 포털 URL
- `MANUS_JWT_SECRET`: 기존 세션 검증용 비밀값
- `OWNER_OPEN_ID`: 기존 소유자 식별자를 사용하는 경우
- `MANUS_API_URL`, `MANUS_API_KEY`: 해당 서버 기능을 계속 사용하는 경우
- 이미지 업로드에 필요한 저장소 환경변수

비밀값은 Git 저장소, `vercel.json`, 압축 파일 또는 채팅에 넣지 않습니다. Vercel의 Production과 Preview 환경을 구분해 등록하세요.

## 데이터와 기능

로그인, 관리자 인증, 작품·회차 작성, 게시글·댓글, 시민 채팅방, 이미지 메시지, 알림, 이미지 업로드는 서버·데이터베이스·스토리지가 연결되어야 작동합니다. Vercel 서버리스 함수의 임시 파일시스템에 데이터를 저장하지 말고, 기존 MySQL과 오브젝트 스토리지를 연결해야 합니다.

기존 Manus 관리형 DB와 파일 저장소는 Vercel로 자동 복사되지 않습니다. 실제 전환 전 백업, OAuth 콜백 URL 변경, 쿠키 도메인·HTTPS 확인이 필요합니다.

## 확인 순서

1. Vercel에 이 프로젝트를 Import합니다.
2. Root Directory를 프로젝트 루트로 둡니다.
3. `vercel.json`이 인식되는지 확인합니다.
4. 환경변수를 등록합니다.
5. 배포 후 `/api/health`가 200인지 확인합니다.
6. 관리자 로그인, 일반 로그인, 작품 작성, 게시글, 채팅, 이미지 업로드를 순서대로 확인합니다.
