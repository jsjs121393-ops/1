# Railway 이전 안내

이 프로젝트는 Docker 컨테이너로 실행되며 다음 런타임 환경변수가 필요합니다.

- `PORT`: Railway가 주입하므로 별도 고정값을 넣지 않습니다.
- `DATABASE_URL`: Railway MySQL 호환 데이터베이스 연결 문자열.
- `MANUS_PROJECT_ID`, `MANUS_OAUTH_PORTAL_URL`, `MANUS_OAUTH_API_URL`: Manus OAuth를 계속 사용할 경우 필요한 값입니다.
- `MANUS_JWT_SECRET`: 기존 Manus 세션 검증에 필요한 서버 전용 값입니다.
- `MANUS_API_KEY`: 서버 전용 Manus API 기능을 계속 사용할 때만 설정합니다.
- 기존 프로젝트에서 사용하는 Storage 관련 서버 환경변수: 이미지 업로드를 유지하려면 Railway 배포 환경에도 동일한 저장소 설정이 필요합니다.

## 배포 순서

1. Railway에서 새 프로젝트를 만들고 GitHub 저장소 또는 이 프로젝트의 Docker 소스를 연결합니다.
2. MySQL 호환 데이터베이스를 추가하고 `DATABASE_URL`을 연결합니다.
3. 위의 서버 전용 환경변수를 Railway Variables에 등록합니다. 비밀값은 채팅이나 Git에 저장하지 않습니다.
4. 배포 후 `/api/health`가 200을 반환하는지 확인합니다.
5. 기존 데이터베이스와 이미지 저장소를 이전한 뒤 관리자 로그인, 회원 로그인, 게시글, 채팅, 이미지 업로드를 확인합니다.

기존 Manus 프로젝트의 관리형 데이터베이스와 저장소는 Railway로 자동 복사되지 않습니다. 실제 데이터 이전 전에는 백업을 만들고, OAuth 리디렉션 URL과 이미지 저장소의 공개 URL을 새 도메인에 맞게 확인해야 합니다.
