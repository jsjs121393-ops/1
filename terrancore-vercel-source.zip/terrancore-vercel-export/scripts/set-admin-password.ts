import "dotenv/config";
import { unlink } from "node:fs/promises";
import {
  rows,
  execute,
  transaction,
  closeCommunityPool,
} from "../server/community/database";
import {
  hashPassword,
  verifyPassword,
  passwordSchema,
} from "../server/community/security";

async function run() {
  const value = process.env.TERRAN_ADMIN_NEW_PASSWORD;
  if (!value) throw new Error("보안 입력된 비밀번호가 현재 환경에 없습니다.");
  const check = passwordSchema.shape.newPassword.safeParse(value);
  if (!check.success)
    throw new Error(
      "새 비밀번호는 영문과 숫자 또는 기호를 포함한 8~128자여야 합니다. 기존 비밀번호는 변경하지 않았습니다."
    );
  const hash = await hashPassword(check.data);
  await transaction(async db => {
    const accounts = await rows(
      "SELECT id FROM tc_admin_accounts WHERE username=? FOR UPDATE",
      ["admin"],
      db
    );
    if (!accounts.length) throw new Error("관리자 계정을 찾을 수 없습니다.");
    await execute(
      "UPDATE tc_admin_accounts SET password_hash=? WHERE id=?",
      [hash, accounts[0].id],
      db
    );
    await execute(
      "DELETE FROM tc_admin_sessions WHERE admin_id=?",
      [accounts[0].id],
      db
    );
  });
  const updated = await rows(
    "SELECT password_hash FROM tc_admin_accounts WHERE username=?",
    ["admin"]
  );
  if (
    !updated[0] ||
    !(await verifyPassword(check.data, updated[0].password_hash))
  )
    throw new Error("변경한 비밀번호의 검증에 실패했습니다.");
  await unlink("/home/ubuntu/terran-admin-access.txt").catch(
    (error: NodeJS.ErrnoException) => {
      if (error.code !== "ENOENT")
        throw new Error("이전 초기 암호 파일 정리가 필요합니다.");
    }
  );
  console.log(
    "관리자 admin 비밀번호 변경 및 해시 검증 완료. 기존 관리자 세션이 해제되었고 이전 초기 암호 파일은 제거되었습니다."
  );
}
run()
  .catch(error => {
    console.error(
      error instanceof Error && !("sql" in error)
        ? error.message
        : "관리자 비밀번호 변경에 실패했습니다."
    );
    process.exitCode = 1;
  })
  .finally(async () => {
    delete process.env.TERRAN_ADMIN_NEW_PASSWORD;
    await closeCommunityPool();
  });
