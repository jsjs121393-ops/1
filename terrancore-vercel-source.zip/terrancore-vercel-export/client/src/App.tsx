import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch, useLocation, useSearch } from "wouter";
import { useEffect } from "react";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import NotFound from "./pages/NotFound";
import Home from "./pages/Home";
import { CommunityProvider } from "./components/terran/CommunityProvider";
import { ChatNotificationsProvider } from "./components/terran/ChatNotifications";
import { Layout } from "./components/terran/Layout";
import Explore from "./pages/terran/Explore";
import Community, { PostDetail } from "./pages/terran/Community";
import WorkDetail, { EpisodeReader } from "./pages/terran/WorkDetail";
import { ChatPage } from "./pages/terran/ChatPanel";
import Write from "./pages/terran/Write";
import Admin from "./pages/terran/Admin";
import AdminLogin from "./pages/terran/AdminLogin";
import Profile from "./pages/terran/Profile";
import Info from "./pages/terran/Info";

function Router() {
  const [location] = useLocation();
  const search = useSearch();
  useEffect(() => {
    window.scrollTo(0, 0);
    if (location === "/") {
      document.title =
        "테란 | 가상국가 웹소설·웹툰·세계관 창작 커뮤니티 사이트";
    }
  }, [location, search]);
  return (
    <Layout>
      <Switch key={`${location}?${search}`}>
        <Route path="/" component={Home} />
        <Route path="/novels">{() => <Explore kind="novel" />}</Route>
        <Route path="/webtoons">{() => <Explore kind="webtoon" />}</Route>
        <Route path="/search">{() => <Explore />}</Route>
        <Route path="/community" component={Community} />
        <Route path="/chat" component={ChatPage} />
        <Route path="/work/:id/episode/:episodeId">
          {p => <EpisodeReader id={p.id} episodeId={p.episodeId} />}
        </Route>
        <Route path="/work/:id">{p => <WorkDetail id={p.id} />}</Route>
        <Route path="/post/:id">{p => <PostDetail id={p.id} />}</Route>
        <Route path="/write" component={Write} />
        <Route path="/profile" component={Profile} />
        <Route path="/admin/login" component={AdminLogin} />
        <Route path="/admin" component={Admin} />
        <Route path="/world">{() => <Info />}</Route>
        <Route path="/guide">{() => <Info guide />}</Route>
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}
export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <CommunityProvider>
            <Toaster theme="dark" position="bottom-right" />
            <ChatNotificationsProvider>
              <Router />
            </ChatNotificationsProvider>
          </CommunityProvider>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
