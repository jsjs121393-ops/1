import { describe, expect, it } from "vitest";
import type { ChatMessage } from "../../../shared/community";
import {
  chatMessagePreview,
  chatRoomLabel,
  collectNewChatMessages,
  parseChatNotificationPreferences,
  removeRoomNotifications,
} from "./chat-notifications";

function message(
  id: number,
  overrides: Partial<ChatMessage> = {}
): ChatMessage {
  return {
    id,
    room: "general",
    body: `test-${id}`,
    images: [],
    author: "Test author",
    authorId: 2,
    createdAt: "2026-11-10T00:00:00.000Z",
    hidden: false,
    ...overrides,
  };
}
const options = { selfAuthorId: 1, activeRoom: null, visible: true };

describe("collectNewChatMessages", () => {
  it("seeds initial history without notifications, including after a reload", () => {
    const feed = [message(5), message(1), message(3)];
    expect(collectNewChatMessages(feed, null, options)).toEqual({
      watermark: 5,
      messages: [],
    });
    expect(collectNewChatMessages(feed, null, options).messages).toEqual([]);
  });

  it("seeds an empty successful feed so subsequent messages are new", () => {
    const initial = collectNewChatMessages([], null, options);
    expect(initial.watermark).toBe(0);
    expect(
      collectNewChatMessages([message(1)], initial.watermark, options).messages
    ).toHaveLength(1);
  });

  it("sorts unordered new IDs, deduplicates, and excludes repeated polls", () => {
    const feed = [message(9), message(7), message(8), message(7), message(4)];
    const next = collectNewChatMessages(feed, 5, options);
    expect(next.messages.map(m => m.id)).toEqual([7, 8, 9]);
    expect(next.watermark).toBe(9);
    expect(
      collectNewChatMessages(feed, next.watermark, options).messages
    ).toEqual([]);
  });

  it("does not reduce its watermark when a newer message is absent or deleted", () => {
    expect(collectNewChatMessages([message(2)], 10, options)).toEqual({
      watermark: 10,
      messages: [],
    });
  });

  it("excludes self messages for a signed-in member", () => {
    const next = collectNewChatMessages(
      [message(2, { authorId: 1 }), message(3)],
      1,
      options
    );
    expect(next.messages.map(m => m.id)).toEqual([3]);
    expect(next.watermark).toBe(3);
  });

  it("excludes admin-only authorId zero but not zero for a signed-in member", () => {
    const adminMessage = message(2, { authorId: 0 });
    expect(
      collectNewChatMessages([adminMessage], 1, {
        ...options,
        selfAuthorId: 0,
      }).messages
    ).toEqual([]);
    expect(
      collectNewChatMessages([adminMessage], 1, options).messages
    ).toHaveLength(1);
  });

  it("does not notify a visible active room but includes other rooms", () => {
    const next = collectNewChatMessages(
      [message(2), message(3, { room: "world" })],
      1,
      { ...options, activeRoom: "general" }
    );
    expect(next.messages.map(m => m.room)).toEqual(["world"]);
    expect(next.watermark).toBe(3);
  });

  it("notifies the active room when the page is hidden", () => {
    expect(
      collectNewChatMessages([message(2)], 1, {
        ...options,
        activeRoom: "general",
        visible: false,
      }).messages
    ).toHaveLength(1);
  });

  it("filters hidden or unsupported-room messages while advancing their IDs", () => {
    const next = collectNewChatMessages(
      [
        message(2, { hidden: true }),
        message(3, { room: "private" }),
        message(4, { room: "creators" }),
      ],
      1,
      options
    );
    expect(next.messages.map(m => m.id)).toEqual([4]);
    expect(next.watermark).toBe(4);
  });

  it("classifies well-formed custom rooms without requiring a cached room list", () => {
    const room = "room_a1b2c3d4e5f6";
    const next = collectNewChatMessages(
      [message(2, { room, roomName: "시민 연구 모임" })],
      1,
      options
    );
    expect(next.messages).toEqual([
      message(2, { room, roomName: "시민 연구 모임" }),
    ]);
    expect(next.watermark).toBe(2);
    expect(
      collectNewChatMessages(next.messages, null, options).messages
    ).toEqual([]);
  });

  it("keeps self, hidden, and visible-active suppression for custom rooms", () => {
    const room = "room_a1b2c3d4e5f6";
    const feed = [
      message(2, { room, authorId: 1 }),
      message(3, { room, hidden: true }),
      message(4, { room }),
      message(5, { room: "room_012345abcdef" }),
    ];
    const next = collectNewChatMessages(feed, 1, {
      ...options,
      activeRoom: room,
    });
    expect(next.messages.map(m => m.id)).toEqual([5]);
    expect(next.watermark).toBe(5);
    expect(
      collectNewChatMessages(feed, 1, {
        ...options,
        activeRoom: room,
        visible: false,
      }).messages.map(m => m.id)
    ).toEqual([4, 5]);
  });

  it("rejects malformed custom room IDs while still advancing the watermark", () => {
    const feed = [
      message(2, { room: "room_abc" }),
      message(3, { room: "room_012345ABCDEf" }),
      message(4, { room: "room_012345abcdeg" }),
      message(5, { room: "room_012345abcdef\n" }),
      message(6, { room: "constructor" }),
    ];
    expect(collectNewChatMessages(feed, 1, options)).toEqual({
      watermark: 6,
      messages: [],
    });
  });

  it("ignores malformed IDs", () => {
    const next = collectNewChatMessages(
      [message(-1), message(Number.NaN), message(1.5), message(2)],
      0,
      options
    );
    expect(next.messages.map(m => m.id)).toEqual([2]);
  });

  it("resets a new identity's feed by seeding instead of replaying history", () => {
    const initial = collectNewChatMessages([message(5)], null, options);
    expect(
      collectNewChatMessages([message(6)], initial.watermark, options).messages
    ).toHaveLength(1);
    expect(
      collectNewChatMessages([message(6)], null, {
        ...options,
        selfAuthorId: 99,
      }).messages
    ).toEqual([]);
  });
});

describe("notification presentation and preferences", () => {
  it("renders the body or the image-only message summary", () => {
    expect(chatMessagePreview({ body: " hello ", images: ["one"] })).toBe(
      "hello"
    );
    expect(chatMessagePreview({ body: " ", images: ["one", "two"] })).toBe(
      "이미지 2장"
    );
  });

  it("labels all supported rooms", () => {
    expect(chatRoomLabel("general")).toBe("테란 라운지");
    expect(chatRoomLabel("world")).toBe("세계관 연구소");
    expect(chatRoomLabel("creators")).toBe("창작자 살롱");
  });

  it("prefers nonempty server names and never exposes custom or unknown IDs", () => {
    expect(chatRoomLabel("room_a1b2c3d4e5f6", " 시민 연구 모임 ")).toBe(
      "시민 연구 모임"
    );
    expect(chatRoomLabel("general", "새 라운지 이름")).toBe("새 라운지 이름");
    expect(chatRoomLabel("general", "  ")).toBe("테란 라운지");
    expect(chatRoomLabel("room_a1b2c3d4e5f6")).toBe("시민 채팅방");
    expect(chatRoomLabel("room_a1b2c3d4e5f6", "")).toBe("시민 채팅방");
    expect(chatRoomLabel("room_a1b2c3d4e5f6", "  ")).toBe("시민 채팅방");
    expect(chatRoomLabel("unknown")).toBe("시민 채팅방");
    expect(chatRoomLabel("constructor")).toBe("시민 채팅방");
  });

  it("validates built-ins and exact lowercase hexadecimal custom IDs", () => {
    for (const room of [
      "general",
      "world",
      "creators",
      "room_012345abcdef",
      "room_a1b2c3d4e5f6",
    ]) {
      expect(
        collectNewChatMessages([message(1, { room })], 0, options).messages
      ).toHaveLength(1);
    }
    for (const room of [
      "",
      "private",
      "constructor",
      "__proto__",
      "room_012345abcde",
      "room_012345abcdef0",
      "room_012345ABCDEf",
      "room_012345abcdeg",
      " room_012345abcdef",
      "room_012345abcdef\n",
      "room_012345abcdef\r\n",
    ]) {
      expect(
        collectNewChatMessages([message(1, { room })], 0, options).messages
      ).toEqual([]);
    }
  });

  it("mark-room-read removes only the selected custom room without mutation", () => {
    const feed = [
      message(1),
      message(2, { room: "room_a1b2c3d4e5f6" }),
      message(3, { room: "room_012345abcdef" }),
    ];
    expect(
      removeRoomNotifications(feed, "room_a1b2c3d4e5f6").map(m => m.id)
    ).toEqual([1, 3]);
    expect(feed).toHaveLength(3);
  });

  it("mark-room-read removes only relevant messages; all-read uses an empty inbox", () => {
    const feed = [message(1), message(2, { room: "world" }), message(3)];
    expect(removeRoomNotifications(feed, "general").map(m => m.id)).toEqual([
      2,
    ]);
    expect(feed).toHaveLength(3);
  });

  it("defaults in-app on, sound and browser off for absent or malformed storage", () => {
    for (const raw of [null, "not JSON", "null", "[]", "1", '"text"']) {
      expect(parseChatNotificationPreferences(raw)).toEqual({
        enabled: true,
        soundEnabled: false,
        browserEnabled: false,
      });
    }
  });

  it("accepts only boolean preferences and never persists extra fields", () => {
    expect(
      parseChatNotificationPreferences(
        JSON.stringify({
          enabled: false,
          soundEnabled: true,
          browserEnabled: true,
          token: "not-stored",
          messages: [1],
        })
      )
    ).toEqual({ enabled: false, soundEnabled: true, browserEnabled: true });
    expect(
      parseChatNotificationPreferences(
        JSON.stringify({
          enabled: "false",
          soundEnabled: 1,
          browserEnabled: "true",
        })
      )
    ).toEqual({ enabled: true, soundEnabled: false, browserEnabled: false });
  });
});
