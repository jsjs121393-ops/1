import type { ChatMessage } from "@shared/community";

export const CHAT_NOTIFICATION_PREFS_KEY = "terran-chat-notification-prefs";
export const CHAT_ROOM_LABELS: Readonly<Record<string, string>> = {
  general: "테란 라운지",
  world: "세계관 연구소",
  creators: "창작자 살롱",
};

export interface ChatNotificationPreferences {
  enabled: boolean;
  soundEnabled: boolean;
  browserEnabled: boolean;
}

export const DEFAULT_CHAT_NOTIFICATION_PREFERENCES: ChatNotificationPreferences =
  {
    enabled: true,
    soundEnabled: false,
    browserEnabled: false,
  };

export function parseChatNotificationPreferences(
  raw: string | null
): ChatNotificationPreferences {
  try {
    const value: unknown = raw ? JSON.parse(raw) : null;
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      return { ...DEFAULT_CHAT_NOTIFICATION_PREFERENCES };
    }
    const prefs = value as Record<string, unknown>;
    return {
      enabled: typeof prefs.enabled === "boolean" ? prefs.enabled : true,
      soundEnabled:
        typeof prefs.soundEnabled === "boolean" ? prefs.soundEnabled : false,
      browserEnabled:
        typeof prefs.browserEnabled === "boolean"
          ? prefs.browserEnabled
          : false,
    };
  } catch {
    return { ...DEFAULT_CHAT_NOTIFICATION_PREFERENCES };
  }
}

function isChatRoomId(room: string): boolean {
  return (
    Object.hasOwn(CHAT_ROOM_LABELS, room) ||
    (room.length === "room_".length + 12 && /^room_[a-f0-9]{12}$/.test(room))
  );
}

export function chatRoomLabel(room: string, optionalName?: string): string {
  const name = optionalName?.trim();
  if (name) return name;
  return Object.hasOwn(CHAT_ROOM_LABELS, room)
    ? CHAT_ROOM_LABELS[room]
    : "시민 채팅방";
}

export function chatMessagePreview(
  message: Pick<ChatMessage, "body"> & { images?: string[] }
): string {
  return message.body.trim() || `이미지 ${message.images?.length ?? 0}장`;
}

export interface NewChatMessageOptions {
  selfAuthorId: number | null;
  activeRoom: string | null;
  visible: boolean;
}

/** A null watermark seeds history. Even ignored messages advance the watermark. */
export function collectNewChatMessages(
  feed: readonly ChatMessage[],
  watermark: number | null,
  options: NewChatMessageOptions
): { watermark: number; messages: ChatMessage[] } {
  const byId = new Map<number, ChatMessage>();
  for (const message of feed) {
    if (Number.isSafeInteger(message.id) && message.id > 0) {
      byId.set(message.id, message);
    }
  }
  const sorted = [...byId.values()].sort((a, b) => a.id - b.id);
  const highest = sorted.at(-1)?.id ?? 0;
  const nextWatermark = Math.max(watermark ?? 0, highest);
  if (watermark === null) return { watermark: nextWatermark, messages: [] };

  return {
    watermark: nextWatermark,
    messages: sorted.filter(
      message =>
        message.id > watermark &&
        !message.hidden &&
        isChatRoomId(message.room) &&
        message.authorId !== options.selfAuthorId &&
        !(options.visible && message.room === options.activeRoom)
    ),
  };
}

export function removeRoomNotifications(
  messages: readonly ChatMessage[],
  room: string
): ChatMessage[] {
  return messages.filter(message => message.room !== room);
}
