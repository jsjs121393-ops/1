import type { Bootstrap } from "@shared/community";
import { COOKIE_NAME } from "@shared/const";

function memberToken(): string | undefined {
  try {
    const raw = sessionStorage.getItem("manus-cookie");
    if (!raw) return;
    try {
      const data = JSON.parse(raw);
      return typeof data === "string"
        ? data
        : (data?.value ?? data?.token ?? data?.webdev_app_session);
    } catch {
      const prefix = `${COOKIE_NAME}=`;
      const pair = raw.split(";").find(part => part.trim().startsWith(prefix));
      return pair
        ? pair.trim().slice(prefix.length)
        : raw.includes("=")
          ? undefined
          : raw;
    }
  } catch {
    return;
  }
}
export async function api<T = any>(
  path: string,
  method = "GET",
  body?: unknown
): Promise<T> {
  const headers: Record<string, string> = { "X-Terran-Client": "web" };
  const token = memberToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  try {
    const admin = sessionStorage.getItem("terran-admin");
    if (admin) headers["X-Terran-Admin"] = admin;
  } catch {}
  if (body !== undefined) headers["Content-Type"] = "application/json";
  const response = await fetch(`/api/community${path}`, {
    method,
    headers,
    credentials: "include",
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await response
    .json()
    .catch(() => ({ error: "서버 응답을 읽을 수 없습니다." }));
  if (!response.ok || data.error)
    throw new Error(data.error || "요청에 실패했습니다. 다시 시도해 주세요.");
  return data;
}
export const loadCommunity = () => api<Bootstrap>("/bootstrap");
export async function uploadImage(file: File): Promise<string> {
  if (
    !["image/jpeg", "image/png", "image/webp", "image/gif"].includes(file.type)
  )
    throw new Error("JPG, PNG, WEBP, GIF 이미지만 올릴 수 있습니다.");
  if (file.size > 10 * 1024 * 1024)
    throw new Error("이미지는 한 장당 10MB 이하로 올려 주세요.");
  const data = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1]);
    reader.onerror = () => reject(new Error("파일을 읽지 못했습니다."));
    reader.readAsDataURL(file);
  });
  return (
    await api<{ url: string }>("/upload", "POST", {
      name: file.name,
      type: file.type,
      data,
    })
  ).url;
}
export function dateLabel(value: string) {
  return new Date(value).toLocaleDateString("ko-KR", {
    month: "2-digit",
    day: "2-digit",
  });
}
export function timeLabel(value: string) {
  return new Date(value).toLocaleTimeString("ko-KR", {
    hour: "2-digit",
    minute: "2-digit",
  });
}
