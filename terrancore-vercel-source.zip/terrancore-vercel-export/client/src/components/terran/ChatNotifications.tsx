import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { useQuery } from "@tanstack/react-query";
import * as Popover from "@radix-ui/react-popover";
import { Bell, CheckCheck, X } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import type { ChatMessage, ChatRoom } from "@shared/community";
import { api, timeLabel } from "@/lib/community";
import {
  CHAT_NOTIFICATION_PREFS_KEY,
  CHAT_ROOM_LABELS,
  chatMessagePreview,
  chatRoomLabel,
  collectNewChatMessages,
  parseChatNotificationPreferences,
  removeRoomNotifications,
} from "@/lib/chat-notifications";
import { useCommunity } from "./CommunityProvider";

type AudioContextConstructor = new () => AudioContext;

function audioContextConstructor(): AudioContextConstructor | undefined {
  if (typeof window === "undefined") return undefined;
  return (
    window.AudioContext ??
    (window as Window & { webkitAudioContext?: AudioContextConstructor })
      .webkitAudioContext
  );
}

function supportsBrowserNotifications(): boolean {
  return (
    typeof window !== "undefined" &&
    window.isSecureContext &&
    "Notification" in window &&
    typeof window.Notification === "function"
  );
}

function loadPreferences() {
  try {
    return parseChatNotificationPreferences(
      window.localStorage.getItem(CHAT_NOTIFICATION_PREFS_KEY)
    );
  } catch {
    return parseChatNotificationPreferences(null);
  }
}

export interface ChatNotificationsContextValue {
  activeRoom: string | null;
  setActiveRoom: (room: string | null) => void;
  unreadCount: number;
  /** Unseen messages, oldest first; opening the bell does not mark them read. */
  notifications: ChatMessage[];
  markAllRead: () => void;
  markRoomRead: (room: string) => void;
  enabled: boolean;
  setEnabled: (enabled: boolean) => void;
  soundEnabled: boolean;
  toggleSound: () => void;
  browserEnabled: boolean;
  toggleBrowser: () => Promise<void>;
  browserSupported: boolean;
  browserPermission: NotificationPermission | null;
  browserPending: boolean;
  browserError: string | null;
  soundSupported: boolean;
  soundError: string | null;
  authenticated: boolean;
  loading: boolean;
  error: string | null;
}

const ChatNotificationsContext =
  createContext<ChatNotificationsContextValue | null>(null);

export function useChatNotifications(): ChatNotificationsContextValue {
  const context = useContext(ChatNotificationsContext);
  if (!context) {
    throw new Error(
      "useChatNotifications must be used within ChatNotificationsProvider"
    );
  }
  return context;
}

export function ChatNotificationsProvider({
  children,
}: {
  children: ReactNode;
}) {
  const { data } = useCommunity();
  const [, navigate] = useLocation();
  const identity = data.user
    ? `user:${data.user.id}`
    : data.admin
      ? "admin"
      : null;
  const selfAuthorId = data.user?.id ?? (data.admin ? 0 : null);
  const identityRef = useRef(identity);
  identityRef.current = identity;
  const requestSession = useRef({ identity, token: Symbol("chat-session") });
  if (requestSession.current.identity !== identity) {
    requestSession.current = { identity, token: Symbol("chat-session") };
  }
  const sessionToken = requestSession.current.token;
  const baseline = useRef<{
    identity: string | null;
    watermark: number | null;
  }>({
    identity: null,
    watermark: null,
  });
  const [inbox, setInbox] = useState<{
    identity: string | null;
    messages: ChatMessage[];
  }>({ identity: null, messages: [] });
  const [activeRoom, setActiveRoomState] = useState<string | null>(null);
  const activeRoomRef = useRef<string | null>(null);
  const [preferences, setPreferences] = useState(loadPreferences);
  const preferencesRef = useRef(preferences);
  preferencesRef.current = preferences;
  const browserSupported = supportsBrowserNotifications();
  const soundSupported = Boolean(audioContextConstructor());
  const [browserPermission, setBrowserPermission] =
    useState<NotificationPermission | null>(() =>
      browserSupported ? Notification.permission : null
    );
  const [browserPending, setBrowserPending] = useState(false);
  const permissionRequestPending = useRef(false);
  const [browserError, setBrowserError] = useState<string | null>(null);
  const [soundError, setSoundError] = useState<string | null>(null);
  const audioRef = useRef<AudioContext | null>(null);
  const systemNotification = useRef<{
    room: string;
    notification: Notification;
  } | null>(null);
  const toastIds = useRef<Set<string | number>>(new Set());

  // The response carries its requester identity so an old in-flight response
  // cannot seed or notify a newly logged-in account despite the shared query key.
  const query = useQuery({
    queryKey: ["chat-feed"],
    queryFn: async () => ({
      identity,
      sessionToken,
      messages: await api<ChatMessage[]>("/chat"),
    }),
    enabled: Boolean(identity),
    refetchInterval: 3000,
    refetchIntervalInBackground: true,
    refetchOnWindowFocus: true,
    staleTime: 0,
    retry: 1,
  });
  const { refetch } = query;

  const roomsQuery = useQuery({
    queryKey: ["chat-rooms"],
    queryFn: () => api<ChatRoom[]>("/rooms"),
    enabled: Boolean(identity),
    refetchInterval: 10000,
    refetchIntervalInBackground: true,
    refetchOnWindowFocus: true,
    staleTime: 0,
    retry: 1,
  });
  const prunedRoomListAt = useRef(0);

  const closeSystemNotification = useCallback(() => {
    systemNotification.current?.notification.close();
    systemNotification.current = null;
  }, []);

  const markAllRead = useCallback(() => {
    setInbox({ identity: identityRef.current, messages: [] });
    closeSystemNotification();
  }, [closeSystemNotification]);

  const markRoomRead = useCallback(
    (room: string) => {
      setInbox(current => ({
        identity: identityRef.current,
        messages:
          current.identity === identityRef.current
            ? removeRoomNotifications(current.messages, room)
            : [],
      }));
      if (systemNotification.current?.room === room) {
        closeSystemNotification();
      }
    },
    [closeSystemNotification]
  );

  const setActiveRoom = useCallback(
    (room: string | null) => {
      const next =
        room &&
        (Object.hasOwn(CHAT_ROOM_LABELS, room) ||
          (room.length === "room_".length + 12 &&
            /^room_[a-f0-9]{12}$/.test(room)))
          ? room
          : null;
      activeRoomRef.current = next;
      setActiveRoomState(next);
      if (next && document.visibilityState === "visible") markRoomRead(next);
    },
    [markRoomRead]
  );

  const openRoom = useCallback(
    (room: string) => {
      markRoomRead(room);
      navigate(`/chat?room=${encodeURIComponent(room)}`);
    },
    [markRoomRead, navigate]
  );

  useEffect(() => {
    baseline.current = { identity, watermark: null };
    setInbox({ identity, messages: [] });
    closeSystemNotification();
    toastIds.current.forEach(id => toast.dismiss(id));
    toastIds.current.clear();
    // Refetch immediately on login/account change; cached history is not reused
    // as the new account's initial feed. No request is started while logged out.
    if (identity) void refetch();
  }, [identity, refetch, closeSystemNotification]);

  useEffect(() => {
    if (
      !identity ||
      !roomsQuery.isSuccess ||
      roomsQuery.isFetching ||
      !roomsQuery.data ||
      roomsQuery.dataUpdatedAt === prunedRoomListAt.current
    )
      return;
    prunedRoomListAt.current = roomsQuery.dataUpdatedAt;
    const openRoomIds = new Set(
      roomsQuery.data.filter(room => !room.closed).map(room => room.id)
    );
    // Apply each successful list to the existing inbox only. Do not use a cached
    // list to classify incoming messages: a new room may not be cached yet.
    setInbox(current => {
      if (current.identity !== identity) return current;
      const messages = current.messages.filter(message =>
        openRoomIds.has(message.room)
      );
      return messages.length === current.messages.length
        ? current
        : { identity, messages };
    });
    if (
      systemNotification.current &&
      !openRoomIds.has(systemNotification.current.room)
    ) {
      closeSystemNotification();
    }
  }, [
    identity,
    roomsQuery.data,
    roomsQuery.dataUpdatedAt,
    roomsQuery.isSuccess,
    roomsQuery.isFetching,
    closeSystemNotification,
  ]);

  useEffect(() => {
    try {
      // Only these three booleans are persisted, never messages or identities.
      window.localStorage.setItem(
        CHAT_NOTIFICATION_PREFS_KEY,
        JSON.stringify(preferences)
      );
    } catch {
      // Private browsing/storage policies should not break in-memory settings.
    }
  }, [preferences]);

  useEffect(() => {
    function onVisibilityOrFocus() {
      if (document.visibilityState === "visible" && activeRoomRef.current) {
        markRoomRead(activeRoomRef.current);
      }
      if (browserSupported) {
        const permission = Notification.permission;
        setBrowserPermission(permission);
        if (permission !== "granted") {
          setPreferences(current => ({ ...current, browserEnabled: false }));
          closeSystemNotification();
        }
      }
    }
    document.addEventListener("visibilitychange", onVisibilityOrFocus);
    window.addEventListener("focus", onVisibilityOrFocus);
    // A saved preference cannot grant permission on a subsequent visit.
    if (!browserSupported || Notification.permission !== "granted") {
      setPreferences(current => ({ ...current, browserEnabled: false }));
    }
    return () => {
      document.removeEventListener("visibilitychange", onVisibilityOrFocus);
      window.removeEventListener("focus", onVisibilityOrFocus);
    };
  }, [browserSupported, closeSystemNotification, markRoomRead]);

  const unlockAudio = useCallback(() => {
    const Constructor = audioContextConstructor();
    if (!Constructor) return;
    try {
      if (!audioRef.current || audioRef.current.state === "closed") {
        audioRef.current = new Constructor();
      }
      // Called only from the toggle or another trusted pointer/keyboard gesture.
      const context = audioRef.current;
      void context.resume().then(
        () => {
          setSoundError(
            context.state === "running"
              ? null
              : "소리가 일시 중지되었습니다. 페이지를 눌러 다시 활성화해 주세요."
          );
        },
        () => {
          setSoundError(
            "브라우저가 소리 재생을 제한했습니다. 페이지를 눌러 다시 시도해 주세요."
          );
        }
      );
    } catch {
      setSoundError("이 브라우저에서 알림 소리를 활성화하지 못했습니다.");
    }
  }, []);

  const toggleSound = useCallback(() => {
    if (!soundSupported) return;
    const next = !preferencesRef.current.soundEnabled;
    preferencesRef.current = { ...preferencesRef.current, soundEnabled: next };
    setPreferences(current => ({ ...current, soundEnabled: next }));
    if (next) unlockAudio();
    else setSoundError(null);
  }, [soundSupported, unlockAudio]);

  useEffect(() => {
    if (!preferences.soundEnabled) return;
    function onGesture(event: Event) {
      if (event.isTrusted) unlockAudio();
    }
    window.addEventListener("pointerdown", onGesture, true);
    window.addEventListener("keydown", onGesture, true);
    return () => {
      window.removeEventListener("pointerdown", onGesture, true);
      window.removeEventListener("keydown", onGesture, true);
    };
  }, [preferences.soundEnabled, unlockAudio]);

  const toggleBrowser = useCallback(async () => {
    if (!browserSupported || permissionRequestPending.current) return;
    if (preferencesRef.current.browserEnabled) {
      preferencesRef.current = {
        ...preferencesRef.current,
        browserEnabled: false,
      };
      setPreferences(current => ({ ...current, browserEnabled: false }));
      closeSystemNotification();
      return;
    }
    setBrowserError(null);
    if (Notification.permission === "denied") {
      setBrowserPermission("denied");
      setBrowserError("브라우저 사이트 설정에서 알림 권한을 허용해 주세요.");
      return;
    }
    permissionRequestPending.current = true;
    setBrowserPending(true);
    try {
      // This method is called directly by the settings button, never by polling.
      const permission =
        Notification.permission === "granted"
          ? "granted"
          : await Notification.requestPermission();
      setBrowserPermission(permission);
      const next = permission === "granted";
      preferencesRef.current = {
        ...preferencesRef.current,
        browserEnabled: next,
      };
      setPreferences(current => ({ ...current, browserEnabled: next }));
      if (!next) {
        setBrowserError(
          permission === "denied"
            ? "알림 권한이 차단되었습니다. 브라우저 사이트 설정을 확인해 주세요."
            : "알림 권한이 허용되지 않았습니다. 켜기 버튼으로 다시 요청할 수 있습니다."
        );
      }
    } catch {
      setBrowserError(
        "이 앱/브라우저에서는 시스템 알림을 켤 수 없습니다. 앱 내 알림을 이용해 주세요."
      );
    } finally {
      permissionRequestPending.current = false;
      setBrowserPending(false);
    }
  }, [browserSupported, closeSystemNotification]);

  useEffect(() => {
    const result = query.data;
    if (
      !identity ||
      !result ||
      result.identity !== identity ||
      result.sessionToken !== sessionToken
    )
      return;
    if (baseline.current.identity !== identity) {
      baseline.current = { identity, watermark: null };
    }
    const batch = collectNewChatMessages(
      result.messages,
      baseline.current.watermark,
      {
        selfAuthorId,
        activeRoom: activeRoomRef.current,
        visible: document.visibilityState === "visible",
      }
    );
    baseline.current.watermark = batch.watermark;
    if (!batch.messages.length) return;
    setInbox(current => ({
      identity,
      messages: [
        ...(current.identity === identity ? current.messages : []),
        ...batch.messages,
      ],
    }));
    const latest = batch.messages[batch.messages.length - 1];
    const title = `${chatRoomLabel(latest.room, latest.roomName)} · ${latest.author}`;
    const summary = chatMessagePreview(latest);
    const description =
      batch.messages.length > 1
        ? `새 메시지 ${batch.messages.length}개 · ${summary}`
        : summary;

    if (preferencesRef.current.enabled) {
      let toastId: string | number;
      toastId = toast(title, {
        description,
        action: {
          label: "채팅 보기",
          onClick: () => {
            if (identityRef.current === identity) openRoom(latest.room);
          },
        },
        onDismiss: () => toastIds.current.delete(toastId),
        onAutoClose: () => toastIds.current.delete(toastId),
      });
      toastIds.current.add(toastId);
    }

    if (preferencesRef.current.soundEnabled) {
      const context = audioRef.current;
      if (context?.state === "running") {
        try {
          const oscillator = context.createOscillator();
          const gain = context.createGain();
          const start = context.currentTime;
          oscillator.type = "sine";
          oscillator.frequency.setValueAtTime(880, start);
          gain.gain.setValueAtTime(0, start);
          gain.gain.linearRampToValueAtTime(0.045, start + 0.015);
          gain.gain.exponentialRampToValueAtTime(0.001, start + 0.18);
          oscillator.connect(gain);
          gain.connect(context.destination);
          oscillator.onended = () => {
            oscillator.disconnect();
            gain.disconnect();
          };
          oscillator.start(start);
          oscillator.stop(start + 0.2);
        } catch {
          setSoundError("브라우저가 알림 소리 재생을 제한했습니다.");
        }
      } else {
        setSoundError("소리를 활성화하려면 페이지를 한 번 눌러 주세요.");
      }
    }

    if (
      browserSupported &&
      preferencesRef.current.browserEnabled &&
      Notification.permission === "granted" &&
      document.visibilityState === "hidden"
    ) {
      try {
        closeSystemNotification();
        const notification = new Notification(title, {
          body: description,
          tag: "terran-chat",
          // The explicit WebAudio toggle controls sound; avoid OS sound when off.
          silent: true,
        });
        systemNotification.current = { room: latest.room, notification };
        notification.onclick = () => {
          if (identityRef.current === identity) {
            window.focus();
            openRoom(latest.room);
          }
          notification.close();
        };
      } catch {
        setBrowserError(
          "이 앱/브라우저에서는 시스템 알림이 제한됩니다. 앱 내 알림을 이용해 주세요."
        );
      }
    }
  }, [
    query.data,
    identity,
    sessionToken,
    selfAuthorId,
    browserSupported,
    closeSystemNotification,
    openRoom,
  ]);

  useEffect(
    () => () => {
      closeSystemNotification();
      toastIds.current.forEach(id => toast.dismiss(id));
      toastIds.current.clear();
      const context = audioRef.current;
      if (context && context.state !== "closed") {
        void context.close().catch(() => undefined);
      }
    },
    [closeSystemNotification]
  );

  const notifications =
    identity && inbox.identity === identity ? inbox.messages : [];
  return (
    <ChatNotificationsContext.Provider
      value={{
        activeRoom,
        setActiveRoom,
        unreadCount: notifications.length,
        notifications,
        markAllRead,
        markRoomRead,
        enabled: preferences.enabled,
        setEnabled: enabled =>
          setPreferences(current => ({ ...current, enabled })),
        soundEnabled: preferences.soundEnabled,
        toggleSound,
        browserEnabled:
          browserSupported &&
          browserPermission === "granted" &&
          preferences.browserEnabled,
        toggleBrowser,
        browserSupported,
        browserPermission,
        browserPending,
        browserError,
        soundSupported,
        soundError,
        authenticated: Boolean(identity),
        loading:
          Boolean(identity) &&
          query.isFetching &&
          query.data?.sessionToken !== sessionToken,
        error:
          identity && query.error
            ? "채팅 알림 연결을 확인해 주세요. 잠시 후 다시 연결합니다."
            : null,
      }}
    >
      {children}
    </ChatNotificationsContext.Provider>
  );
}

export function ChatNotificationBell() {
  const chat = useChatNotifications();
  const [, navigate] = useLocation();
  const [open, setOpen] = useState(false);
  const latest = chat.notifications.slice(-20).reverse();
  const browserDisabled =
    !chat.browserSupported ||
    chat.browserPermission === "denied" ||
    chat.browserPending;

  return (
    <div className="notification-wrap">
      <Popover.Root open={open} onOpenChange={setOpen}>
        <Popover.Trigger asChild>
          <button
            type="button"
            className={`icon-btn notification-bell ${open ? "selected" : ""}`}
            aria-label={`채팅 알림${chat.unreadCount ? `, 읽지 않은 메시지 ${chat.unreadCount}개` : ", 읽지 않은 메시지 없음"}`}
          >
            <Bell size={19} aria-hidden="true" />
            {chat.unreadCount > 0 && (
              <span className="notification-badge" aria-hidden="true">
                {chat.unreadCount > 99 ? "99+" : chat.unreadCount}
              </span>
            )}
          </button>
        </Popover.Trigger>
        <Popover.Portal>
          <Popover.Content
            className="notification-popover chat-notification-popover"
            align="end"
            sideOffset={10}
            collisionPadding={12}
            aria-labelledby="chat-notification-title"
            style={{
              position: "relative",
              top: "auto",
              right: "auto",
              width: "min(380px, calc(100vw - 24px))",
              maxHeight: "min(680px, calc(100dvh - 96px))",
              overflowY: "auto",
              zIndex: 80,
            }}
          >
            <div className="notification-heading">
              <strong id="chat-notification-title">채팅 알림</strong>
              <span className="notification-unread-total" aria-live="polite">
                읽지 않음 {chat.unreadCount}개
              </span>
              <Popover.Close asChild>
                <button
                  type="button"
                  className="icon-btn"
                  aria-label="채팅 알림 닫기"
                >
                  <X size={16} aria-hidden="true" />
                </button>
              </Popover.Close>
            </div>
            <div className="notification-read-actions">
              <button
                type="button"
                onClick={chat.markAllRead}
                disabled={!chat.unreadCount}
                className="notification-text-button"
              >
                <CheckCheck size={14} aria-hidden="true" /> 모두 읽음
              </button>
              <button
                type="button"
                onClick={chat.markAllRead}
                disabled={!chat.unreadCount}
                className="notification-text-button"
                aria-label="읽지 않은 채팅 알림 배지 지우기"
              >
                배지 지우기
              </button>
            </div>
            {!chat.authenticated ? (
              <p className="notification-empty">
                로그인하면 새 채팅 알림을 받을 수 있어요.
              </p>
            ) : chat.loading ? (
              <p className="notification-empty" role="status">
                채팅 알림을 연결하는 중입니다.
              </p>
            ) : !latest.length ? (
              <p className="notification-empty">
                읽지 않은 새 메시지가 없습니다.
              </p>
            ) : (
              <ul
                className="notification-list"
                aria-label="읽지 않은 채팅 메시지"
              >
                {latest.map(message => (
                  <li key={message.id}>
                    <button
                      type="button"
                      className="notification-message"
                      onClick={() => {
                        chat.markRoomRead(message.room);
                        setOpen(false);
                        navigate(
                          `/chat?room=${encodeURIComponent(message.room)}`
                        );
                      }}
                      aria-label={`${chatRoomLabel(message.room, message.roomName)}, ${message.author}: ${chatMessagePreview(message)}. 채팅방으로 이동하고 이 방의 알림 읽음 처리`}
                    >
                      <span className="notification-message-meta">
                        <span className="notification-room">
                          {chatRoomLabel(message.room, message.roomName)}
                        </span>
                        <time dateTime={message.createdAt}>
                          {timeLabel(message.createdAt)}
                        </time>
                      </span>
                      <strong className="notification-author">
                        {message.author}
                      </strong>
                      <span className="notification-message-body">
                        {chatMessagePreview(message)}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
            {chat.unreadCount > 20 && (
              <p className="notification-note">
                최근 읽지 않은 메시지 20개를 표시합니다.
              </p>
            )}
            {chat.error && (
              <p className="notification-warning" role="status">
                {chat.error}
              </p>
            )}
            <fieldset className="notification-settings">
              <legend>알림 설정</legend>
              <label className="notification-setting">
                <span>앱 내 팝업</span>
                <input
                  type="checkbox"
                  checked={chat.enabled}
                  onChange={event => chat.setEnabled(event.target.checked)}
                  aria-label="앱 내 채팅 팝업 알림"
                />
              </label>
              <label className="notification-setting">
                <span>알림 소리</span>
                <input
                  type="checkbox"
                  checked={chat.soundEnabled}
                  onChange={chat.toggleSound}
                  disabled={!chat.soundSupported}
                  aria-label="채팅 알림 소리"
                  aria-describedby="chat-sound-help"
                />
              </label>
              <p id="chat-sound-help" className="notification-note">
                {!chat.soundSupported
                  ? "이 브라우저는 알림 소리 재생을 지원하지 않습니다."
                  : (chat.soundError ??
                    "소리를 켠 후에도 브라우저 정책에 따라 재생이 제한될 수 있습니다.")}
              </p>
              <div className="notification-setting">
                <span id="chat-browser-label">브라우저 알림</span>
                <button
                  type="button"
                  role="switch"
                  aria-checked={chat.browserEnabled}
                  aria-labelledby="chat-browser-label"
                  aria-describedby="chat-browser-help"
                  className={`notification-toggle ${chat.browserEnabled ? "on" : ""}`}
                  disabled={browserDisabled}
                  onClick={() => void chat.toggleBrowser()}
                >
                  {chat.browserPending
                    ? "요청 중"
                    : chat.browserEnabled
                      ? "켜짐"
                      : "꺼짐"}
                </button>
              </div>
              <p id="chat-browser-help" className="notification-note">
                {!chat.browserSupported
                  ? "이 앱/브라우저에서는 시스템 알림을 지원하지 않거나 보안 연결이 필요합니다."
                  : chat.browserPermission === "denied"
                    ? "알림 권한이 차단되었습니다. 브라우저 사이트 설정에서 허용해 주세요."
                    : (chat.browserError ??
                      "페이지가 뒤로 전환되었을 때만 시스템 알림을 표시합니다.")}
              </p>
              <p className="notification-note">
                앱 내 팝업을 꺼도 읽지 않은 메시지는 보관됩니다.
              </p>
            </fieldset>
            <p className="notification-footnote">
              페이지를 열어둔 동안 알림 · 모바일 앱/브라우저에 따라 시스템 알림
              제한
              <br />
              페이지를 닫으면 알림을 받을 수 없고, 백그라운드에서는 갱신이
              늦어질 수 있습니다.
            </p>
          </Popover.Content>
        </Popover.Portal>
      </Popover.Root>
    </div>
  );
}
