import { Link } from "wouter";
import { BookOpen, Image, ArrowUpRight } from "lucide-react";
import type { Work } from "@shared/community";
export function WorkCard({ work }: { work: Work }) {
  return (
    <Link href={`/work/${work.id}`} className="work-card">
      <div className="cover-wrap">
        {work.cover ? (
          <img
            src={work.cover}
            alt={`${work.title} 작품 표지`}
            loading="lazy"
          />
        ) : (
          <div className="blank-cover">
            <BookOpen size={40} />
            <span>{work.title}</span>
          </div>
        )}
        <span className={`content-badge ${work.kind}`}>
          {work.kind === "novel" ? "웹소설" : "웹툰"}
        </span>
        <div className="cover-hover">
          <ArrowUpRight size={28} />
        </div>
        <span className="cover-status">
          {work.status === "completed" ? "완결" : "연재 중"}
        </span>
      </div>
      <div className="work-genre">
        {work.genre}
        <span>·</span>
        {work.tags[0] ?? "테란 세계관"}
      </div>
      <h3>{work.title}</h3>
      <div className="work-meta">
        <span>{work.author}</span>
        <span>
          {work.kind === "novel" ? <BookOpen size={12} /> : <Image size={12} />}{" "}
          {work.episodes.length}화
        </span>
      </div>
    </Link>
  );
}
