import { createContext, useContext, useState, type ReactNode } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { X, ArrowUpRight, ShieldCheck, LoaderCircle } from "lucide-react";
import { Link } from "wouter";
import { startLogin } from "@/const";
import { api, loadCommunity } from "@/lib/community";
import type { Bootstrap } from "@shared/community";

const empty: Bootstrap = {
  user: null,
  admin: false,
  works: [],
  posts: [],
  messages: [],
  stats: { members: 0, works: 0, posts: 0, messages: 0 },
};
interface CommunityContext {
  data: Bootstrap;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<unknown>;
  requireLogin: () => boolean;
  login: () => void;
  mutate: <T = any>(path: string, method: string, body?: unknown) => Promise<T>;
}
const Context = createContext<CommunityContext>(null!);
export const useCommunity = () => useContext(Context);
export function CommunityProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  const [showLogin, setShowLogin] = useState(false);
  const query = useQuery({
    queryKey: ["community"],
    queryFn: loadCommunity,
    retry: 1,
    refetchOnWindowFocus: true,
  });
  const data = query.data ?? empty;
  const refresh = () =>
    queryClient.invalidateQueries({ queryKey: ["community"] });
  async function mutate<T = any>(
    path: string,
    method: string,
    body?: unknown
  ): Promise<T> {
    try {
      const result = await api<T>(path, method, body);
      await refresh();
      return result;
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "요청에 실패했습니다."
      );
      throw error;
    }
  }
  function requireLogin() {
    if (data.user || data.admin) return true;
    setShowLogin(true);
    return false;
  }
  return (
    <Context.Provider
      value={{
        data,
        loading: query.isLoading,
        error: query.error?.message ?? null,
        refresh,
        requireLogin,
        login: () => setShowLogin(true),
        mutate,
      }}
    >
      {children}
      {showLogin && (
        <div className="modal-backdrop" onClick={() => setShowLogin(false)}>
          <section
            className="modal login-modal"
            role="dialog"
            aria-modal="true"
            aria-label="테란 가입 및 로그인"
            onClick={e => e.stopPropagation()}
          >
            <button
              className="icon-btn modal-close"
              aria-label="닫기"
              onClick={() => setShowLogin(false)}
            >
              <X size={20} />
            </button>
            <div className="login-orbit">
              <ShieldCheck size={32} />
            </div>
            <span className="eyebrow">YOUR NEXT CHAPTER</span>
            <h2>테란의 시민이 되어 주세요.</h2>
            <p>
              이야기를 연재하고, 생각을 나누고,
              <br />
              함께 새로운 세계를 만들어 보세요.
            </p>
            <button
              className="primary-btn wide"
              onClick={() => {
                try {
                  startLogin();
                } catch {
                  toast.error(
                    "로그인을 시작하지 못했습니다. 다시 시도해 주세요."
                  );
                }
              }}
            >
              Manus 계정으로 가입 · 로그인 <ArrowUpRight size={18} />
            </button>
            <p className="fineprint">
              첫 로그인 시 테란 회원 프로필이 생성됩니다.
              <br />
              관리자는 별도의 관리자 화면에서 로그인해 주세요.
            </p>
            <Link
              href="/admin/login"
              className="modal-admin-link"
              onClick={() => setShowLogin(false)}
            >
              <ShieldCheck size={15} />
              관리자 로그인으로 이동
              <ArrowUpRight size={14} />
            </Link>
          </section>
        </div>
      )}
    </Context.Provider>
  );
}
export function DataStatus() {
  const { loading, error, refresh } = useCommunity();
  return loading ? (
    <div className="status-message">
      <LoaderCircle size={18} className="spin" /> 테란의 기록을 불러오는
      중입니다.
    </div>
  ) : error ? (
    <div className="error-message">
      {error}
      <button onClick={() => refresh()}>다시 불러오기</button>
    </div>
  ) : null;
}
