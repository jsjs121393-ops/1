import { useEffect, useRef, useState } from "react";
import {
  Hash,
  Plus,
  Search,
  X,
  Check,
  LoaderCircle,
  Users,
  LockKeyhole,
  Radio,
  ArrowRight,
} from "lucide-react";
import type { ChatRoom } from "@shared/community";
import { api } from "@/lib/community";
import { useCommunity } from "./CommunityProvider";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";

export function ChatRoomDirectory({
  rooms,
  activeId,
  onSelect,
  loading,
  error,
  onRetry,
}: {
  rooms: ChatRoom[];
  activeId: string;
  onSelect: (id: string) => void;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
}) {
  const [search, setSearch] = useState("");
  const [creating, setCreating] = useState(false);
  const { requireLogin } = useCommunity();
  const filtered = rooms.filter(room =>
    `${room.name} ${room.description} ${room.creator}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );
  const groups = [
    { name: "테란 공용 채널", rooms: filtered.filter(r => r.isDefault) },
    { name: "시민이 연 채팅방", rooms: filtered.filter(r => !r.isDefault) },
  ];
  return (
    <aside className="room-directory" aria-label="채팅방 목록">
      <div className="room-directory-heading">
        <div>
          <span className="eyebrow">OPEN FREQUENCIES</span>
          <h2>채팅방 탐색</h2>
        </div>
        <span className="room-count">{rooms.length}개</span>
      </div>
      <button
        className="primary-btn room-create-button"
        onClick={() => {
          if (requireLogin()) setCreating(true);
        }}
      >
        <Plus size={17} /> 새 채팅방 만들기
      </button>
      <label className="room-search">
        <Search size={15} />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="방 이름이나 주제로 검색"
          aria-label="채팅방 검색"
          maxLength={100}
        />
      </label>
      <div className="room-directory-list">
        {loading && (
          <div className="room-list-state">
            <LoaderCircle size={18} className="spin" />
            채팅방을 찾는 중...
          </div>
        )}
        {error && (
          <div className="room-list-state">
            <p>{error}</p>
            <button onClick={onRetry}>다시 불러오기</button>
          </div>
        )}
        {!loading &&
          !error &&
          groups.map(group => (
            <section className="room-group" key={group.name}>
              <h3>
                {group.name}
                <span>{group.rooms.length}</span>
              </h3>
              {group.rooms.map(room => (
                <button
                  className={`room-card ${room.id === activeId ? "active" : ""}`}
                  key={room.id}
                  onClick={() => onSelect(room.id)}
                >
                  <span className="room-card-icon">
                    {room.isDefault ? <Radio size={17} /> : <Hash size={19} />}
                  </span>
                  <span className="room-card-copy">
                    <strong>{room.name}</strong>
                    <span>
                      {room.description ||
                        "함께 이야기하며 채워갈 새로운 공간."}
                    </span>
                    <small>
                      {room.isDefault
                        ? "테란 공용 채널"
                        : `${room.creator} 개설`}
                      <i />
                      메시지 {room.messageCount}개
                    </small>
                  </span>
                  <ArrowRight className="room-card-arrow" size={15} />
                </button>
              ))}
              {!group.rooms.length && (
                <p className="room-empty-small">
                  {search
                    ? "검색한 채팅방이 없습니다."
                    : group.name === "시민이 연 채팅방"
                      ? "당신만의 첫 채팅방을 열어 보세요."
                      : "열린 공용 채널이 없습니다."}
                </p>
              )}
            </section>
          ))}
      </div>
      <div className="room-directory-note">
        <Users size={17} />
        <p>
          같은 관심사를 가진 시민들과
          <br />
          당신만의 공간을 만들어 보세요.
        </p>
      </div>
      {creating && (
        <ChatRoomEditor
          onClose={() => setCreating(false)}
          onSaved={room => {
            setCreating(false);
            onSelect(room.id);
          }}
        />
      )}
    </aside>
  );
}
export function ChatRoomEditor({
  room,
  onClose,
  onSaved,
}: {
  room?: ChatRoom;
  onClose: () => void;
  onSaved: (room: ChatRoom) => void;
}) {
  const [name, setName] = useState(room?.name ?? "");
  const [description, setDescription] = useState(room?.description ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const queryClient = useQueryClient();
  const dialog = useRef<HTMLElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    dialog.current?.querySelector<HTMLInputElement>("input")?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !busy) onClose();
      if (e.key === "Tab") {
        const focusable = Array.from(
          dialog.current?.querySelectorAll<HTMLElement>(
            "button:not([disabled]),input:not([disabled]),textarea:not([disabled])"
          ) ?? []
        );
        const first = focusable[0],
          last = focusable.at(-1);
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last?.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first?.focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      previous?.focus();
    };
  }, [busy, onClose]);
  async function refreshRooms() {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ["chat-rooms"] }),
      queryClient.invalidateQueries({ queryKey: ["chat-feed"] }),
      queryClient.invalidateQueries({ queryKey: ["community"] }),
    ]);
  }
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (name.trim().length < 2) {
      setError("채팅방 이름을 2자 이상 입력해 주세요.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const result = await api<ChatRoom>(
        room ? `/rooms/${encodeURIComponent(room.id)}` : "/rooms",
        room ? "PATCH" : "POST",
        { name: name.trim(), description: description.trim() }
      );
      await refreshRooms();
      toast.success(
        room ? "채팅방 정보를 수정했습니다." : "새로운 채팅방이 열렸습니다."
      );
      onSaved(result);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "채팅방을 저장하지 못했습니다."
      );
    } finally {
      setBusy(false);
    }
  }
  async function closeRoom() {
    if (
      !room ||
      !window.confirm(
        "이 채팅방을 닫을까요? 공개 목록과 알림에서 제외되며 이전 메시지는 보관됩니다."
      )
    )
      return;
    setBusy(true);
    setError("");
    try {
      const result = await api<ChatRoom>(
        `/rooms/${encodeURIComponent(room.id)}`,
        "PATCH",
        { closed: true }
      );
      await refreshRooms();
      toast.success("채팅방이 닫혔습니다. 이전 메시지는 보관됩니다.");
      onSaved(result);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "채팅방을 닫지 못했습니다."
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <div
      className="modal-backdrop room-modal-backdrop"
      onClick={() => {
        if (!busy) onClose();
      }}
    >
      <section
        ref={dialog}
        className="modal room-editor-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="room-editor-title"
        onClick={e => e.stopPropagation()}
      >
        <button
          type="button"
          className="icon-btn modal-close"
          aria-label="채팅방 창 닫기"
          disabled={busy}
          onClick={onClose}
        >
          <X size={20} />
        </button>
        <span className="room-editor-emblem">
          <Hash size={28} />
        </span>
        <span className="eyebrow">A SPACE OF YOUR OWN</span>
        <h2 id="room-editor-title">
          {room ? "채팅방 관리" : "새로운 대화의 시작."}
        </h2>
        <p>
          {room
            ? "채팅방 정보를 수정하거나 대화를 마무리하세요."
            : "원하는 주제로 시민들과 이야기할 공간을 열어 보세요."}
        </p>
        <form onSubmit={submit}>
          <label>
            채팅방 이름 <span>{name.length}/40</span>
            <input
              value={name}
              onChange={e => setName(e.target.value)}
              minLength={2}
              maxLength={40}
              required
              disabled={busy}
              placeholder="예: 테란 함대 설정 연구회"
            />
          </label>
          <label>
            채팅방 소개 <span>{description.length}/200</span>
            <textarea
              value={description}
              onChange={e => setDescription(e.target.value)}
              maxLength={200}
              rows={3}
              disabled={busy}
              placeholder="어떤 이야기를 나누고 싶나요?"
            />
          </label>
          <div className="room-visibility">
            <Users size={16} />
            <span>
              공개 채팅방 · 모든 시민이 탐색하고 대화에 참여할 수 있어요.
            </span>
          </div>
          {error && (
            <div className="error-message" role="alert">
              {error}
            </div>
          )}
          <button className="primary-btn wide" disabled={busy}>
            {busy ? (
              <LoaderCircle className="spin" size={17} />
            ) : room ? (
              <Check size={17} />
            ) : (
              <Plus size={17} />
            )}{" "}
            {room ? "변경 사항 저장" : "채팅방 개설하기"}
          </button>
        </form>
        {room && !room.isDefault && (
          <button
            className="room-close-action"
            onClick={closeRoom}
            disabled={busy}
          >
            <LockKeyhole size={14} />
            채팅방 닫기
          </button>
        )}
        <p className="fineprint">
          {room
            ? "개설자와 관리자만 채팅방을 변경할 수 있습니다."
            : "개설 후 방 정보 수정과 닫기는 개설자 또는 관리자만 가능합니다."}
        </p>
      </section>
    </div>
  );
}
