import { useState, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import {
  Home,
  BookOpen,
  PanelsTopLeft,
  MessagesSquare,
  MessageCircle,
  Search,
  ArrowUpRight,
  ArrowRight,
  Shield,
  Orbit,
  ChevronRight,
  Menu,
  X,
  Compass,
  LogOut,
  UserRound,
  PenLine,
} from "lucide-react";
import { ChatNotificationBell } from "./ChatNotifications";
import { useCommunity } from "./CommunityProvider";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";

export function Brand({ small = false }: { small?: boolean }) {
  return (
    <Link
      href="/"
      className={`brand ${small ? "small" : ""}`}
      aria-label="테란 홈"
    >
      <svg viewBox="0 0 40 40" aria-hidden="true">
        <path d="M20 4 36 32h-9L20 19 13 32H4L20 4Z" fill="currentColor" />
        <path d="M11 26h18l-4 7H15Z" fill="#e4f3ff" />
      </svg>
      <span>
        TERRAN<span className="brand-caption">WORLD BUILDING COMMUNITY</span>
      </span>
    </Link>
  );
}
const links = [
  { path: "/", label: "홈", icon: Home },
  { path: "/novels", label: "웹소설", icon: BookOpen },
  { path: "/webtoons", label: "웹툰", icon: PanelsTopLeft },
  { path: "/community", label: "커뮤니티", icon: MessagesSquare },
  { path: "/chat", label: "실시간 채팅", icon: MessageCircle },
];
export function Layout({ children }: { children: ReactNode }) {
  const [location, navigate] = useLocation();
  const { data, login, refresh } = useCommunity();
  const { logout } = useAuth();
  const [mobile, setMobile] = useState(false);
  const [search, setSearch] = useState("");
  const title =
    links.find(l => l.path !== "/" && location.startsWith(l.path))?.label ??
    (location.startsWith("/admin")
      ? "관리자 콘솔"
      : location.startsWith("/work")
        ? "이야기 아카이브"
        : location.startsWith("/write")
          ? "창작 스튜디오"
          : location.startsWith("/profile")
            ? "내 프로필"
            : "홈");
  const searchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) {
      navigate(`/search?q=${encodeURIComponent(search.trim())}`);
      setMobile(false);
    }
  };
  return (
    <div className="app-layout">
      {mobile && (
        <button
          className="sidebar-shade"
          aria-label="메뉴 닫기"
          onClick={() => setMobile(false)}
        />
      )}
      <aside className={`sidebar ${mobile ? "open" : ""}`}>
        <div className="sidebar-brand">
          <Brand />
          <button
            className="icon-btn mobile-close"
            aria-label="메뉴 닫기"
            onClick={() => setMobile(false)}
          >
            <X size={20} />
          </button>
        </div>
        <div className="sidebar-label">EXPLORE TERRAN</div>
        <nav className="main-nav">
          {links.map(({ path, label, icon: Icon }) => (
            <Link
              key={path}
              href={path}
              className={`nav-item ${location === path || (path !== "/" && location.startsWith(path)) ? "active" : ""}`}
              onClick={() => setMobile(false)}
            >
              <Icon size={19} />
              <span>{label}</span>
              {path === "/chat" && <i className="live-dot" />}
            </Link>
          ))}
        </nav>
        <div className="sidebar-label archive-label">테란 아카이브</div>
        <nav className="main-nav">
          <Link
            href="/world"
            className={`nav-item ${location === "/world" ? "active" : ""}`}
            onClick={() => setMobile(false)}
          >
            <Orbit size={19} />
            <span>세계관 안내</span>
            <ArrowUpRight size={14} className="nav-end" />
          </Link>
          <Link
            href="/guide"
            className={`nav-item ${location === "/guide" ? "active" : ""}`}
            onClick={() => setMobile(false)}
          >
            <Compass size={19} />
            <span>이용 안내</span>
          </Link>
        </nav>
        <div className="sidebar-bottom">
          <div className="citizen-card">
            <div className="mini-stars">
              ✦ <span>THE NEXT STORY IS YOURS</span>
            </div>
            <h3>
              당신의 이야기가
              <br />
              테란의 역사가 됩니다.
            </h3>
            <button
              onClick={() => {
                setMobile(false);
                data.user || data.admin ? navigate("/write") : login();
              }}
            >
              {data.user || data.admin
                ? "새로운 이야기 쓰기"
                : "테란 시민으로 합류하기"}
              <ArrowRight size={15} />
            </button>
          </div>
          <Link
            href={data.admin ? "/admin" : "/admin/login"}
            className="admin-link"
            onClick={() => setMobile(false)}
          >
            <Shield size={14} /> {data.admin ? "관리자 센터" : "관리자 로그인"}{" "}
            <ChevronRight size={14} />
          </Link>
          <div className="sidebar-copyright">© 2026 TERRAN COMMUNITY</div>
        </div>
      </aside>
      <div className="main-shell">
        <header className="topbar">
          <div className="breadcrumb">
            <button
              className="icon-btn mobile-menu"
              aria-label="메뉴 열기"
              onClick={() => setMobile(true)}
            >
              <Menu size={22} />
            </button>
            <span>{title}</span>
            <ChevronRight size={14} />
            <span className="breadcrumb-muted">테란 커뮤니티</span>
          </div>
          <form className="header-search" onSubmit={searchSubmit}>
            <Search size={16} />
            <input
              aria-label="작품 및 게시글 검색"
              placeholder="어떤 이야기를 찾고 있나요?"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
            <kbd>↵</kbd>
          </form>
          <div className="topbar-actions">
            <ChatNotificationBell />
            {!data.admin && (
              <Link className="admin-entry-link" href="/admin/login">
                <Shield size={15} />
                <span>관리자 로그인</span>
              </Link>
            )}
            {data.user ? (
              <Link href="/profile" className="user-chip">
                <span className="avatar">
                  {(data.user.name ?? "시민").slice(0, 1)}
                </span>
                <span>{data.user.name ?? "테란 시민"}</span>
              </Link>
            ) : data.admin ? (
              <Link href="/admin" className="login-button">
                <Shield size={15} /> 관리자
              </Link>
            ) : (
              <button className="login-button" onClick={login}>
                시민 로그인 <ArrowUpRight size={15} />
              </button>
            )}
            {data.user && (
              <button
                className="icon-btn logout-btn"
                aria-label="로그아웃"
                onClick={async () => {
                  try {
                    await logout();
                    await refresh();
                    toast.success("로그아웃했습니다.");
                  } catch {
                    toast.error("로그아웃에 실패했습니다.");
                  }
                }}
              >
                <LogOut size={16} />
              </button>
            )}
          </div>
        </header>
        <main className="page-content">{children}</main>
        <footer className="footer">
          <Brand small />
          <span>모든 이야기의 시작, 테란.</span>
          <div>
            <Link href="/guide">커뮤니티 가이드</Link>
            <Link href={data.admin ? "/admin" : "/admin/login"}>
              {data.admin ? "관리자 센터" : "관리자 로그인"}
            </Link>
          </div>
        </footer>
      </div>
    </div>
  );
}
