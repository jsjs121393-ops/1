import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  ArrowRight,
  ArrowUpRight,
  Orbit,
  Megaphone,
  ChevronRight,
  MessageCircle,
  Sparkles,
  BookOpen,
  Send,
  Plus,
  Globe2,
} from "lucide-react";
import { ART } from "@shared/community";
import {
  useCommunity,
  DataStatus,
} from "@/components/terran/CommunityProvider";
import { WorkCard } from "@/components/terran/WorkCard";
import { dateLabel } from "@/lib/community";
import ChatPanel from "./terran/ChatPanel";

export default function Home() {
  const { data } = useCommunity();
  const [tab, setTab] = useState("all");
  const [, navigate] = useLocation();
  const works = data.works
    .filter(w => tab === "all" || w.kind === tab)
    .slice(0, 4);
  return (
    <div className="home-page">
      <section className="hero">
        <img
          className="hero-image"
          src={ART.hero}
          alt="푸른 테란 행성의 궤도를 항해하는 우주 함대"
        />
        <div className="hero-overlay" />
        <div className="hero-grid" />
        <div className="hero-copy">
          <div className="hero-eyebrow">
            <span />
            <span>가상국가, 무한한 이야기</span>
          </div>
          <h1>
            우리의 상상이,
            <br />
            하나의 <em>세계</em>가 되다.
          </h1>
          <p>
            별 너머의 새로운 세계, 테란.
            <br />
            당신의 이야기로 이 우주를 채워 주세요.
          </p>
          <div className="hero-buttons">
            <Link href="/novels" className="primary-btn">
              작품 둘러보기 <ArrowRight size={17} />
            </Link>
            <Link href="/world" className="hero-secondary">
              테란 알아보기 <ArrowUpRight size={16} />
            </Link>
          </div>
          <div className="hero-stats">
            <div>
              <strong>{data.stats.works.toLocaleString()}</strong>
              <span>개의 이야기</span>
            </div>
            <i />
            <div>
              <strong>{data.stats.members.toLocaleString()}</strong>
              <span>명의 테란 시민</span>
            </div>
            <i />
            <div className="hero-world">
              <span className="live-dot" />
              <span>함께 만들어 가는 세계</span>
            </div>
          </div>
        </div>
        <div className="hero-coordinate">
          <span>EXPLORE THE UNWRITTEN</span>
          <span>SECTOR 01 / TERRAN</span>
        </div>
        <div className="hero-pagination">
          <span className="active" />
          <span />
          <span />
          <small>01 — 03</small>
        </div>
      </section>
      <div className="announcement">
        <div>
          <Megaphone size={16} />
          <span className="announcement-tag">공지</span>
          <Link
            href={
              data.posts.find(p => p.pinned)
                ? `/post/${data.posts.find(p => p.pinned)!.id}`
                : "/guide"
            }
          >
            테란 커뮤니티에 오신 것을 환영합니다. 우리 세계의 첫 페이지를 함께
            열어 주세요.
          </Link>
          <span className="new-label">NEW</span>
        </div>
        <Link href="/guide" aria-label="이용 안내 보기">
          <ChevronRight size={18} />
        </Link>
      </div>
      <DataStatus />
      <div className="home-columns">
        <div className="home-main">
          <section className="stories-section">
            <div className="section-heading">
              <h2>
                <Sparkles size={20} /> 지금, 테란이 주목하는 이야기
              </h2>
              <Link href="/novels" className="more-link">
                전체 보기 <ArrowUpRight size={15} />
              </Link>
            </div>
            <div className="story-tabs">
              <button
                className={tab === "all" ? "active" : ""}
                onClick={() => setTab("all")}
              >
                전체
              </button>
              <button
                className={tab === "novel" ? "active" : ""}
                onClick={() => setTab("novel")}
              >
                웹소설
              </button>
              <button
                className={tab === "webtoon" ? "active" : ""}
                onClick={() => setTab("webtoon")}
              >
                웹툰
              </button>
              <span className="tab-note">당신을 기다리는 새로운 세계</span>
            </div>
            <div className="work-grid">
              {works.map(w => (
                <WorkCard key={w.id} work={w} />
              ))}
            </div>
            {!works.length && (
              <div className="empty-state compact">
                <BookOpen size={28} />
                <p>새로운 이야기의 첫 번째 작가가 되어 보세요.</p>
              </div>
            )}
          </section>
          <section className="community-section">
            <div className="section-heading">
              <h2>
                <MessagesIcon /> 시민들의 이야기
              </h2>
              <Link href="/community" className="more-link">
                게시판 가기 <ArrowUpRight size={15} />
              </Link>
            </div>
            <div className="board-summary">
              {data.posts.slice(0, 4).map(p => (
                <Link href={`/post/${p.id}`} key={p.id} className="post-row">
                  <span
                    className={`category-label ${p.pinned ? "notice" : ""}`}
                  >
                    {p.category}
                  </span>
                  <strong>{p.title}</strong>
                  {p.comments.length > 0 && (
                    <span className="comment-count">{p.comments.length}</span>
                  )}
                  <span className="post-author">{p.author}</span>
                  <span className="post-date">{dateLabel(p.createdAt)}</span>
                </Link>
              ))}
            </div>
          </section>
        </div>
        <aside className="home-aside">
          <section className="mini-chat">
            <div className="section-heading">
              <h2>
                <MessageCircle size={18} /> 테란 라운지
              </h2>
              <span className="live-pill">
                <i /> LIVE
              </span>
            </div>
            <div className="chat-description">
              지금 이 순간, 같은 세계를 공유하는 우리.
            </div>
            <ChatPanel compact />
            <Link href="/chat" className="chat-open">
              전체 채팅방 입장하기 <ArrowRight size={15} />
            </Link>
          </section>
          <Link href="/world" className="world-card">
            <div className="world-card-orbit">
              <Globe2 size={90} />
              <Orbit size={120} />
            </div>
            <div className="world-card-copy">
              <span className="eyebrow">THE TERRAN UNIVERSE</span>
              <h3>
                어떤 세계를
                <br />
                상상하고 있나요?
              </h3>
              <p>테란의 세계관을 탐험해 보세요.</p>
              <span className="world-link">
                세계관 아카이브 <ArrowUpRight size={16} />
              </span>
            </div>
          </Link>
          <div className="creator-note">
            <span className="little-cross">+</span>
            <div>
              <strong>새로운 이야기는 언제나 환영해요.</strong>
              <p>웹소설부터 웹툰까지, 당신의 우주를 들려주세요.</p>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
function MessagesIcon() {
  return <MessageCircle size={20} />;
}
