import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  PenLine,
  Plus,
  Trash2,
  List,
  ChevronRight,
  Minus,
  Image,
} from "lucide-react";
import { toast } from "sonner";
import {
  useCommunity,
  DataStatus,
} from "@/components/terran/CommunityProvider";
import { dateLabel } from "@/lib/community";
import NotFound from "@/pages/NotFound";
export default function WorkDetail({ id }: { id: string }) {
  const { data, loading, error, mutate } = useCommunity();
  const [, navigate] = useLocation();
  const work = data.works.find(w => w.id === Number(id));
  if (loading || error)
    return (
      <div className="standard-page">
        <DataStatus />
      </div>
    );
  if (!work) return <NotFound />;
  const episodes = [...work.episodes].sort((a, b) => a.number - b.number);
  const canEdit = data.admin || data.user?.id === work.authorId;
  async function remove() {
    if (!window.confirm("이 작품과 모든 회차를 삭제할까요?")) return;
    try {
      await mutate(`/works/${id}`, "DELETE");
      toast.success("작품을 삭제했습니다.");
      navigate(work!.kind === "novel" ? "/novels" : "/webtoons");
    } catch {}
  }
  return (
    <div className="standard-page">
      <Link
        href={work.kind === "novel" ? "/novels" : "/webtoons"}
        className="back-link"
      >
        <ArrowLeft size={16} />
        {work.kind === "novel" ? "웹소설" : "웹툰"} 아카이브
      </Link>
      <section className="work-detail-hero">
        <div className="detail-cover">
          {work.cover ? (
            <img src={work.cover} alt={`${work.title} 표지`} />
          ) : (
            <div className="blank-cover">
              <BookOpen size={44} />
            </div>
          )}
        </div>
        <div className="work-detail-info">
          <div className="detail-tags">
            <span className={`content-badge static ${work.kind}`}>
              {work.kind === "novel" ? "웹소설" : "웹툰"}
            </span>
            <span>{work.genre}</span>
            <span>{work.status === "completed" ? "완결" : "연재 중"}</span>
          </div>
          <h1>{work.title}</h1>
          <p className="work-author">
            {work.author} <span>· 총 {episodes.length}화</span>
          </p>
          <p className="work-description">{work.description}</p>
          <div className="tag-list">
            {work.tags.map(t => (
              <span key={t}>#{t}</span>
            ))}
          </div>
          {work.sample && (
            <div className="sample-notice">
              세계관 예시 작품입니다. 실제 작품과 회차는 시민과 관리자가 직접
              등록할 수 있습니다.
            </div>
          )}
          <div className="detail-button-row">
            {episodes[0] && (
              <Link
                href={`/work/${id}/episode/${episodes[0].id}`}
                className="primary-btn"
              >
                <BookOpen size={16} /> 첫 화부터 보기 <ArrowRight size={16} />
              </Link>
            )}
            {canEdit && (
              <>
                <Link
                  href={`/write?type=${work.kind}&edit=${id}`}
                  className="secondary-btn"
                >
                  <PenLine size={15} /> 작품 수정
                </Link>
                <button
                  className="icon-btn danger"
                  onClick={remove}
                  aria-label="작품 삭제"
                >
                  <Trash2 size={17} />
                </button>
              </>
            )}
          </div>
        </div>
      </section>
      <section className="episode-section">
        <div className="section-heading">
          <h2>
            전체 회차 <span className="muted">{episodes.length}</span>
          </h2>
          {canEdit && (
            <Link
              className="secondary-btn"
              href={`/write?type=episode&work=${id}`}
            >
              <Plus size={15} /> 회차 등록
            </Link>
          )}
        </div>
        <div className="episode-list">
          {episodes.map(ep => (
            <div className="episode-row" key={ep.id}>
              <Link href={`/work/${id}/episode/${ep.id}`}>
                <span className="episode-number">
                  {String(ep.number).padStart(2, "0")}
                </span>
                <div>
                  <h3>{ep.title}</h3>
                  <span>
                    {dateLabel(ep.createdAt)} ·{" "}
                    {work.kind === "novel"
                      ? `${ep.body.length.toLocaleString()}자`
                      : `${ep.images.length}장의 이미지`}
                  </span>
                </div>
                <ChevronRight size={18} />
              </Link>
              {canEdit && (
                <div className="episode-actions">
                  <Link
                    href={`/write?type=episode&work=${id}&edit=${ep.id}`}
                    className="icon-btn"
                    aria-label="회차 수정"
                  >
                    <PenLine size={15} />
                  </Link>
                  <button
                    className="icon-btn danger"
                    aria-label="회차 삭제"
                    onClick={async () => {
                      if (window.confirm("이 회차를 삭제할까요?")) {
                        try {
                          await mutate(`/episodes/${ep.id}`, "DELETE");
                          toast.success("회차를 삭제했습니다.");
                        } catch {}
                      }
                    }}
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
        {!episodes.length && (
          <div className="empty-state">
            <BookOpen size={30} />
            <h3>첫 번째 회차를 기다리고 있어요.</h3>
            <p>새로운 여정이 곧 시작됩니다.</p>
          </div>
        )}
      </section>
    </div>
  );
}
export function EpisodeReader({
  id,
  episodeId,
}: {
  id: string;
  episodeId: string;
}) {
  const { data, loading, error } = useCommunity();
  const [fontSize, setFontSize] = useState(18);
  const work = data.works.find(w => w.id === Number(id));
  const ep = work?.episodes.find(e => e.id === Number(episodeId));
  if (loading || error)
    return (
      <div className="standard-page">
        <DataStatus />
      </div>
    );
  if (!work || !ep) return <NotFound />;
  const episodes = [...work.episodes].sort((a, b) => a.number - b.number);
  const index = episodes.findIndex(e => e.id === ep.id);
  return (
    <div className={`reader-page ${work.kind}`}>
      <div className="reader-toolbar">
        <Link href={`/work/${id}`}>
          <ArrowLeft size={17} /> 작품으로
        </Link>
        <span>{work.title}</span>
        {work.kind === "novel" && (
          <div className="font-controls">
            <button
              className="icon-btn"
              aria-label="글씨 작게"
              onClick={() => setFontSize(Math.max(14, fontSize - 1))}
            >
              <Minus size={15} />
            </button>
            <span>{fontSize}px</span>
            <button
              className="icon-btn"
              aria-label="글씨 크게"
              onClick={() => setFontSize(Math.min(28, fontSize + 1))}
            >
              <Plus size={15} />
            </button>
          </div>
        )}
      </div>
      <div className="reader-title">
        <span className="eyebrow">
          CHAPTER {String(ep.number).padStart(2, "0")}
        </span>
        <h1>{ep.title}</h1>
        <span>{work.author}</span>
        {work.sample && (
          <p className="sample-notice">
            테란 세계관을 소개하는 예시 회차입니다.
          </p>
        )}
      </div>
      {work.kind === "novel" ? (
        <article className="novel-body" style={{ fontSize }}>
          {ep.body}
        </article>
      ) : (
        <article className="webtoon-body">
          {ep.images.map((src, i) => (
            <img
              key={`${src}-${i}`}
              src={src}
              alt={`${ep.title} ${i + 1}번째 장면`}
              loading={i > 1 ? "lazy" : "eager"}
            />
          ))}
          {ep.body && <div className="webtoon-note">{ep.body}</div>}
          {!ep.images.length && (
            <div className="empty-state">
              <Image size={30} />
              <p>이미지가 등록되지 않은 회차입니다.</p>
            </div>
          )}
        </article>
      )}
      <div className="reader-navigation">
        {index > 0 ? (
          <Link
            className="secondary-btn"
            href={`/work/${id}/episode/${episodes[index - 1].id}`}
          >
            <ArrowLeft size={16} /> 이전 화
          </Link>
        ) : (
          <span />
        )}
        <Link className="text-btn" href={`/work/${id}`}>
          <List size={16} /> 회차 목록
        </Link>
        {index < episodes.length - 1 ? (
          <Link
            className="primary-btn"
            href={`/work/${id}/episode/${episodes[index + 1].id}`}
          >
            다음 화 <ArrowRight size={16} />
          </Link>
        ) : (
          <span className="muted">마지막 회차입니다.</span>
        )}
      </div>
    </div>
  );
}
