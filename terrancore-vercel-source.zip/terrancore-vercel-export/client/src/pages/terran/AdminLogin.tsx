import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import {
  Shield,
  LockKeyhole,
  ArrowRight,
  LoaderCircle,
  Eye,
  EyeOff,
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
} from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { api } from "@/lib/community";
import { useCommunity } from "@/components/terran/CommunityProvider";

export default function AdminLogin() {
  const { data, loading, refresh } = useCommunity();
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("");
  const [visible, setVisible] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => {
    if (!loading && data.admin) navigate("/admin", { replace: true });
  }, [loading, data.admin, navigate]);
  async function login(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      const result = await api<{ success: boolean; token?: string }>(
        "/admin/login",
        "POST",
        { username: username.trim(), password }
      );
      if (!result.token)
        throw new Error(
          "관리자 인증 정보를 받지 못했습니다. 다시 시도해 주세요."
        );
      sessionStorage.setItem("terran-admin", result.token);
      setPassword("");
      setVisible(false);
      await Promise.all([
        refresh(),
        queryClient.invalidateQueries({ queryKey: ["admin-data"] }),
      ]);
      toast.success("관리자 인증 완료. 테란 관제실로 이동합니다.");
      navigate("/admin", { replace: true });
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "관리자 로그인에 실패했습니다."
      );
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="admin-login-page standalone-admin-login">
      <div className="admin-login-art">
        <div className="admin-emblem">
          <Shield size={58} />
        </div>
        <span className="eyebrow">TERRAN CONTROL CENTER</span>
        <h1>
          우리 세계를
          <br />
          안전하게, 함께.
        </h1>
        <p>
          이야기와 시민들이 머무는 곳.
          <br />
          테란을 지키는 관리자 전용 공간입니다.
        </p>
        <div className="admin-access-features">
          <span>
            <CheckCircle2 size={15} /> 작품과 게시글 운영
          </span>
          <span>
            <CheckCircle2 size={15} /> 시민·채팅방 관리
          </span>
          <span>
            <CheckCircle2 size={15} /> 별도의 관리자 보안 인증
          </span>
        </div>
      </div>
      <form className="admin-login-form" onSubmit={login}>
        <Link href="/" className="admin-back-link">
          <ArrowLeft size={14} />
          커뮤니티로 돌아가기
        </Link>
        <span className="eyebrow">AUTHORIZED ACCESS ONLY</span>
        <h2>관리자 로그인</h2>
        <p>일반 회원 로그인과 별도의 관리자 계정으로 접속하세요.</p>
        <label>
          관리자 아이디
          <input
            value={username}
            autoComplete="username"
            onChange={e => setUsername(e.target.value)}
            required
            maxLength={64}
            disabled={busy}
            placeholder="관리자 아이디"
          />
        </label>
        <label>
          관리자 비밀번호
          <div className="password-input-wrap">
            <input
              type={visible ? "text" : "password"}
              value={password}
              autoComplete="current-password"
              onChange={e => setPassword(e.target.value)}
              required
              maxLength={128}
              disabled={busy}
              placeholder="직접 설정한 관리자 비밀번호"
            />
            <button
              type="button"
              onClick={() => setVisible(v => !v)}
              aria-label={visible ? "비밀번호 숨기기" : "비밀번호 표시"}
              aria-pressed={visible}
              disabled={busy}
            >
              {visible ? <EyeOff size={17} /> : <Eye size={17} />}
            </button>
          </div>
        </label>
        {error && (
          <div className="error-message" role="alert">
            <AlertTriangle size={16} />
            {error}
          </div>
        )}
        <button
          className="primary-btn wide"
          disabled={busy || !username.trim() || !password}
        >
          {busy ? (
            <LoaderCircle className="spin" size={17} />
          ) : (
            <LockKeyhole size={17} />
          )}{" "}
          {busy ? "보안 인증 확인 중..." : "관리자 관제실 입장"}
          <ArrowRight size={17} />
        </button>
        <div className="admin-login-security">
          <Shield size={16} />
          <p>
            이전에 설정한 관리자 비밀번호를 사용하세요.
            <br />새 비밀번호로 다시 설정하거나 가입할 필요가 없습니다.
          </p>
        </div>
        <p className="fineprint">
          비밀번호는 저장하거나 다른 시민에게 공유하지 마세요.
          <br />
          이후 변경은 관리자 센터의 보안 설정에서 가능합니다.
        </p>
      </form>
    </div>
  );
}
