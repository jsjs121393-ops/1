import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Search, SlidersHorizontal, PenLine, ArrowUpRight } from "lucide-react";
import {
  useCommunity,
  DataStatus,
} from "@/components/terran/CommunityProvider";
import { WorkCard } from "@/components/terran/WorkCard";
import { dateLabel } from "@/lib/community";
export default function Explore({ kind }: { kind?: "novel" | "webtoon" }) {
  const { data, requireLogin } = useCommunity();
  const [location, navigate] = useLocation();
  const globalSearch = location.startsWith("/search");
  const initial = globalSearch
    ? (new URLSearchParams(window.location.search).get("q") ?? "")
    : "";
  const [search, setSearch] = useState(initial);
  const [genre, setGenre] = useState("전체");
  const [sort, setSort] = useState("latest");
  const genres = [
    "전체",
    ...new Set(
      data.works.filter(w => !kind || w.kind === kind).map(w => w.genre)
    ),
  ];
  let works = data.works.filter(
    w =>
      (!kind || w.kind === kind) &&
      (genre === "전체" || w.genre === genre) &&
      `${w.title} ${w.description} ${w.author} ${w.tags.join(" ")}`
        .toLowerCase()
        .includes(search.toLowerCase())
  );
  works = [...works].sort((a, b) =>
    sort === "latest"
      ? +new Date(b.createdAt) - +new Date(a.createdAt)
      : b.episodes.length - a.episodes.length
  );
  const posts = globalSearch
    ? data.posts.filter(p =>
        `${p.title} ${p.body}`.toLowerCase().includes(search.toLowerCase())
      )
    : [];
  return (
    <div className="standard-page">
      <div className="page-heading">
        <div>
          <span className="eyebrow">
            {globalSearch ? "SEARCH THE ARCHIVE" : "STORIES BEYOND THE STARS"}
          </span>
          <h1>
            {globalSearch
              ? "테란의 기록 검색"
              : kind === "novel"
                ? "문장으로 펼치는 새로운 우주"
                : "장면으로 만나는 테란"}
          </h1>
          <p>
            {globalSearch
              ? "작품과 시민들의 이야기를 한곳에서 찾아보세요."
              : "끝없는 상상력으로 쓰여지는, 우리만의 세계."}
          </p>
        </div>
        {!globalSearch && (
          <button
            className="primary-btn"
            onClick={() => requireLogin() && navigate(`/write?type=${kind}`)}
          >
            <PenLine size={16} /> 작품 등록
          </button>
        )}
      </div>
      <div className="explore-toolbar">
        <form className="search-field" onSubmit={e => e.preventDefault()}>
          <Search size={18} />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="작품 제목, 작가, 키워드 검색"
            aria-label="작품 검색"
          />
        </form>
        <select
          aria-label="작품 정렬"
          value={sort}
          onChange={e => setSort(e.target.value)}
        >
          <option value="latest">최신순</option>
          <option value="episodes">회차 많은 순</option>
        </select>
      </div>
      <div className="filter-pills">
        {genres.map(g => (
          <button
            key={g}
            className={genre === g ? "active" : ""}
            onClick={() => setGenre(g)}
          >
            {g}
          </button>
        ))}
      </div>
      <DataStatus />
      <div className="results-label">{works.length}개의 이야기</div>
      <div className="work-grid explore-grid">
        {works.map(w => (
          <WorkCard key={w.id} work={w} />
        ))}
      </div>
      {!works.length && (
        <div className="empty-state">
          <Search size={30} />
          <h3>아직 이곳에 기록된 이야기가 없어요.</h3>
          <p>다른 검색어를 사용하거나 첫 번째 이야기를 올려 보세요.</p>
        </div>
      )}
      {globalSearch && (
        <section className="search-posts">
          <h2>
            커뮤니티 검색 결과 <span className="muted">{posts.length}</span>
          </h2>
          {posts.map(p => (
            <Link key={p.id} href={`/post/${p.id}`} className="post-row">
              <span className="category-label">{p.category}</span>
              <strong>{p.title}</strong>
              <span className="muted">{dateLabel(p.createdAt)}</span>
              <ArrowUpRight size={16} />
            </Link>
          ))}
        </section>
      )}
    </div>
  );
}
