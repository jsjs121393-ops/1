import { useEffect, useState } from "react";
import { Link } from "wouter";
import { UserRound, Save, PenLine, ArrowUpRight } from "lucide-react";
import { toast } from "sonner";
import {
  useCommunity,
  DataStatus,
} from "@/components/terran/CommunityProvider";
import { WorkCard } from "@/components/terran/WorkCard";
export default function Profile() {
  const { data, loading, error, login, mutate } = useCommunity();
  const [name, setName] = useState(data.user?.name ?? "");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (data.user?.name) setName(data.user.name);
  }, [data.user?.name]);
  if (loading || error)
    return (
      <div className="standard-page">
        <DataStatus />
      </div>
    );
  if (!data.user)
    return (
      <div className="standard-page">
        <div className="empty-state">
          <UserRound size={36} />
          <h2>나의 테란 기록</h2>
          <p>로그인한 뒤 시민 프로필을 관리할 수 있어요.</p>
          <button className="primary-btn" onClick={login}>
            가입 · 로그인
          </button>
        </div>
      </div>
    );
  const works = data.works.filter(w => w.authorId === data.user!.id);
  const posts = data.posts.filter(p => p.authorId === data.user!.id);
  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await mutate("/profile", "PATCH", { name: name.trim() });
      toast.success("프로필을 저장했습니다.");
    } catch {
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="standard-page">
      <div className="page-heading">
        <div>
          <span className="eyebrow">YOUR TERRAN IDENTITY</span>
          <h1>내가 기록한 세계</h1>
          <p>당신의 이야기가 쌓여 테란의 역사가 됩니다.</p>
        </div>
        <Link className="primary-btn" href="/write">
          <PenLine size={16} /> 새 작품 등록
        </Link>
      </div>
      <form className="profile-card" onSubmit={save}>
        <span className="profile-avatar">
          {(data.user.name ?? "시민").slice(0, 1)}
        </span>
        <div>
          <span className="eyebrow">TERRAN CITIZEN</span>
          <label>
            시민 이름
            <input
              value={name}
              maxLength={30}
              minLength={2}
              required
              onChange={e => setName(e.target.value)}
            />
          </label>
          <p className="muted">
            {data.user.email ?? "Manus 계정으로 인증된 시민"}
          </p>
        </div>
        <button className="secondary-btn" disabled={busy}>
          <Save size={16} /> 프로필 저장
        </button>
      </form>
      <section className="profile-section">
        <div className="section-heading">
          <h2>
            나의 연재 작품 <span className="muted">{works.length}</span>
          </h2>
        </div>
        <div className="work-grid explore-grid">
          {works.map(w => (
            <WorkCard key={w.id} work={w} />
          ))}
        </div>
        {!works.length && (
          <div className="empty-state compact">
            <p>아직 등록한 작품이 없어요. 새로운 이야기를 시작해 보세요.</p>
          </div>
        )}
      </section>
      <section className="profile-section">
        <h2>
          내가 쓴 게시글 <span className="muted">{posts.length}</span>
        </h2>
        {posts.map(p => (
          <Link className="post-row" key={p.id} href={`/post/${p.id}`}>
            <span className="category-label">{p.category}</span>
            <strong>{p.title}</strong>
            <ArrowUpRight size={15} />
          </Link>
        ))}
        {!posts.length && (
          <p className="muted">아직 작성한 게시글이 없습니다.</p>
        )}
      </section>
    </div>
  );
}
