import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  ArrowLeft,
  Upload,
  LoaderCircle,
  Save,
  ImagePlus,
  ArrowUp,
  ArrowDown,
  X,
  BookOpen,
  PanelsTopLeft,
  PenLine,
} from "lucide-react";
import { toast } from "sonner";
import {
  useCommunity,
  DataStatus,
} from "@/components/terran/CommunityProvider";
import { uploadImage } from "@/lib/community";
import { CATEGORIES } from "./Community";
export default function Write() {
  const { loading, error } = useCommunity();
  if (loading || error)
    return (
      <div className="standard-page">
        <DataStatus />
      </div>
    );
  return <WriteForm />;
}
function WriteForm() {
  const { data, loading, error, login, mutate } = useCommunity();
  const [, navigate] = useLocation();
  const params = new URLSearchParams(window.location.search);
  const type = params.get("type") ?? "novel";
  const editId = Number(params.get("edit") || 0);
  const workId = Number(params.get("work") || 0);
  const existingWork = data.works.find(
    w => w.id === (type === "episode" ? workId : editId)
  );
  const existingEp =
    type === "episode"
      ? existingWork?.episodes.find(e => e.id === editId)
      : undefined;
  const existingPost =
    type === "post" ? data.posts.find(p => p.id === editId) : undefined;
  const isEpisode = type === "episode";
  const isPost = type === "post";
  const isWebtoon = isEpisode
    ? existingWork?.kind === "webtoon"
    : type === "webtoon";
  const [title, setTitle] = useState(
    existingEp?.title ?? existingPost?.title ?? existingWork?.title ?? ""
  );
  const [body, setBody] = useState(
    existingEp?.body ??
      existingPost?.body ??
      (!isEpisode ? existingWork?.description : "") ??
      ""
  );
  const [genre, setGenre] = useState(existingWork?.genre ?? "SF");
  const [category, setCategory] = useState(
    existingPost?.category ?? CATEGORIES[0]
  );
  const [tags, setTags] = useState(existingWork?.tags.join(", ") ?? "");
  const [status, setStatus] = useState(existingWork?.status ?? "ongoing");
  const [number, setNumber] = useState(
    existingEp?.number ??
      Math.max(0, ...(existingWork?.episodes.map(e => e.number) ?? [])) + 1
  );
  const [cover, setCover] = useState(existingWork?.cover ?? "");
  const [images, setImages] = useState(existingEp?.images ?? []);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  if (loading || error)
    return (
      <div className="standard-page">
        <DataStatus />
      </div>
    );
  if (!data.user && !data.admin)
    return (
      <div className="standard-page">
        <div className="empty-state">
          <PenLine size={36} />
          <h2>당신의 이야기를 들려주세요.</h2>
          <p>콘텐츠를 등록하려면 테란 시민으로 로그인해 주세요.</p>
          <button className="primary-btn" onClick={login}>
            가입 · 로그인
          </button>
        </div>
      </div>
    );
  if (isEpisode && !existingWork)
    return (
      <div className="standard-page">
        <div className="error-message">
          작품을 찾지 못했습니다.<Link href="/novels">작품 목록으로</Link>
        </div>
      </div>
    );
  async function filesChanged(files: FileList | null, forCover: boolean) {
    if (!files?.length) return;
    setUploading(true);
    try {
      const result: string[] = [];
      for (const file of Array.from(files))
        result.push(await uploadImage(file));
      if (forCover) setCover(result[0]);
      else setImages(prev => [...prev, ...result]);
      toast.success("이미지를 업로드했습니다. 저장 버튼을 눌러 등록해 주세요.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "업로드 실패");
    } finally {
      setUploading(false);
    }
  }
  function move(index: number, direction: number) {
    setImages(prev => {
      const list = [...prev];
      const next = index + direction;
      if (next < 0 || next >= list.length) return prev;
      [list[index], list[next]] = [list[next], list[index]];
      return list;
    });
  }
  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (busy || uploading) return;
    if (isEpisode && isWebtoon && !images.length) {
      toast.error("웹툰 이미지를 한 장 이상 올려 주세요.");
      return;
    }
    setBusy(true);
    try {
      let result: any;
      if (isPost) {
        result = await mutate(
          editId ? `/posts/${editId}` : "/posts",
          editId ? "PATCH" : "POST",
          { title: title.trim(), body, category }
        );
        navigate(`/post/${editId || result.id}`);
      } else if (isEpisode) {
        result = await mutate(
          editId ? `/episodes/${editId}` : `/works/${workId}/episodes`,
          editId ? "PATCH" : "POST",
          { title: title.trim(), number, body, images }
        );
        navigate(`/work/${workId}`);
      } else {
        result = await mutate(
          editId ? `/works/${editId}` : "/works",
          editId ? "PATCH" : "POST",
          {
            kind: type === "webtoon" ? "webtoon" : "novel",
            title: title.trim(),
            description: body,
            genre,
            cover,
            tags: tags
              .split(",")
              .map(t => t.trim())
              .filter(Boolean),
            status,
          }
        );
        navigate(`/work/${editId || result.id}`);
      }
      toast.success(
        editId ? "변경사항을 저장했습니다." : "새로운 이야기를 등록했습니다."
      );
    } catch {
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="standard-page write-page">
      <Link
        href={
          isEpisode
            ? `/work/${workId}`
            : isPost
              ? "/community"
              : isWebtoon
                ? "/webtoons"
                : "/novels"
        }
        className="back-link"
      >
        <ArrowLeft size={16} /> 돌아가기
      </Link>
      <div className="page-heading">
        <div>
          <span className="eyebrow">CREATOR STUDIO</span>
          <h1>
            {editId
              ? "이야기 다듬기"
              : isEpisode
                ? "다음 장을 기록하세요."
                : "당신의 우주를 펼쳐 주세요."}
          </h1>
          <p>
            {isPost
              ? "서로의 생각이 테란을 더 풍성하게 만듭니다."
              : isEpisode
                ? `${existingWork?.title} · 새로운 회차`
                : "작품을 등록한 뒤 회차를 추가해 연재를 시작할 수 있어요."}
          </p>
        </div>
      </div>
      {!isPost && !isEpisode && !editId && (
        <div className="write-type-tabs">
          <Link href="/write?type=novel" className={!isWebtoon ? "active" : ""}>
            <BookOpen size={19} /> 웹소설
          </Link>
          <Link
            href="/write?type=webtoon"
            className={isWebtoon ? "active" : ""}
          >
            <PanelsTopLeft size={19} /> 웹툰
          </Link>
        </div>
      )}
      <form className="editor-form" onSubmit={save}>
        <label>
          제목 <span className="required">*</span>
          <input
            value={title}
            onChange={e => setTitle(e.target.value)}
            placeholder={
              isEpisode
                ? "회차 제목을 입력해 주세요."
                : "이야기의 이름을 지어 주세요."
            }
            maxLength={120}
            required
          />
        </label>
        {isPost && (
          <label>
            게시판
            <select
              value={category}
              onChange={e => setCategory(e.target.value)}
            >
              {CATEGORIES.map(c => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </label>
        )}
        {isEpisode && (
          <label className="short-field">
            회차 번호
            <input
              type="number"
              min={1}
              max={100000}
              value={number}
              onChange={e => setNumber(Number(e.target.value))}
              required
            />
          </label>
        )}
        {!isPost && !isEpisode && (
          <>
            <div className="form-two-columns">
              <label>
                장르
                <select value={genre} onChange={e => setGenre(e.target.value)}>
                  {["SF", "판타지", "모험", "드라마", "기타"].map(g => (
                    <option key={g}>{g}</option>
                  ))}
                </select>
              </label>
              <label>
                연재 상태
                <select
                  value={status}
                  onChange={e =>
                    setStatus(e.target.value as "ongoing" | "completed")
                  }
                >
                  <option value="ongoing">연재 중</option>
                  <option value="completed">완결</option>
                </select>
              </label>
            </div>
            <label>
              키워드
              <input
                value={tags}
                onChange={e => setTags(e.target.value)}
                maxLength={200}
                placeholder="우주, 함대, 모험 (쉼표로 구분)"
              />
            </label>
            <div className="cover-editor">
              <div>
                <label>작품 표지</label>
                <p>JPG, PNG, WEBP, GIF · 최대 10MB</p>
                <label className="secondary-btn file-label">
                  <ImagePlus size={16} />{" "}
                  {cover ? "표지 바꾸기" : "표지 올리기"}
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/gif"
                    disabled={uploading}
                    onChange={e => filesChanged(e.target.files, true)}
                  />
                </label>
              </div>
              {cover && <img src={cover} alt="업로드한 표지 미리보기" />}
            </div>
          </>
        )}
        {(!isEpisode || !isWebtoon) && (
          <label>
            {isPost || isEpisode ? "본문" : "작품 소개"}{" "}
            <span className="required">*</span>
            <textarea
              className={isEpisode ? "large-textarea" : ""}
              value={body}
              onChange={e => setBody(e.target.value)}
              placeholder={
                isEpisode
                  ? "이곳에서 다음 이야기가 시작됩니다."
                  : "당신의 이야기를 소개해 주세요."
              }
              maxLength={isEpisode ? 100000 : isPost ? 30000 : 3000}
              required
            />
          </label>
        )}
        {isEpisode && isWebtoon && (
          <>
            <div className="image-upload-heading">
              <div>
                <label>
                  웹툰 이미지 <span className="required">*</span>
                </label>
                <p className="muted">
                  감상 순서대로 올려 주세요. 화살표로 순서를 바꿀 수 있어요.
                </p>
              </div>
              <label className="secondary-btn file-label">
                <Upload size={16} /> 이미지 추가
                <input
                  type="file"
                  multiple
                  accept="image/jpeg,image/png,image/webp,image/gif"
                  disabled={uploading}
                  onChange={e => filesChanged(e.target.files, false)}
                />
              </label>
            </div>
            <div className="image-sort-list">
              {images.map((src, index) => (
                <div className="image-sort-item" key={`${src}-${index}`}>
                  <img src={src} alt={`${index + 1}번째 웹툰 이미지`} />
                  <span>{index + 1}번째 장면</span>
                  <button
                    type="button"
                    className="icon-btn"
                    disabled={index === 0}
                    aria-label="이미지 위로 이동"
                    onClick={() => move(index, -1)}
                  >
                    <ArrowUp size={16} />
                  </button>
                  <button
                    type="button"
                    className="icon-btn"
                    disabled={index === images.length - 1}
                    aria-label="이미지 아래로 이동"
                    onClick={() => move(index, 1)}
                  >
                    <ArrowDown size={16} />
                  </button>
                  <button
                    type="button"
                    className="icon-btn danger"
                    aria-label="이미지 제외"
                    onClick={() =>
                      setImages(prev => prev.filter((_, i) => i !== index))
                    }
                  >
                    <X size={16} />
                  </button>
                </div>
              ))}
            </div>
            {!images.length && (
              <div className="upload-empty">
                <ImagePlus size={32} />
                <p>회차 이미지를 추가해 주세요.</p>
              </div>
            )}
            <label>
              작가의 말 (선택)
              <textarea
                value={body}
                onChange={e => setBody(e.target.value)}
                maxLength={3000}
                placeholder="이 회차에 덧붙일 이야기"
              />
            </label>
          </>
        )}
        {uploading && (
          <div className="status-message">
            <LoaderCircle size={16} className="spin" /> 이미지 업로드 중입니다.
            잠시만 기다려 주세요.
          </div>
        )}
        <div className="editor-bottom">
          <p>직접 창작했거나 게시 권한이 있는 콘텐츠만 올려 주세요.</p>
          <button className="primary-btn" disabled={busy || uploading}>
            {busy ? (
              <LoaderCircle size={16} className="spin" />
            ) : (
              <Save size={16} />
            )}{" "}
            {editId ? "변경사항 저장" : "등록하기"}
          </button>
        </div>
      </form>
    </div>
  );
}
