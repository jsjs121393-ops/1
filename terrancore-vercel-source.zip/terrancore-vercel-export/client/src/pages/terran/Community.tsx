import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  PenLine,
  Search,
  MessageCircle,
  ArrowLeft,
  Trash2,
  Send,
  LoaderCircle,
  Megaphone,
} from "lucide-react";
import { toast } from "sonner";
import {
  useCommunity,
  DataStatus,
} from "@/components/terran/CommunityProvider";
import { dateLabel } from "@/lib/community";
import NotFound from "@/pages/NotFound";
export const CATEGORIES = [
  "자유게시판",
  "세계관 토론",
  "창작 이야기",
  "질문 · 도움",
];
export default function Community() {
  const { data, requireLogin } = useCommunity();
  const [, navigate] = useLocation();
  const [category, setCategory] = useState("전체");
  const [search, setSearch] = useState("");
  const categories = [
    "전체",
    ...new Set([...CATEGORIES, ...data.posts.map(p => p.category)]),
  ];
  const posts = data.posts
    .filter(
      p =>
        (category === "전체" || p.category === category) &&
        `${p.title} ${p.body} ${p.author}`
          .toLowerCase()
          .includes(search.toLowerCase())
    )
    .sort(
      (a, b) =>
        Number(b.pinned) - Number(a.pinned) ||
        +new Date(b.createdAt) - +new Date(a.createdAt)
    );
  return (
    <div className="standard-page">
      <div className="page-heading">
        <div>
          <span className="eyebrow">VOICES OF TERRAN</span>
          <h1>시민들의 이야기</h1>
          <p>자유로운 생각들이 만나, 더 넓은 세계가 됩니다.</p>
        </div>
        <button
          className="primary-btn"
          onClick={() => requireLogin() && navigate("/write?type=post")}
        >
          <PenLine size={16} /> 글쓰기
        </button>
      </div>
      <div className="board-toolbar">
        <div className="filter-pills">
          {categories.map(c => (
            <button
              key={c}
              className={category === c ? "active" : ""}
              onClick={() => setCategory(c)}
            >
              {c}
            </button>
          ))}
        </div>
        <div className="search-field">
          <Search size={17} />
          <input
            aria-label="게시글 검색"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="게시글 검색"
          />
        </div>
      </div>
      <DataStatus />
      <div className="board-header">
        <span>분류 / 제목</span>
        <span>작성자</span>
        <span>작성일</span>
      </div>
      <div className="board-list">
        {posts.map(p => (
          <Link className="post-row" href={`/post/${p.id}`} key={p.id}>
            <span className={`category-label ${p.pinned ? "notice" : ""}`}>
              {p.category}
            </span>
            <strong>
              {p.pinned && <Megaphone size={14} />} {p.title}
            </strong>
            <span className="comment-count">
              <MessageCircle size={12} />
              {p.comments.length}
            </span>
            <span className="post-author">{p.author}</span>
            <span className="post-date">{dateLabel(p.createdAt)}</span>
          </Link>
        ))}
      </div>
      {!posts.length && (
        <div className="empty-state">
          <MessageCircle size={32} />
          <h3>아직 작성된 게시글이 없어요.</h3>
          <p>첫 번째 이야기를 남겨 주세요.</p>
        </div>
      )}
      <div className="board-footer">
        총 {posts.length}개의 게시글 <span>최신 이야기부터 표시합니다.</span>
      </div>
    </div>
  );
}
export function PostDetail({ id }: { id: string }) {
  const { data, loading, error, requireLogin, mutate } = useCommunity();
  const [, navigate] = useLocation();
  const [comment, setComment] = useState("");
  const [sending, setSending] = useState(false);
  const [editingComment, setEditingComment] = useState<number | null>(null);
  const [editBody, setEditBody] = useState("");
  const [editBusy, setEditBusy] = useState(false);
  const post = data.posts.find(p => p.id === Number(id));
  if (loading || error)
    return (
      <div className="standard-page">
        <DataStatus />
      </div>
    );
  if (!post) return <NotFound />;
  const canEdit = data.admin || data.user?.id === post.authorId;
  async function deletePost() {
    if (!window.confirm("게시글과 연결된 댓글을 삭제할까요?")) return;
    try {
      await mutate(`/posts/${id}`, "DELETE");
      toast.success("게시글을 삭제했습니다.");
      navigate("/community");
    } catch {}
  }
  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (!requireLogin() || !comment.trim()) return;
    setSending(true);
    try {
      await mutate(`/posts/${id}/comments`, "POST", { body: comment.trim() });
      setComment("");
      toast.success("댓글을 남겼습니다.");
    } catch {
    } finally {
      setSending(false);
    }
  }
  return (
    <div className="standard-page reading-page">
      <Link className="back-link" href="/community">
        <ArrowLeft size={16} /> 시민들의 이야기
      </Link>
      <article className="post-detail">
        <span className="category-label">{post.category}</span>
        <h1>{post.title}</h1>
        <div className="detail-byline">
          <span className="avatar">{post.author.slice(0, 1)}</span>
          <strong>{post.author}</strong>
          <span>{new Date(post.createdAt).toLocaleDateString("ko-KR")}</span>
          {post.sample && <span className="sample-label">세계관 예시</span>}
          {canEdit && (
            <div className="detail-actions">
              <Link href={`/write?type=post&edit=${id}`} className="text-btn">
                <PenLine size={14} /> 수정
              </Link>
              <button className="text-btn danger" onClick={deletePost}>
                <Trash2 size={14} /> 삭제
              </button>
            </div>
          )}
        </div>
        <div className="post-body">{post.body}</div>
      </article>
      <section className="comment-section">
        <h2>
          댓글 <span>{post.comments.length}</span>
        </h2>
        {post.comments.map(c => (
          <div className="comment-item" key={c.id}>
            <span className="avatar">{c.author.slice(0, 1)}</span>
            <div>
              <div className="comment-byline">
                <strong>{c.author}</strong>
                <span>{dateLabel(c.createdAt)}</span>
                {(data.admin || data.user?.id === c.authorId) && (
                  <button
                    className="icon-btn"
                    aria-label="댓글 수정"
                    onClick={() => {
                      setEditingComment(c.id);
                      setEditBody(c.body);
                    }}
                  >
                    <PenLine size={13} />
                  </button>
                )}
                {(data.admin || data.user?.id === c.authorId) && (
                  <button
                    className="icon-btn danger"
                    aria-label="댓글 삭제"
                    onClick={async () => {
                      if (window.confirm("댓글을 삭제할까요?")) {
                        try {
                          await mutate(`/comments/${c.id}`, "DELETE");
                        } catch {}
                      }
                    }}
                  >
                    <Trash2 size={13} />
                  </button>
                )}
              </div>
              {editingComment === c.id ? (
                <form
                  className="comment-edit-form"
                  onSubmit={async e => {
                    e.preventDefault();
                    if (!editBody.trim() || editBusy) return;
                    setEditBusy(true);
                    try {
                      await mutate(`/comments/${c.id}`, "PATCH", {
                        body: editBody.trim(),
                      });
                      setEditingComment(null);
                      toast.success("댓글을 수정했습니다.");
                    } catch {
                    } finally {
                      setEditBusy(false);
                    }
                  }}
                >
                  <textarea
                    aria-label="수정할 댓글 내용"
                    value={editBody}
                    onChange={e => setEditBody(e.target.value)}
                    maxLength={5000}
                    required
                  />
                  <div>
                    <button
                      type="button"
                      className="text-btn"
                      disabled={editBusy}
                      onClick={() => setEditingComment(null)}
                    >
                      취소
                    </button>
                    <button className="secondary-btn" disabled={editBusy}>
                      {editBusy ? "저장 중..." : "수정 저장"}
                    </button>
                  </div>
                </form>
              ) : (
                <p>{c.body}</p>
              )}
            </div>
          </div>
        ))}
        {!post.comments.length && (
          <p className="muted">가장 먼저 생각을 나눠 보세요.</p>
        )}
        <form onSubmit={send} className="comment-form">
          <textarea
            aria-label="댓글 내용"
            placeholder="서로를 존중하는 따뜻한 댓글을 남겨 주세요."
            value={comment}
            maxLength={2000}
            onChange={e => setComment(e.target.value)}
            onFocus={() => {
              if (!data.user && !data.admin) requireLogin();
            }}
          />
          <button className="primary-btn" disabled={sending}>
            {sending ? (
              <LoaderCircle className="spin" size={15} />
            ) : (
              <Send size={15} />
            )}{" "}
            댓글 등록
          </button>
        </form>
      </section>
    </div>
  );
}
