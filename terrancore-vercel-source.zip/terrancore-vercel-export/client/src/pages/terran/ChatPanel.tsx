import { useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Send,
  Radio,
  LoaderCircle,
  Trash2,
  MessageCircle,
  Hash,
  LockKeyhole,
  ImagePlus,
  X,
  Expand,
  Bell,
  Settings2,
  Link2,
} from "lucide-react";
import { toast } from "sonner";
import type { ChatMessage, ChatRoom } from "@shared/community";
import { api, timeLabel, uploadImage } from "@/lib/community";
import { useCommunity } from "@/components/terran/CommunityProvider";
import { useChatNotifications } from "@/components/terran/ChatNotifications";
import {
  ChatRoomDirectory,
  ChatRoomEditor,
} from "@/components/terran/ChatRooms";
import { useLocation } from "wouter";

export default function ChatPanel({ compact = false }: { compact?: boolean }) {
  const { data, requireLogin, mutate } = useCommunity();
  const notifications = useChatNotifications();
  const [, navigate] = useLocation();
  const initialRoom = compact
    ? "general"
    : new URLSearchParams(window.location.search).get("room");
  const [room, setRoom] = useState(
    initialRoom &&
      /^(general|world|creators|room_[a-f0-9]{12})$/.test(initialRoom)
      ? initialRoom
      : "general"
  );
  const [body, setBody] = useState("");
  const [images, setImages] = useState<string[]>([]);
  const [sending, setSending] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const end = useRef<HTMLDivElement>(null);
  const messageList = useRef<HTMLDivElement>(null);
  const lastMessage = useRef<number | null>(null);
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState<ChatRoom | undefined>();
  const roomsQuery = useQuery({
    queryKey: ["chat-rooms"],
    queryFn: () => api<ChatRoom[]>("/rooms"),
    refetchInterval: 10000,
    retry: 1,
  });
  const rooms = roomsQuery.data ?? [];
  const active = rooms.find(r => r.id === room);
  const canManage =
    !!active &&
    !active.isDefault &&
    !!(data.admin || (data.user && active.creatorId === data.user.id));
  const query = useQuery({
    queryKey: ["chat", room],
    queryFn: () => api<ChatMessage[]>(`/chat?room=${encodeURIComponent(room)}`),
    enabled: !!active,
    refetchInterval: 3000,
    retry: 1,
  });
  const messages = query.data ?? [];
  const latestId = messages.at(-1)?.id ?? 0;
  useEffect(() => {
    if (compact) return;
    notifications.setActiveRoom(active ? room : null);
    if (active) notifications.markRoomRead(room);
    return () => notifications.setActiveRoom(null);
  }, [
    room,
    !!active,
    compact,
    notifications.setActiveRoom,
    notifications.markRoomRead,
  ]);
  useEffect(() => {
    const list = messageList.current;
    const nearBottom =
      !list || list.scrollHeight - list.scrollTop - list.clientHeight < 150;
    if (!compact && (lastMessage.current === null || nearBottom))
      end.current?.scrollIntoView({
        behavior: lastMessage.current === null ? "instant" : "smooth",
        block: "nearest",
      });
    lastMessage.current = latestId;
  }, [latestId, room, compact]);
  useEffect(() => {
    lastMessage.current = null;
  }, [room]);
  useEffect(() => {
    if (!expanded) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setExpanded(null);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [expanded]);
  async function attach(files: FileList | null) {
    if (!files?.length || !requireLogin()) return;
    const selected = Array.from(files);
    if (selected.length + images.length > 4) {
      toast.error("메시지 하나에 이미지는 최대 4장까지 보낼 수 있어요.");
      if (fileInput.current) fileInput.current.value = "";
      return;
    }
    setUploading(true);
    try {
      for (const file of selected) {
        const url = await uploadImage(file);
        setImages(prev => [...prev, url]);
      }
      toast.success("이미지를 첨부했습니다. 전송 버튼을 눌러 보내 주세요.");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "이미지 업로드에 실패했습니다."
      );
    } finally {
      setUploading(false);
      if (fileInput.current) fileInput.current.value = "";
    }
  }
  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (
      !active ||
      !requireLogin() ||
      (!body.trim() && !images.length) ||
      sending ||
      uploading
    )
      return;
    setSending(true);
    try {
      await api("/chat", "POST", { room, body: body.trim(), images });
      setBody("");
      setImages([]);
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["chat", room] }),
        queryClient.invalidateQueries({ queryKey: ["chat-feed"] }),
        queryClient.invalidateQueries({ queryKey: ["chat-rooms"] }),
      ]);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "메시지 전송에 실패했습니다."
      );
    } finally {
      setSending(false);
    }
  }
  async function remove(id: number) {
    if (!window.confirm("이 메시지를 삭제할까요?")) return;
    try {
      await mutate(`/chat/${id}`, "DELETE");
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["chat"] }),
        queryClient.invalidateQueries({ queryKey: ["chat-feed"] }),
      ]);
    } catch {}
  }
  const canSend = !!(data.user || data.admin) && !!active;
  const selectRoom = (id: string) => {
    if (compact) {
      setRoom(id);
      return;
    }
    navigate(`/chat?room=${encodeURIComponent(id)}`);
  };
  async function shareRoom() {
    if (!active) return;
    const url = `${window.location.origin}/chat?room=${encodeURIComponent(room)}`;
    try {
      await navigator.clipboard.writeText(url);
      toast.success("채팅방 링크를 복사했습니다.");
    } catch {
      window.prompt("이 채팅방의 링크를 복사해 주세요.", url);
    }
  }
  return (
    <div className={compact ? "compact-chat-wrap" : "chat-workspace"}>
      {!compact && (
        <ChatRoomDirectory
          rooms={rooms}
          activeId={room}
          onSelect={selectRoom}
          loading={roomsQuery.isLoading}
          error={roomsQuery.error?.message ?? null}
          onRetry={() => void roomsQuery.refetch()}
        />
      )}
      <div className={`chat-panel ${compact ? "compact-chat" : "full-chat"}`}>
        {!compact && (
          <>
            <div className="channel-heading">
              <Radio size={20} />
              <div>
                <strong>{active?.name ?? "채팅방 연결"}</strong>
                <p>
                  {active?.description ||
                    (active
                      ? `${active.creator}님이 연 대화 공간입니다.`
                      : "열린 채팅방을 선택해 주세요.")}
                </p>
              </div>
              <div className="room-heading-actions">
                <button
                  className="icon-btn"
                  aria-label="채팅방 링크 복사"
                  onClick={shareRoom}
                  disabled={!active}
                >
                  <Link2 size={17} />
                </button>
                {canManage && (
                  <button
                    className="icon-btn"
                    aria-label="채팅방 관리"
                    onClick={() => setEditing(active)}
                  >
                    <Settings2 size={17} />
                  </button>
                )}
              </div>
            </div>
            <div className="chat-feature-note">
              <ImagePlus size={13} />
              <span>이미지 최대 4장 · 한 장당 10MB</span>
              <Bell size={13} />
              <span>상단 종에서 알림 설정</span>
            </div>
          </>
        )}
        <div className="message-list" ref={messageList}>
          {!active && (
            <div className="chat-empty">
              <MessageCircle size={26} />
              <strong>
                {roomsQuery.isLoading
                  ? "채팅방을 불러오는 중입니다."
                  : roomsQuery.error
                    ? "채팅방에 연결하지 못했습니다."
                    : "이 채팅방은 닫혔거나 존재하지 않습니다."}
              </strong>
              <span>목록에서 다른 채팅방을 선택해 주세요.</span>
              {!compact && (
                <button
                  className="secondary-btn"
                  onClick={() => selectRoom("general")}
                >
                  테란 라운지로 이동
                </button>
              )}
            </div>
          )}
          {active && query.isLoading && (
            <div className="chat-empty">
              <LoaderCircle className="spin" size={24} />
              <span>통신 연결 중...</span>
            </div>
          )}
          {query.error && (
            <div className="error-message">
              채팅 연결을 확인해 주세요.
              <button onClick={() => query.refetch()}>다시 연결</button>
            </div>
          )}
          {active && !query.isLoading && !query.error && !messages.length && (
            <div className="chat-empty">
              <div className="chat-empty-icon">
                <MessageCircle size={26} />
              </div>
              <strong>
                {compact
                  ? "여기서 우리의 이야기가 시작돼요."
                  : "첫 번째 인사를 건네 보세요."}
              </strong>
              <span>
                {compact
                  ? "글과 사진으로 테란 시민들과 이야기해 보세요."
                  : "서로를 존중하며 함께 새로운 세계를 만들어 주세요."}
              </span>
            </div>
          )}
          {(active ? (compact ? messages.slice(-4) : messages) : []).map(m => (
            <div
              className={`message-item ${m.authorId === data.user?.id || (!data.user && data.admin && m.authorId === 0) ? "own" : ""}`}
              key={m.id}
            >
              <span
                className="avatar"
                style={{
                  background: `hsl(${(m.authorId * 67 + 200) % 360} 30% 22%)`,
                }}
              >
                {m.author.slice(0, 1)}
              </span>
              <div className="message-content">
                <div className="message-author">
                  {m.author}
                  <time>{timeLabel(m.createdAt)}</time>
                  {!compact && (data.admin || m.authorId === data.user?.id) && (
                    <button
                      className="icon-btn"
                      aria-label="메시지 삭제"
                      onClick={() => remove(m.id)}
                    >
                      <Trash2 size={12} />
                    </button>
                  )}
                </div>
                {m.body && <p>{m.body}</p>}
                {!!m.images?.length && (
                  <div
                    className={`message-images ${m.images.length > 1 ? "multiple" : ""}`}
                  >
                    {m.images.map((src, index) => (
                      <button
                        type="button"
                        className="message-image-button"
                        key={`${src}-${index}`}
                        aria-label={`${m.author}님이 보낸 이미지 ${index + 1} 확대 보기`}
                        onClick={() => setExpanded(src)}
                      >
                        <img
                          src={src}
                          alt={`${m.author}님이 보낸 이미지 ${index + 1}`}
                          loading="lazy"
                          onLoad={() => {
                            const list = messageList.current;
                            if (
                              !compact &&
                              list &&
                              list.scrollHeight -
                                list.scrollTop -
                                list.clientHeight <
                                250
                            )
                              end.current?.scrollIntoView({ block: "nearest" });
                          }}
                        />
                        <span>
                          <Expand size={15} />
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          <div ref={end} />
        </div>
        {(images.length > 0 || uploading) && (
          <div className="chat-attachments">
            <div className="attachment-heading">
              <span>전송할 이미지 {images.length}/4</span>
              {uploading && (
                <span>
                  <LoaderCircle className="spin" size={12} /> 업로드 중
                </span>
              )}
            </div>
            <div className="attachment-grid">
              {images.map((src, index) => (
                <div key={src} className="attachment-preview">
                  <img src={src} alt={`첨부 이미지 ${index + 1}`} />
                  <button
                    type="button"
                    aria-label={`${index + 1}번째 첨부 취소`}
                    disabled={sending || uploading}
                    onClick={() =>
                      setImages(prev => prev.filter((_, i) => i !== index))
                    }
                  >
                    <X size={12} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
        <form className="chat-input" onSubmit={send}>
          <input
            type="file"
            className="chat-file-input"
            ref={fileInput}
            accept="image/jpeg,image/png,image/webp,image/gif"
            multiple
            onChange={e => attach(e.target.files)}
          />
          <button
            className="chat-attach-button"
            type="button"
            aria-label="채팅 이미지 첨부"
            title="이미지 첨부"
            disabled={!active || uploading || sending || images.length >= 4}
            onClick={() => {
              if (requireLogin()) fileInput.current?.click();
            }}
          >
            {uploading ? (
              <LoaderCircle className="spin" size={17} />
            ) : (
              <ImagePlus size={19} />
            )}
          </button>
          <input
            aria-label="채팅 메시지"
            value={body}
            onChange={e => setBody(e.target.value)}
            maxLength={2000}
            disabled={!active}
            placeholder={
              canSend
                ? "이야기나 사진을 보내 보세요..."
                : "로그인하고 대화에 참여해 보세요"
            }
            onFocus={() => {
              if (!canSend) requireLogin();
            }}
          />
          <button
            className="chat-send-button"
            type="submit"
            aria-label="메시지 보내기"
            disabled={
              !active ||
              sending ||
              uploading ||
              (canSend && !body.trim() && !images.length)
            }
          >
            {sending ? (
              <LoaderCircle size={16} className="spin" />
            ) : (
              <Send size={16} />
            )}
          </button>
        </form>
        {!compact && (
          <div className="chat-safety">
            <LockKeyhole size={12} />
            시민들의 안전을 위해 채팅 기록이 보관됩니다. 사진 속 개인정보도
            확인해 주세요.
          </div>
        )}
        {expanded && (
          <div
            className="chat-image-lightbox"
            role="dialog"
            aria-modal="true"
            aria-label="채팅 이미지 확대 보기"
            onClick={() => setExpanded(null)}
          >
            <button
              className="lightbox-close"
              type="button"
              autoFocus
              aria-label="이미지 닫기"
              onClick={() => setExpanded(null)}
            >
              <X size={25} />
            </button>
            <img
              src={expanded}
              alt="확대한 채팅 이미지"
              onClick={e => e.stopPropagation()}
            />
            <a
              href={expanded}
              target="_blank"
              rel="noopener noreferrer"
              onClick={e => e.stopPropagation()}
            >
              원본 이미지 열기 <Expand size={14} />
            </a>
          </div>
        )}
      </div>
      {editing && (
        <ChatRoomEditor
          room={editing}
          onClose={() => setEditing(undefined)}
          onSaved={saved => {
            setEditing(undefined);
            if (saved.closed) selectRoom("general");
          }}
        />
      )}
    </div>
  );
}
export function ChatPage() {
  return (
    <div className="standard-page">
      <div className="page-heading">
        <div>
          <span className="eyebrow">WE ARE CONNECTED</span>
          <h1>같은 우주, 실시간 대화.</h1>
          <p>
            원하는 주제로 채팅방을 열고, 글과 사진으로 당신만의 이야기를
            나누세요.
          </p>
        </div>
        <span className="live-pill">
          <i /> LIVE CHAT
        </span>
      </div>
      <div className="chat-page-panel">
        <ChatPanel />
      </div>
    </div>
  );
}
