import { Link } from "wouter";
import {
  ArrowRight,
  Orbit,
  BookOpen,
  PanelsTopLeft,
  MessagesSquare,
  ShieldCheck,
  Radio,
} from "lucide-react";
import { ART } from "@shared/community";
export default function Info({ guide = false }: { guide?: boolean }) {
  return (
    <div className="standard-page info-page">
      <section
        className="info-hero"
        style={
          !guide
            ? {
                backgroundImage: `linear-gradient(90deg, rgba(9,14,27,.96),rgba(9,14,27,.4)),url(${ART.hero})`,
              }
            : undefined
        }
      >
        <span className="eyebrow">
          {guide ? "A BETTER WORLD, TOGETHER" : "THE TERRAN UNIVERSE"}
        </span>
        <h1>
          {guide ? (
            <>
              함께 만드는 세계에는
              <br />
              서로를 위한 약속이 있어요.
            </>
          ) : (
            <>
              테란,
              <br />
              아직 쓰이지 않은 우주.
            </>
          )}
        </h1>
        <p>
          {guide
            ? "처음 온 시민도, 오래된 창작자도 편안하게 이야기를 나눌 수 있도록."
            : "이곳은 우리가 함께 만들어 가는 가상국가입니다.\n하나의 설정, 한 편의 이야기가 새로운 역사가 됩니다."}
        </p>
      </section>
      {guide ? (
        <div className="guide-sections">
          {[
            {
              icon: BookOpen,
              title: "웹소설을 연재하려면",
              body: "로그인 후 웹소설 화면에서 작품을 등록하세요. 작품 소개와 표지를 설정한 뒤 작품 상세의 회차 등록 버튼으로 본문을 올릴 수 있습니다. 본인이 작성한 작품과 회차는 언제든 수정하거나 삭제할 수 있어요.",
            },
            {
              icon: PanelsTopLeft,
              title: "웹툰의 다음 장면을 올리려면",
              body: "웹툰 작품을 등록한 후 회차별 이미지를 업로드하세요. JPG, PNG, WEBP, GIF 파일을 한 장당 10MB까지 올릴 수 있고 화살표로 감상 순서를 바꿀 수 있습니다. 업로드한 이미지가 세로형 감상 화면에 순서대로 표시됩니다.",
            },
            {
              icon: MessagesSquare,
              title: "서로의 생각을 나누려면",
              body: "자유게시판, 세계관 토론, 창작 이야기, 질문 · 도움 중 어울리는 게시판을 선택해 글을 남겨 주세요. 댓글로 이야기를 이어갈 수 있고, 채팅에서는 테란 라운지·세계관 연구소·창작자 살롱 중 채널을 선택할 수 있어요.",
            },
            {
              icon: ShieldCheck,
              title: "우리 세계를 위한 기본 약속",
              body: "직접 창작했거나 게시 권한이 있는 콘텐츠만 올려 주세요. 다른 시민의 개인정보를 공유하거나 혐오, 욕설, 도배를 게시하지 마세요. 관리자는 커뮤니티 보호를 위해 콘텐츠를 숨기거나 삭제하고 작성 권한을 제한할 수 있습니다. 숨김과 삭제는 파일 저장소의 물리적 삭제를 의미하지 않습니다.",
            },
          ].map(({ icon: Icon, title, body }) => (
            <section className="guide-section" key={title}>
              <div className="info-icon">
                <Icon size={23} />
              </div>
              <div>
                <h2>{title}</h2>
                <p>{body}</p>
              </div>
            </section>
          ))}
        </div>
      ) : (
        <>
          <div className="world-intro">
            <span className="eyebrow">A WORLD WE BUILD TOGETHER</span>
            <h2>
              하나의 행성에서 시작되는,
              <br />
              무한한 가능성.
            </h2>
            <p>
              테란의 역사와 지형, 문화와 함대의 모습은 시민들의 상상 속에서
              완성됩니다. 여기 소개된 작품과 설정은 시작을 돕기 위한 예시입니다.
              당신이 구상한 테란의 이야기를 자유롭게 기록해 주세요.
            </p>
          </div>
          <div className="world-facts">
            <section>
              <span>01 / THE WORLD</span>
              <Orbit size={27} />
              <h3>우리의 국가, 테란</h3>
              <p>
                푸른 행성과 광활한 우주를 무대로 펼쳐지는 가상국가. 어떤 도시와
                문화를 가질지는 이제 우리의 이야기에 달려 있습니다.
              </p>
            </section>
            <section>
              <span>02 / THE STORIES</span>
              <BookOpen size={27} />
              <h3>다양한 시선의 역사</h3>
              <p>
                함대의 항해 일지부터 한 시민의 하루까지. 거대한 세계는 작은
                이야기에서 시작됩니다.
              </p>
            </section>
            <section>
              <span>03 / THE CITIZENS</span>
              <Radio size={27} />
              <h3>창작으로 이어지는 우리</h3>
              <p>
                작가, 그림을 그리는 사람, 이야기를 읽는 사람. 모두가 테란의
                세계를 넓혀가는 시민입니다.
              </p>
            </section>
          </div>
          <div className="world-cta">
            <h2>테란의 다음 역사는 당신의 이야기입니다.</h2>
            <Link href="/write" className="primary-btn">
              나의 이야기 시작하기 <ArrowRight size={17} />
            </Link>
          </div>
        </>
      )}
      <div className="info-links">
        <Link href={guide ? "/world" : "/guide"}>
          {guide ? "테란 세계관 둘러보기" : "커뮤니티 이용 안내"}{" "}
          <ArrowRight size={16} />
        </Link>
        <Link href="/community">
          시민들과 이야기 나누기 <ArrowRight size={16} />
        </Link>
      </div>
    </div>
  );
}
