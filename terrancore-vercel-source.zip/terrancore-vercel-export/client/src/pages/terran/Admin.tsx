import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
  Shield,
  LockKeyhole,
  ArrowRight,
  LoaderCircle,
  LogOut,
  EyeOff,
  Eye,
  Trash2,
  Users,
  BookOpen,
  MessagesSquare,
  MessageCircle,
  KeyRound,
  Check,
  Settings2,
  AlertTriangle,
} from "lucide-react";
import { toast } from "sonner";
import { api, dateLabel } from "@/lib/community";
import {
  useCommunity,
  DataStatus,
} from "@/components/terran/CommunityProvider";
import type { AdminData } from "@shared/community";
export default function Admin() {
  const { data, loading, error } = useCommunity();
  const [, navigate] = useLocation();
  useEffect(() => {
    if (!loading && !error && !data.admin)
      navigate("/admin/login", { replace: true });
  }, [loading, error, data.admin, navigate]);
  if (loading || error)
    return (
      <div className="standard-page">
        <DataStatus />
      </div>
    );
  if (!data.admin)
    return (
      <div className="standard-page">
        <div className="status-message">
          <LoaderCircle className="spin" size={17} /> 관리자 로그인창으로 이동
          중...
        </div>
      </div>
    );
  return <Dashboard />;
}
const tabs = [
  { id: "works", label: "작품" },
  { id: "episodes", label: "회차" },
  { id: "posts", label: "게시글" },
  { id: "comments", label: "댓글" },
  { id: "messages", label: "채팅" },
  { id: "users", label: "회원" },
  { id: "settings", label: "보안 설정" },
];
function Dashboard() {
  const { mutate, refresh } = useCommunity();
  const [tab, setTab] = useState("works");
  const [search, setSearch] = useState("");
  const [acting, setActing] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const query = useQuery({
    queryKey: ["admin-data"],
    queryFn: () => api<AdminData>("/admin/data"),
    retry: false,
  });
  const d = query.data;
  async function moderate(entity: string, id: number, action: string) {
    if (
      action === "delete" &&
      !window.confirm("이 항목을 삭제할까요? 삭제 후에는 복구할 수 없습니다.")
    )
      return;
    setActing(`${entity}-${id}`);
    try {
      await mutate("/admin/moderate", "POST", { entity, id, action });
      await query.refetch();
      toast.success(
        action === "hide"
          ? "항목을 숨겼습니다."
          : action === "restore"
            ? "항목을 다시 공개했습니다."
            : "항목을 삭제했습니다."
      );
    } catch {
    } finally {
      setActing("");
    }
  }
  async function member(id: number, banned: boolean) {
    if (
      !window.confirm(
        banned
          ? "이 회원의 작성 및 채팅 권한을 제한할까요?"
          : "이 회원의 이용 제한을 해제할까요?"
      )
    )
      return;
    try {
      await mutate("/admin/member", "POST", { id, banned });
      await query.refetch();
      toast.success("회원 상태를 변경했습니다.");
    } catch {}
  }
  async function logout() {
    try {
      await api("/admin/logout", "POST", {});
      sessionStorage.removeItem("terran-admin");
      await refresh();
      toast.success("관리자 로그아웃 완료");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "로그아웃 실패");
    }
  }
  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      toast.error("새 비밀번호 확인이 일치하지 않습니다.");
      return;
    }
    if (
      newPassword.length < 8 ||
      newPassword.length > 128 ||
      !/[a-zA-Z]/.test(newPassword) ||
      !/[^a-zA-Z]/.test(newPassword)
    ) {
      toast.error(
        "영문과 숫자 또는 기호를 포함한 8~128자 비밀번호를 사용해 주세요."
      );
      return;
    }
    setActing("password");
    try {
      await mutate("/admin/password", "POST", { currentPassword, newPassword });
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      toast.success("관리자 비밀번호를 변경했습니다.");
    } catch {
    } finally {
      setActing("");
    }
  }
  const entries = d
    ? tab === "works"
      ? d.works.map(w => ({
          entity: "work",
          id: w.id,
          title: w.title,
          author: w.author,
          hidden: w.hidden,
          date: w.createdAt,
          detail: w.kind === "novel" ? "웹소설" : "웹툰",
        }))
      : tab === "episodes"
        ? d.works.flatMap(w =>
            w.episodes.map(e => ({
              entity: "episode",
              id: e.id,
              title: `${w.title} · ${e.number}화 ${e.title}`,
              author: w.author,
              hidden: e.hidden,
              date: e.createdAt,
              detail: "회차",
            }))
          )
        : tab === "posts"
          ? d.posts.map(p => ({
              entity: "post",
              id: p.id,
              title: p.title,
              author: p.author,
              hidden: p.hidden,
              date: p.createdAt,
              detail: p.category,
            }))
          : tab === "comments"
            ? d.posts.flatMap(p =>
                p.comments.map(c => ({
                  entity: "comment",
                  id: c.id,
                  title: c.body,
                  author: c.author,
                  hidden: c.hidden,
                  date: c.createdAt,
                  detail: p.title,
                }))
              )
            : tab === "messages"
              ? d.messages.map(m => ({
                  entity: "message",
                  id: m.id,
                  title: m.body || `이미지 ${m.images?.length ?? 0}장`,
                  author: m.author,
                  hidden: m.hidden,
                  date: m.createdAt,
                  detail: m.room,
                }))
              : []
    : [];
  return (
    <div className="standard-page admin-dashboard">
      <div className="page-heading">
        <div>
          <span className="eyebrow">TERRAN CONTROL CENTER</span>
          <h1>
            테란 관제실 <Shield size={25} />
          </h1>
          <p>더 좋은 이야기가 머무를 수 있도록, 우리의 세계를 관리하세요.</p>
        </div>
        <button className="secondary-btn" onClick={logout}>
          <LogOut size={15} /> 관리자 로그아웃
        </button>
      </div>
      <div className="admin-stat-grid">
        {[
          { label: "등록 회원", value: d?.users.length, icon: Users },
          { label: "연재 작품", value: d?.works.length, icon: BookOpen },
          { label: "게시글", value: d?.posts.length, icon: MessagesSquare },
          {
            label: "채팅 기록",
            value: d?.messages.length,
            icon: MessageCircle,
          },
        ].map(({ label, value, icon: Icon }) => (
          <div className="admin-stat" key={label}>
            <Icon size={21} />
            <span>{label}</span>
            <strong>{value ?? "—"}</strong>
          </div>
        ))}
      </div>
      <div className="admin-tabs">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => {
              setTab(t.id);
              setSearch("");
            }}
            className={tab === t.id ? "active" : ""}
          >
            {t.label}
          </button>
        ))}
      </div>
      {query.isLoading && (
        <div className="status-message">
          <LoaderCircle className="spin" size={17} /> 관리 기록을 불러오는
          중입니다.
        </div>
      )}
      {query.error && (
        <div className="error-message">
          {query.error.message}
          <button onClick={() => query.refetch()}>다시 시도</button>
        </div>
      )}
      {tab === "settings" ? (
        <form className="editor-form password-form" onSubmit={changePassword}>
          <h2>
            <KeyRound size={20} /> 관리자 비밀번호 변경
          </h2>
          <p className="muted">
            영문과 숫자 또는 기호를 포함한 8~128자 비밀번호를 사용해 주세요.
            12자 이상의 긴 비밀번호를 권장합니다.
          </p>
          <label>
            현재 비밀번호
            <input
              type="password"
              value={currentPassword}
              onChange={e => setCurrentPassword(e.target.value)}
              required
              autoComplete="current-password"
            />
          </label>
          <label>
            새 비밀번호
            <input
              type="password"
              value={newPassword}
              onChange={e => setNewPassword(e.target.value)}
              required
              minLength={8}
              maxLength={128}
              autoComplete="new-password"
            />
          </label>
          <label>
            새 비밀번호 확인
            <input
              type="password"
              value={confirmPassword}
              onChange={e => setConfirmPassword(e.target.value)}
              required
              autoComplete="new-password"
            />
          </label>
          <button className="primary-btn" disabled={acting === "password"}>
            <Check size={16} /> 비밀번호 변경
          </button>
          <p className="fineprint">변경 시 다른 관리자 세션은 해제됩니다.</p>
        </form>
      ) : (
        <>
          <div className="admin-list-heading">
            <h2>{tabs.find(t => t.id === tab)?.label} 관리</h2>
            <input
              aria-label="관리 항목 검색"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="제목 또는 이름으로 검색"
            />
          </div>
          <div className="admin-list">
            {tab === "users"
              ? d?.users
                  .filter(u =>
                    `${u.name} ${u.email}`
                      .toLowerCase()
                      .includes(search.toLowerCase())
                  )
                  .map(u => (
                    <div className="admin-row" key={u.id}>
                      <span className="avatar">
                        {(u.name ?? "시민").slice(0, 1)}
                      </span>
                      <div className="admin-record">
                        <strong>{u.name ?? "테란 시민"}</strong>
                        <span>{u.email ?? "이메일 비공개"}</span>
                      </div>
                      <span
                        className={`moderation-status ${u.banned ? "hidden" : ""}`}
                      >
                        {u.banned ? "이용 제한" : "정상"}
                      </span>
                      <button
                        className="secondary-btn"
                        onClick={() => member(u.id, !u.banned)}
                      >
                        {u.banned ? "제한 해제" : "이용 제한"}
                      </button>
                    </div>
                  ))
              : entries
                  .filter(e =>
                    `${e.title} ${e.author}`
                      .toLowerCase()
                      .includes(search.toLowerCase())
                  )
                  .map(e => (
                    <div className="admin-row" key={`${e.entity}-${e.id}`}>
                      <div className="admin-record">
                        <strong>{e.title}</strong>
                        <span>
                          {e.detail} · {e.author} · {dateLabel(e.date)}
                        </span>
                        {e.entity === "message" && (
                          <div className="admin-message-images">
                            {d?.messages
                              .find(m => m.id === e.id)
                              ?.images?.map((src, i) => (
                                <a
                                  key={src}
                                  href={src}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  aria-label={`${i + 1}번째 채팅 이미지 원본 보기`}
                                >
                                  <img
                                    src={src}
                                    alt={`첨부 이미지 ${i + 1}`}
                                    loading="lazy"
                                  />
                                </a>
                              ))}
                          </div>
                        )}
                      </div>
                      <span
                        className={`moderation-status ${e.hidden ? "hidden" : ""}`}
                      >
                        {e.hidden ? "숨김" : "공개"}
                      </span>
                      <button
                        className="icon-btn"
                        disabled={acting === `${e.entity}-${e.id}`}
                        aria-label={e.hidden ? "다시 공개" : "항목 숨기기"}
                        onClick={() =>
                          moderate(
                            e.entity,
                            e.id,
                            e.hidden ? "restore" : "hide"
                          )
                        }
                      >
                        {e.hidden ? <Eye size={17} /> : <EyeOff size={17} />}
                      </button>
                      <button
                        className="icon-btn danger"
                        disabled={acting === `${e.entity}-${e.id}`}
                        aria-label="항목 삭제"
                        onClick={() => moderate(e.entity, e.id, "delete")}
                      >
                        <Trash2 size={17} />
                      </button>
                    </div>
                  ))}
          </div>
          {d &&
            ((tab === "users" && !d.users.length) ||
              (tab !== "users" && !entries.length)) && (
              <div className="empty-state">
                <Settings2 size={28} />
                <p>아직 관리할 기록이 없습니다.</p>
              </div>
            )}
          <p className="fineprint">
            숨김 처리한 콘텐츠는 시민들에게 표시되지 않습니다. 삭제는 되돌릴 수
            없습니다.
          </p>
        </>
      )}
    </div>
  );
}
