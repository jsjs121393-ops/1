# 별도 index.html 배치

압축본에는 요청에 따라 `client/index.html`을 넣지 않았습니다. 별도로 제공된 `terrancore-vercel-index.html` 파일을 압축 해제 후 다음 경로에 복사하세요.

`client/index.html`

그 다음 Vercel에서 `vercel.json`을 인식한 상태로 배포하면 됩니다. 이 파일은 SEO 제목과 keywords 메타 태그를 포함한 원본 홈 문서입니다.
