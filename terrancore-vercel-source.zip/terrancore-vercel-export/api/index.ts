import { createApp } from "../server/_core/app";

// Vercel invokes the exported Express application for /api/* requests.
// Static frontend files are served by Vercel from dist/public.
const app = createApp();

export default app;
