export type ContentKind = "novel" | "webtoon";
export interface Member {
  id: number;
  name: string | null;
  email: string | null;
  role: "user" | "admin";
  banned?: boolean;
  createdAt?: string;
}
export interface Episode {
  id: number;
  workId: number;
  title: string;
  number: number;
  body: string;
  images: string[];
  createdAt: string;
  hidden: boolean;
}
export interface Work {
  id: number;
  kind: ContentKind;
  title: string;
  description: string;
  author: string;
  authorId: number;
  genre: string;
  cover: string;
  tags: string[];
  status: "ongoing" | "completed";
  createdAt: string;
  featured: boolean;
  hidden: boolean;
  sample: boolean;
  episodes: Episode[];
}
export interface Comment {
  id: number;
  postId: number;
  body: string;
  author: string;
  authorId: number;
  createdAt: string;
  hidden: boolean;
}
export interface Post {
  id: number;
  title: string;
  body: string;
  category: string;
  author: string;
  authorId: number;
  createdAt: string;
  hidden: boolean;
  pinned: boolean;
  sample: boolean;
  comments: Comment[];
}
export interface ChatRoom {
  id: string;
  name: string;
  description: string;
  creatorId: number;
  creator: string;
  createdAt: string;
  isDefault: boolean;
  closed: boolean;
  messageCount: number;
}
export interface ChatMessage {
  id: number;
  room: string;
  roomName?: string;
  body: string;
  images: string[];
  author: string;
  authorId: number;
  createdAt: string;
  hidden: boolean;
}
export interface Bootstrap {
  user: Member | null;
  admin: boolean;
  works: Work[];
  posts: Post[];
  messages: ChatMessage[];
  stats: { members: number; works: number; posts: number; messages: number };
}
export interface AdminData {
  users: Member[];
  works: Work[];
  posts: Post[];
  messages: ChatMessage[];
}
export const ART = {
  hero: "/manus-storage/async-images/BqLuOSrrGQpaFuzvhvQbx8/image-1.webp",
  covers: [
    "/manus-storage/async-images/BqLuOSrrGQpaFuzvhvQbx8/image-2.webp",
    "/manus-storage/async-images/BqLuOSrrGQpaFuzvhvQbx8/image-3.webp",
    "/manus-storage/async-images/BqLuOSrrGQpaFuzvhvQbx8/image-4.webp",
    "/manus-storage/async-images/BqLuOSrrGQpaFuzvhvQbx8/image-5.webp",
  ],
};
